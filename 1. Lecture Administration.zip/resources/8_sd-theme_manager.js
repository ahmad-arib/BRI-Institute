try {
// custom theme classes
$(document).ready(function(){
    $('.slide').addClass('sd-slide-background-color_1');
    $('#slide-box').addClass('sd-world-background-image_1');
});

}
catch  (ex) { }