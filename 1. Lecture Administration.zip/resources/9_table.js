var scene = (function () {

    var config = {
        layers: 3
    };

    var tranDone = null;
    var ourDiv;
    var SLIDE_WIDTH = 1920;
    var $viewportDiv; //the div suppied by editor or player in which in scene runs. 
    var $world; //the outermost container of the scene
    var $slideBox;  //container for slides. same size as slides.
    var $currentSlide; //slide in view.
    var $bgBox;
    var templates = { 
        world: '<div id="world">',
        slideBox: '<div id="slide-box">',
        slide: '<div class="slide pre-enter">'
    };
    //NOTE: slides in scenes are not zero indexed. Therefore 1 is added or substracted from all index related operations. 
    function init(viewportDivID) {
        clearParams(); // in case of editor=>player reset
        ourDiv = document.getElementById(viewportDivID);
        $viewportDiv = $('#' + viewportDivID);
        $world = $(templates.world).appendTo($viewportDiv);
        $slideBox = $(templates.slideBox).appendTo($world);
        //$frame = $(templates.frame).appendTo($viewportDiv); // not required anymore and blocks mouse clicks on videos

        $viewportDiv.css({ height: $viewportDiv.parent().height + 'px', width: $viewportDiv.parent().width + 'px' });

        //$(window).on('resize', scale);
        var TO = false;
        $(window).resize(function (event) {
            if (this != event.target)
                return;
            if (TO !== false)
                clearTimeout(TO);
            TO = setTimeout(scale, 600); //200 is time in miliseconds
        });
        scale();

        if ( document.readyState == 'complete' ){
            loadFinished();
        } else {
            setTimeout(loadFinished(), 3000);
        }
    };

    //TODO make more intelligent
    function loadFinished() {
        $('body').triggerHandler('loadfinished');
    }

    function scale() {
        centerScale();
    }


    function insertSlide(slideNum, html) {
        var tempPlace = addSlide(html);
        if (tempPlace == slideNum)
            return;
        moveSlide(tempPlace, slideNum);
    }

    function centerScale() {
        var wW = ourDiv.parentNode.offsetWidth;
        var wH = ourDiv.parentNode.offsetHeight;

        var scaler = Math.min(wW / 1920, wH / 1080); // original screen was designed in full HD Chrome
        var w = wW / scaler;
        var h = wH / scaler;
        var left = (w - scaler * w) / 2 - (w - 1920) / 2 * scaler;
        var top = (h - scaler * h) / 2 - (h - 1080) / 2 * scaler;


        var style = "width:" + w + "px; height:" + h + "px;" + allStyles("-webkit-transform:  translate(-" + left + "px,-" + top + "px) scale(" + scaler + ");");

        ourDiv.setAttribute("style", style);

        //redrawScene();
        //            stepToSlide(currentSlide);
    }

    // should get a line with a single webkit command, and will multiply it and add other extensions
    function allStyles(style) {
        var styles = style;
        styles += " " + style.replace(/webkit/g, "moz"); // mozilla
        styles += " " + style.replace(/webkit/g, "ms"); // Microsoft Explorer
        styles += " " + style.replace(/webkit/g, "o"); // Opera
        styles += " " + style.replace(/-webkit-/g, ""); // generic

        return styles;
    }


    /*function scale($element) {
        var $toScale = $viewportDiv;

        $toScale.each(function () {
            var margin = parseInt($toScale.css('margin'));
            $toScale.css('margin', '0');
            scaleElement($toScale, $toScale.parent(), margin);
            centerInParent($toScale);
        });
    }*/
    //old scale function
    function oldScale() {
        ourDiv.setAttribute("style", ""); // might cause problems with future scenes? maybe better do it somehow in the css
        var margin = parseInt($slideBox.css('margin'));
        $slideBox.css('margin', '0');
        scaleElement($slideBox, $world, margin);
        centerInParent($slideBox);
    }

    //copied exactly fromt he toher scenes


    function getSLideBoundingClientRect() {
        var wW = ourDiv.parentNode.offsetWidth;
        var wH = ourDiv.parentNode.offsetHeight;

        var scaler = Math.min(wW / 1920, wH / 1080); // original screen was designed in full HD Chrome
        var w = wW;/// scaler;
        var h = wH;// / scaler;


        var bb = {left:0, right:w, top:0, bottom:h, width:w, height:h};//$slideBox.get(0).getBoundingClientRect();
        //var bb;
        
        return bb;
    }

    //centers absolutley positioned element in parent
    function centerInParent($element) {
        var $parent = $element.parent();
        var scaleFactor = $element.attr('scale-factor') || 1;  //TODO use boundingclientrect instead of scalefactor
        var wdelta = $parent.width() - ($element.width() * scaleFactor);
        var hdelta = $parent.height() - ($element.height() * scaleFactor);
        $element.css({
            left: wdelta / 2 + 'px',
            top: hdelta / 2 + 'px'
        });
    }

    function scaleElement($element, $context, margin) {
        margin = margin || 0;
        var
            w = $element.width(),
            h = $element.height(),
            dw = $context.width() - margin,
            dh = $context.height() - margin,
            widthDelta,
            heightDetla,
            minDelta,
            maxDelta,
            transform;

        widthDelta = dw / w;
        heightDetla = dh / h;
        minDelta = Math.min(widthDelta, heightDetla);

        transform = 'scale(' + minDelta + ',' + minDelta + ')';

        $element.css('-webkit-transform', transform).attr('scale-factor', minDelta);
        $element.css('-moz-transform', transform).attr('scale-factor', minDelta);
        $element.css('transform', transform).attr('scale-factor', minDelta);
        return minDelta;
    }

    function addSlide(html) {  //TODO IMPORTNAT: what about adding the slide into a specificed position? do add plus move?? perhaps this is causing bugs with slide locations when new slides are added in editor somewhere other than the end of the slides list.
        var $toAdd = $(html || '<div class="slide pre-enter">');
        var $slide;

        $slide = $toAdd.first().is('.slide') ? $toAdd : $(templates.slide).append($toAdd).appendTo($slideBox);
        $slide.addClass('sd-slide-background-color_1');
        $slide.appendTo($slideBox);
        $slideBox.width(($slideBox.children('.slide').length + 1) * SLIDE_WIDTH); //make it extra long (+1) to make sure no black area is visible on left edge
        $slideBox.addClass('sd-world-background-image_1');

        return $slide.index() + 1; //return new slide count in convention with other scenes.
    }

    function currentSlideNum() {
        return $currentSlide ? $currentSlide.index() + 1 : 0;
    }
    //slides are not zero indexed
    function getSlide(num) {
        return $($slideBox.children()[num - 1]);
    }

    function goSlide(num) {
        
        var $targetSlide = getSlide(num);
        var oldSlideNum = currentSlideNum();
        var transitionTicks; //time alotted for css transition or video
        var transFromVal;
        if ($targetSlide.length === 0) {
            return;
        }
        
        transFromVal = 'translateX(' + SLIDE_WIDTH * $targetSlide.index() * -1 + 'px' + ')';

        $currentSlide = $targetSlide;

        $viewportDiv.trigger('transitionStart', [num]);
        
        $viewportDiv.attr('slide', currentSlideNum());

        // perform only on explorer! TranslateX for some reason causes a black box to appear
        if ( navigator.userAgent.search('Trident') > -1 || navigator.userAgent.search('MSIE') > -1 ) {
            
            $("#slide-box").css('left', (SLIDE_WIDTH * $targetSlide.index() * -1) + 'px');

        } else {
            $slideBox.css({ '-webkit-transform': transFromVal, '-moz-transform': transFromVal });
        }
        if (tranDone != null)
            clearTimeout(tranDone);
        tranDone=setTimeout(function () { $viewportDiv.trigger('transitionDone'); }, 3500);
    }

    function setSlideHTML(slideNum, html) {
        getSlide(slideNum).html(html);
    }

    function removeHTML(slideNum) {
        getSlide(slideNum).addClass('hide-elements');  //not actually removing html, but keeping name for compatability with other scenes.
    }
    function restoreHTML(slideNum) {
        getSlide(slideNum).removeClass('hide-elements');
    }

    function rewind() {
        goSlide(1);
    }

    function nextSlide() {
        goSlide(currentSlideNum() + 1);
    }
    function prevSlide() {
        goSlide(currentSlideNum() - 1);
    }

    function moveSlide(fromIdx, toIdx) {
        var $targetslide = getSlide(fromIdx);

        if ($targetslide && $targetslide.length === 1) {
            if (toIdx === 1) {
                $slideBox.prepend($targetslide);
            } else if (toIdx < fromIdx) {
                getSlide(toIdx).before($targetslide);
            } else {
                getSlide(toIdx).after($targetslide);
            }
        }
        // IF MOVE DOESN'T WORK, TRY UNCOMMENTING THE FOLLOWING LINES
        //$slideBox.children().each(function () {
        //    setSlideLeft($(this));
        //});
    }

    function deleteSlide(slideNum) {
        var $slides = $slideBox.find('.slide');
        getSlide(slideNum).remove();
        $slideBox.width((1 + $slides.length) * $slides.width());
        $slideBox.css("transition", "none");
        $slideBox.css("-webkit-transition", "none");
        setTimeout(function () {
            $slideBox.css("transition", "");
            $slideBox.css("-webkit-transition", "");
        }, 200);
        

        /*
        
        $slideBox.width($slides.length * $slides.width());

        $slides.each(function () {
            setSlideLeft($(this));
        });*/
    }

    function setSlideLeft($slide) {
        var left = $slide.index() * $slide.width()
        $slide.css('left', left + 'px');
    }

    function manualMove() {
        //empty function to prevent bugs when player calls this method. TODO: have player check if method exists.
    }

    function clearParams() {
        tranDone = null;
        ourDiv=null;
        SLIDE_WIDTH = 1920;
        $viewportDiv=null; //the div suppied by editor or player in which in scene runs. 
        $world=null; //the outermost container of the scene
        $slideBox=null;  //container for slides. same size as slides.
        $currentSlide=null; //slide in view.
        $bgBox=null;
    }

    function getCurrentSlide() {
        return $currentSlide;
    }

    return {
        init: init,
        addSlide: addSlide,
        currentSlideNum: currentSlideNum,
        getCurrentSlide: getCurrentSlide,
        goSlide: goSlide,
        rewind: rewind,
        nextSlide: nextSlide,
        prevSlide: prevSlide,
        setSlideHTML: setSlideHTML,
        removeHTML: removeHTML,
        restoreHTML: restoreHTML,
        moveSlide: moveSlide,
        manualMove: manualMove,
        getSLideBoundingClientRect: getSLideBoundingClientRect,
        deleteSlide: deleteSlide,
        resizeWinner: scale,
        insertSlide: insertSlide
    };


})();