var EM = EM || {};

EM.Media = (function () {

    var enabled = false;


    function slideEnter() {
        var $slide;
        try {
            if (!enabled) {
                return;
            }

            $slide = scene.getCurrentSlide();

            if (!$slide || !$slide.length) {
                console.warn('no slide returned by scene.getCurrentSlide() function');
                return;
            }

            $slide.find('video').each(function () {
                var $this = $(this);
                var dataSrc = $this.attr('data-src');
                var src = $this.attr('src');
                this.autoplay = $this.attr('data-mediaautoplay') === 'true';
                this.preload = "auto";

                if (!src && dataSrc) {
                    this.src = dataSrc;                    
                } else {
                    //TODO: report error
                }

                if (this.autoplay) {
                    try {
                        var promise = this.play();
                        //console.log(this, promise);
                    } catch (e) {
                        console.error(e);
                    }
                }
            });

        } catch (e) {
            console.error(e);
        }
    }

    function allVideosInTarget(e) {
        var $target = $(e.target);
        return $target.filter('video').add($target.find('video'));
    }

    function loadVideo() {
        var dataSrc = this.getAttribute('data-src');
        if (dataSrc && !this.getAttribute('src')) {
            this.src = dataSrc;
        }
        if (this.getAttribute("data-mediaautoplay") === "true" && this.paused && this.readyState < 2 && $(this).closest(".current-active-slide").length > 0 ) { // for parallax and website replaces. the video after replace doesn't play.
            this.play();
        }
    }

    function unloadVideo() {
        var src = this.getAttribute('src');
        if (src) {
            this.pause();
            this.setAttribute('data-src', src);
            this.src = "";
            this.load();
        }
    }

    function pauseVideo() {
        try {

       
        var src = this.getAttribute('src');
        if (src && this.pause) {
            this.pause();
        }
        } catch (e) {
            console.error(e);
        }
    }


    function loadVideosOnInsert(e) {
        allVideosInTarget(e).each(loadVideo);
    }
   
    function unloadVideosOnRemoval(e) {
        allVideosInTarget(e).each(unloadVideo);
    }

    function implementChromeVideoUnloadFix() { //checking in scene manager if there are videos in the presentation so as not to burned presentations that do not have videos with this expensive event handler.

        $(document).off('DOMNodeInserted', loadVideo).off('DOMNodeRemoved', unloadVideo);

        if (window.EM && EM.scenemanager && EM.scenemanager.optimizer && EM.scenemanager.optimizer.hasVideos && $('body').is('.chrome')) {//http://stackoverflow.com/questions/3258587/how-to-properly-unload-destroy-a-video-element
            $(document).on('DOMNodeInserted', loadVideosOnInsert).on('DOMNodeRemoved', unloadVideosOnRemoval); //removing event handlers before adding to prevetn adding multiple times upon reload in editor.
        }
    }

    function ensureSingleEventHandler(target, event, handler) {
        $(target).off(event, handler).on(event, handler);

    }

    function onSceneReady() {

        ensureSingleEventHandler('#scene', 'transitionDone', slideEnter);
        ensureSingleEventHandler('#scene', 'transitionStart', pauseAllMedia);  //stop all videos/audio from playing in other slides

        $('#scene').on('click', '.slide video', function () {
              if (this.paused) {
                  this.play();
              } else {
                  this.pause();
              }
          });

        implementChromeVideoUnloadFix();
    }

    ensureSingleEventHandler(window, 'sceneReady', onSceneReady);

    $(window).off('sceneReady', onSceneReady).on('sceneReady', onSceneReady);


    //stops mp3 and mp4 files from playing inside of the sd-element-media elements
  

    function stopAllMedia() {
        $('video.sd-element-media').each(unloadVideo);
    }

    function pauseAllMedia() {
        $('video.sd-element-media').each(pauseVideo);
    }

    function toggleEnabled(isEnabled) {
        enabled = isEnabled;
    }

    return {
        stopAllMedia: stopAllMedia,
        toggleEnabled: toggleEnabled
    }

})();

EM.ImageEnlarger = (function () {

    var requests = []; // all the css, JavaScript load requests.
    var addedScriptsCssHtmlHash = {}; // the already added scripts and css hash.
   

    
    function receiveMessage(message) {
        /*if (message.origin !== "https://app.emaze.com" && message.origin !== "http://app.emaze.com" && message.origin !== "https://resources.emaze.com" && message.origin !== "http://resources.emaze.com" && message.origin !== "https://www.emaze.com" && message.origin !== "http://www.emaze.com" && message.origin !== "http://emaze.me" && message.origin !== "http://localhost:44301") // if not our domains return! may be an attack!
            return;*/

        try {
            //var data = JSON.parse(message.data);
            var data = tryParseJSON(message.data);

            if (data === false)
                return;

            
            if (data.messageType === "enlargeInstagram") {
                enlarge(data.carouselData, message.source, message.origin);
            }
            else if (data.messageType === "enlargeSlickCarousel") {
                enlarge(data.carouselData, message.source, message.origin);
            }
            else if (data.messageType === "enlargeImageSliderCarousel") {
                enlarge(data.carouselData, message.source, message.origin);
            }
            else if (data.messageType === "enlargeFacebook") {
                enlarge(data.carouselData, message.source, message.origin);
            }
            else if (data.messageType === "getMoreFacebook") { // if we requested more images from facebook
                if (BlueimpLightbox) { // we need to check because the script is added dynamically.
                    BlueimpLightbox.moreItemsReceived(data.carouselData);
                }
            }
            else if (data.messageType === "getMoreInstagram") { // if we requested more images from instagram
                if (BlueimpLightbox) { // we need to check because the script is added dynamically.
                    BlueimpLightbox.moreItemsReceived(data.carouselData);
                }
            }
            else if (data.messageType === "isEditor") { // if the widget is in the player and we want to display the claim your site banner.
                if (typeof presentation !== "undefined"){
                    if (EM.isPublished && presentation.userInfo.isClaimed === false && presentation.core.ezContentType === 6) {
                        var replyBack = JSON.stringify({ messageType: "isEditor", isInPlayer: true }); // create the json for the response
                        message.source.postMessage(replyBack, message.origin); // reply back to the widget.
                    }
                }

            }
            

        } catch (e) {
            console.log("playerImageEnlargerError:" + e);
            
        }
    }

    window.addEventListener("message", receiveMessage, false);



    function enlarge(data, sendersSource , sendersOrigin) {
        // need to open the imageEnlarger with this json  {arr: [ {title: "", href: "", type: "", thumbnail/poster :"" },...] startIndex: "", origin:"" }
        
        //if not exist add the imageEnlarger to the DOM
        var jsArr = [
            createFullUrl("/vbcommon/libs/imageEnlarger/js/blueimp-gallery.min.js"),
            createFullUrl("/vbcommon/libs/imageEnlarger/js/carousel.js")
        ];
        var cssArr = [
            createFullUrl("/vbcommon/libs/imageEnlarger/css/blueimp-gallery.min.css"),
            createFullUrl("/vbcommon/libs/imageEnlarger/css/carousel.css")
        ];

       var didWeLoadNewFiles =  checkAndAddHtmlScriptsAndCssDynamically(cssArr, jsArr);// check and add the html, scripts and css to the DOM only if needed.



        if (didWeLoadNewFiles) {
            
            $.when.apply($, requests).done(function () {// callback after all the javascript and css files from the request array was loaded .
                var template = $(BlueimpLightbox.templates.regular); // the gallery already loaded it is ok to use it.
                if (!(addedScriptsCssHtmlHash[template] === "exist")) { // if the template does not exist add it to the body and to to the hash
                    $("body").append(template);
                    console.log("html added to the dom");
                    addedScriptsCssHtmlHash[template] = "exist";
                }
                
                requests = []; // empty the requests array, we can try to load more files afterwards.

                //var exampleObject = BlueimpLightbox.exampleObj;
                data["sendersSource"] = sendersSource;
                data["sendersOrigin"] = sendersOrigin;// attach the origin (the senders source) to the array.

                BlueimpLightbox.init(data);
                //console.log("carousel added to the DOM");

            });
        }
        else {
            //var exampleObject = BlueimpLightbox.exampleObj;
            //BlueimpLightbox.init(exampleObject);
            data["sendersSource"] = sendersSource; // add the senders reference as source to the object received.
            data["sendersOrigin"] = sendersOrigin;// add the senders domain as origin to the object received..
            BlueimpLightbox.init(data);
            //console.log("carousel already in the DOM");
        }
      

    }
    /**
     * @description adds the environment(for example resources.emazestaging.com) and version to the path
     * @param {string} pathToFile To the File with the prefix '/'. for example:  /vbcommon/libs/imageEnlarger/js/carousel.js
     * @returns {string} full url with environment and version (for example : //resources.emazestaging.com/vbcommon/libs/imageEnlarger/js/carousel.js?v=V3.0.7954.636311366583647781 ) 
     */
    function createFullUrl(pathToFile) {
        if (typeof emazeAppVersion === "undefined" || emazeAppVersion === null) { // at emaze.me the users doesn't have the emazeAppVersion until they republish.
            return environment + pathToFile;
        }
        return environment + pathToFile + "?v=" + emazeAppVersion;
    }

    /*
     * @description Adds the carousel's css and javascript dynamically
     * @param {string} Html template 
     * @returns {} 
     */
    function checkAndAddHtmlScriptsAndCssDynamically(cssUrlsArr, jsUrlsArr) {

        var bool = false;

        if (cssUrlsArr) {
            $.map(cssUrlsArr, function (url) { //urls is the array of css files we want to load
                if ( !(addedScriptsCssHtmlHash[url] === "exist") ) { // if the url
                    var defer = $.Deferred();
                    defer.promise();

                    //we add the deferred object to the requests array
                    requests.push(defer);

                    var cssEl = $('<link>', { rel: 'stylesheet', type: 'text/css', 'href': url });
                    cssEl.appendTo("head").on("load",
                        function() {
                            defer.resolve();
                        });
                    addedScriptsCssHtmlHash[url] = "exist";
                    bool = true;

                }

            });
        }

        if (jsUrlsArr) {
            $.map(jsUrlsArr, function (url) { //urls is the array of css files we want to load
                if (!(addedScriptsCssHtmlHash[url] === "exist")) {
                    var defer = $.Deferred();
                    defer.promise();

                    var script = document.createElement("script");
                    script.type = "text/javascript";
                    script.src = url;
                    //script.async = false;
                    script.addEventListener('load', function () {
                        defer.resolve(script);
                    }, false);
                    
                    document.body.appendChild(script);
                    //document.head.appendChild(script);

                    requests.push(defer);
                    addedScriptsCssHtmlHash[url] = "exist";
                    bool = true;
                }
            });
        }
        

        return bool;

    }

    


    function tryParseJSON(jsonString) {
        try {
            var o = JSON.parse(jsonString);

            // Handle non-exception-throwing cases:
            // Neither JSON.parse(false) or JSON.parse(1234) throw errors, hence the type-checking,
            // but... JSON.parse(null) returns null, and typeof null === "object", 
            // so we must check for that, too. Thankfully, null is falsey, so this suffices:
            if (o && typeof o === "object") {
                return o;
            }
            return false;
        }
        catch (e) { }

        return false;
    }


    return {
    };

})();


