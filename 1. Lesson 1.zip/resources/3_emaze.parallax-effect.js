'use strick';
(function ($, undefined) {

    /*******   Utilities for All browsers    *********/
    if (!Element.prototype.matches) {
        Element.prototype.matches =
            Element.prototype.matchesSelector ||
            Element.prototype.mozMatchesSelector ||
            Element.prototype.msMatchesSelector ||
            Element.prototype.oMatchesSelector ||
            Element.prototype.webkitMatchesSelector ||
            function (s) {
                var matches = (this.document || this.ownerDocument).querySelectorAll(s),
                    i = matches.length;
                while (--i >= 0 && matches.item(i) !== this) { }
                return i > -1;
            };
    }

    if (!window.requestAnimationFrame) {
        window.requestAnimationFrame = (function () {

            return window.webkitRequestAnimationFrame ||
                window.mozRequestAnimationFrame || // comment out if FF4 is slow (it caps framerate at ~30fps: https://bugzilla.mozilla.org/show_bug.cgi?id=630127)
                window.oRequestAnimationFrame ||
                window.msRequestAnimationFrame ||
                function ( /* function FrameRequestCallback */ callback, /* DOMElement Element */ element) {
                    window.setTimeout(callback, 1000 / 60);
                };
        })();
    }

    if (!window.cancelAnimationFrame) {
        // handle multiple browsers for cancelAnimationFrame()
        window.cancelAnimationFrame = (function () {
            return window.cancelAnimationFrame ||
                window.webkitCancelAnimationFrame ||
                window.mozCancelAnimationFrame ||
                window.oCancelAnimationFrame ||
                function (id) {
                    window.clearTimeout(id);
                };
        })();
    }

    window.BrowserAndDeviceInfo = function () {
        var userAgent = window.navigator.userAgent.toLowerCase();
        var browserName = EM.compatibility.getBrowser(),
            device = EM.compatibility.getDevice(),
            typeOfDevice = EM.compatibility.getType();
        var browser = {};
        browser.isSafari = browserName.indexOf("safari") != -1;
        browser.isChrome = browserName.indexOf("chrome") != -1;
        browser.isFireFox = browserName.indexOf("firefox") != -1;
        browser.isEdge = browserName.indexOf("edge") != -1;
        browser.isIE = browserName.indexOf("ie") != -1;
        browser.isMac = typeOfDevice == "mac";
        browser.isPC = typeOfDevice == "pc";
        browser.isIos = typeOfDevice == "iphone" || typeOfDevice == "ipad";
        browser.isIphone = typeOfDevice == "iphone";
        browser.isIPad = typeOfDevice == "ipad";
        browser.isAndroid = typeOfDevice == "android";
        browser.isMobile = device == "mobile";
        browser.isTablet = device == "tablet";
        browser.is3D = false;
        return browser;
    }();

    window.addMultipleEventListener = function (element, events, func) {
        if (element && func && events.length > 0 && events.indexOf(' ') !== -1) {
            events.split(' ').forEach(function (ev) { element.addEventListener(ev, func, false); });
        }
    }

    window.removeMultipleEventListener = function (element, events, func) {
        if (element && func && events.length > 0 && events.indexOf(' ') !== -1) {
            events.split(' ').forEach(function (ev) { element.removeEventListener(ev, func); });
        }
    }

    /******** END  Utilities for All browsers    ********/

    var _parallax = {
        slides: [],
        isBusy: false
    }

    var _b = window.BrowserAndDeviceInfo,
        scrollTime = 1.2,
        scrollDistance = 150,
        startX = 0,
        startY = 0,
        startScrollPosition = 0,
        newScrollPosition = 0;

    function generateSlideId() {
        return new Date().getTime();
    }

    var isCheckedTemplate = false;

    // function set property window.BrowserAndDeviceInfo.is3D
    // this means that template 2D or 3D
    function checkTemplate(scrollBox) {
        var underfined;
        if (!scrollBox.parentElement.hasAttribute('scale-factor')) {
            _b.is3D = true;
        }
        isCheckedTemplate = true;
    }

    var prefix = EM.screenShotFlag ? '#slide-container ' : '#scene ';
    var selectorBase = '[class*="effect_parallax"]:not(.em-parallax):not([class*="effect_parallax_none"]):not([data-parallax-type])';

    function setParallaxTypeAttribute(element) {
        if (element.matches('[class*="effect_parallax_scroll"]')) {
            element.dataset.parallaxType = "scroll";
        }
        else if (element.matches('[class*="effect_parallax_fixed"]')) {
            element.dataset.parallaxType = "fixed";
        }
        else if (element.matches('[class*="effect_parallax_zoom"]')) {
            element.dataset.parallaxType = "zoom";
        }
    }

    function removeParallaxTypeAttribute(element) {
        delete element.dataset.parallaxType;
    }

    function getParallaxElements() {

        var selector = prefix + selectorBase;
        var parallaxElements = document.querySelectorAll(selector);

        if (parallaxElements && parallaxElements.length > 0) {
            parallaxElements.forEach(function (element) {
                setParallaxTypeAttribute(element);
            });            
            return parallaxElements;
        }
        return null;
    }

    function insertElementsToSlides(elements) {
        elements.forEach(function (e) {
            e.classList.add('em-parallax');
            var originalSlide = e.closest('.slide') != null ? e.closest('.slide') : e.closest('.slide_g');
            if (originalSlide) {
                if (!isCheckedTemplate)
                    checkTemplate(originalSlide);
                var slideId = originalSlide.dataset.slideId,
                    slide;
                if (!slideId) {
                    do {
                        slideId = generateSlideId();
                        slide = _parallax.slides.find(function (s) { return s.id == slideId; });
                    } while (slide != null)
                    originalSlide.dataset.slideId = slideId;
                    slide = {
                        id: slideId,
                        elements: [],
                        original: originalSlide,
                        listened: false,
                        installed: false
                    };
                    _parallax.slides.push(slide);
                } else {
                    slide = _parallax.slides.find(function (s) { return s.id == slideId; });
                }
                slide.elements.push(e);
            }
        });
    }    

    function loadScrollPositionElement(element, scrollPosition) {
        var slide = element.parentElement;
        var media = element._media;
        var scrollTop = scrollPosition != undefined ? scrollPosition : slide.scrollTop;       
        
        var deltaTop = element.offsetTop + element.clientTop - scrollTop;
        var deltaBottom = scrollTop + slide.clientHeight - element.offsetTop - element.clientHeight - 2 * element.clientTop;
        if (deltaTop > -element.clientHeight && deltaTop < slide.clientHeight) {
            var y = (-1) * deltaTop * (1 - media.plx.speedY) + media.plx.deltaTopForCenter;
            var z = (deltaBottom + element.clientHeight) * media.plx.speedZ;
            media.style.transform = media.plx.type === "zoom" ? "translate3d(0, " + y + "px, " + z + "px)" : "translate(0, " + y + "px)";
        }
    }

    function loadScrollPositionSlide(slide, position) {
        slide.elements.forEach(function (el) {
            loadScrollPositionElement(el, position);
        });
    }

    // calls when user scroll the slide
    function scrollEventListener(event) {
        //TODO: Change position of relevantes elements
        var slide = this._slide;
        if (_b.isMac) {
            loadScrollPositionSlide(slide);
        }
        else if (_b.isMobile || _b.isTablet) {            
            if (!_parallax.isBusy) {
                window.requestAnimationFrame(function () {
                    loadScrollPositionSlide(slide);
                    _parallax.isBusy = false;
                });
                _parallax.isBusy = true;                               
            }            
        }
        else if (_b.isChrome) {
            loadScrollPositionSlide(slide);
        }
        else {
            if (!_parallax.isBusy) {                
                window.requestAnimationFrame(function () {
                    loadScrollPositionSlide(slide);
                    _parallax.isBusy = false;
                });
                _parallax.isBusy = true;
            }
        }        
    }

    function mousewheelEventListener(event) {
        //TODO: Change position of relevantes elements        
        event.preventDefault();
        var delta = event.wheelDelta / 120 || -event.detail / 3;
        var scrollTop = this.scrollTop;
        var finalScroll = scrollTop - parseInt(delta * scrollDistance);
        TweenLite.to($(this), scrollTime, {
            scrollTo: { y: finalScroll, autoKill: true },
            ease: Power2.easeOut,
            overwrite: 5
        });
        
    }

    function iMacFireFoxEventListener(event) {
        //TODO: Change position of relevantes elements        
        event.preventDefault();
        var delta = event.wheelDelta / 120 || -event.detail / 3;
        var scrollTop = this.scrollTop;
        var finalScroll = scrollTop - parseInt(delta * scrollDistance);
        TweenLite.to($(this), scrollTime, {
            scrollTo: { y: finalScroll, autoKill: true },
            ease: Power2.easeOut,
            overwrite: 1
        });
    } 

    function iMacChromeEventListener(event) {
        //TODO: Change position of relevantes elements        
        event.preventDefault();
        //event.stopPropagation();
        var delta = event.wheelDelta / 120 || -event.detail / 3;
        var scrollTop = this.scrollTop;
        var finalScroll = scrollTop - parseInt(delta * scrollDistance);
        this.scrollTop = finalScroll;        
    }

    function touchStartEventListener(event) {        
        startX = event.touches[0].pageX;
        startY = event.touches[0].pageY;
        startScrollPosition = this.scrollTop;
    }

    function touchMoveEventListener(event) {
        var deltaX = Math.abs(event.touches[0].pageX - startX);
        var deltaY = Math.abs(event.touches[0].pageY - startY);
        if (deltaY - deltaX > 0) {
            if (event.cancelable) {
                event.preventDefault();
                newScrollPosition = startScrollPosition - (event.touches[0].pageY - startY);
                //loadScrollPositionSlide(this._slide, newScrollPosition);
                this.scrollTo(0, newScrollPosition);
            }           
        }
    }

    function resizeMedia(element) {
        var media = element._media;
        var slide = element.parentElement;
        var h, w, l, mediaHeightMin;
        var aspectRatio = media.naturalWidth / media.naturalHeight;

        mediaHeightMin = media.plx.type == "fixed" ?
            slide.clientHeight :
            (slide.clientHeight) * (1 - media.plx.speedY) + element.clientHeight * media.plx.speedY | 0;
        if (mediaHeightMin * aspectRatio >= element.clientWidth) {
            h = mediaHeightMin;
            w = h * aspectRatio;
        } else {
            w = element.clientWidth;
            h = w / aspectRatio;
        }
        l = (w - element.clientWidth) / -2;

        media.style.width = w + "px";
        media.style.height = h + "px";
        media.style.left = l + "px";
        media.plx.deltaTopForCenter = h > slide.clientHeight ? (h - slide.clientHeight) / -2 : 0;
        loadScrollPositionElement(element);
    }

    function setupStylesForElement(media) {
        var mediaStyle = getComputedStyle(media);
        var mediaParent = media.parentElement;
        var borderWidthInt = parseInt(mediaStyle.borderWidth);
        mediaParent.style.borderColor = mediaStyle.borderColor;
        mediaParent.style.borderWidth = borderWidthInt + "px";
        mediaParent.style.marginLeft = (1 - borderWidthInt) + "px";  // -1 px - because by default in element [div.edit-wrapper] border width = 1px.
        mediaParent.style.marginTop = (1 - borderWidthInt) + "px";  // -1 px - because by default in element [div.edit-wrapper] border width = 1px.
        media.style.borderWidth = "0px";
        media.style.marginLeft = "0px";
        media.style.marginTop = "0px"; 
    }

    function destroyStylesForElement(media) {
        var mediaParent = media.parentElement;
        mediaParent.style.borderColor = null;
        mediaParent.style.borderWidth = null;
        mediaParent.style.marginLeft = null;  
        mediaParent.style.marginTop = null;  
        media.style.borderWidth = null;
        media.style.marginLeft = null;
        media.style.marginTop = null;
    }

    function onLoadMedia(event) {
        var media = event.target;
        if (event !== undefined && event != null) {
            var tag = media.tagName.toLowerCase();
            switch (tag) {
                case "img":
                    media.naturalWidth = event.currentTarget.naturalWidth | 1;
                    media.naturalHeight = event.currentTarget.naturalHeight | 1;
                    break;
                case "video":
                    media.naturalWidth = event.currentTarget.videoWidth | 1;
                    media.naturalHeight = event.currentTarget.videoHeight | 1;
                    break;
                case "iframe":
                    media.naturalWidth = event.currentTarget.width | 1;
                    media.naturalHeight = event.currentTarget.height | 1;
                    break;
                default:
                    media.naturalWidth = event.currentTarget.naturalWidth | 1;
                    media.naturalHeight = event.currentTarget.naturalHeight | 1;
                    break;
            }
            media.plx.loaded = true;
            if (!media.plx.styled) {
                setupStylesForElement(media);                
                media.plx.styled = true;
            }
            resizeMedia(media.parentElement);            
        }
    }

    function onResizeElement(event) {
        resizeMedia(event.target);
    }

    function onResizeSlide(event) {
        var slideId = event.target.dataset.slideId;
        var currentSlide = _parallax.slides.find(function (s) { return s.id == slideId; });
        if (currentSlide) {
            currentSlide.elements.forEach(function (el) {
                resizeMedia(el);
            });
        }
    }

    function setup(reset) {
        if (_parallax.slides.length > 0) {
            _parallax.slides.forEach(function (slide) {
                if (reset || !slide.installed) {
                    if (slide.elements.length > 0) {
                        slide.elements.forEach(function (elm) {
                            var media = elm.querySelector('img, video, iframe');
                            media.plx = {
                                speedY: elm.dataset.parallaxType === "fixed" ? 0 : 0.2,
                                speedZ: elm.dataset.parallaxType === "zoom" ? 0.15 : 0,
                                type: elm.dataset.parallaxType,
                                loaded: false,
                                styled: false,
                                deltaTopForCenter: 0
                            }
                            window.addMultipleEventListener(media, "load loadeddata", onLoadMedia);                           

                            elm._media = media;
                            elm.addEventListener('resize', onResizeElement, false);
                            //resizeMedia(elm);                            
                            var loadEvent = new Event('load');
                            elm.dispatchEvent(loadEvent);
                        });
                    }
                    slide.original.addEventListener('resize', onResizeSlide, false);
                    slide.original.addEventListener('changeclass', onResizeSlide, false);
                    slide.original._slide = slide;
                    slide.installed = true;
                    //loadScrollPositionSlide(slide);
                }
            });
        }
    }

    function destroy() {
        if (_parallax.slides.length > 0) {
            _parallax.slides.forEach(function (slide) {
                if (slide.installed) {
                    if (slide.elements.length > 0) {
                        slide.elements.forEach(function (elm) {                            
                            window.removeMultipleEventListener(elm._media, "load loadeddata", onLoadMedia);
                            elm.removeEventListener('resize', onResizeElement);
                            elm._media.style.width = "100%";
                            elm._media.style.height = "100%";
                            elm._media.style.left = "0px";
                            elm._media.style.top = "0px";
                            elm._media.style.transform = "";
                            destroyStylesForElement(elm._media);
                            delete elm._media.plx;
                            elm._media = undefined;
                            delete elm._media;
                            elm.classList.remove('em-parallax');
                            removeParallaxTypeAttribute(elm);
                        });
                    }
                    slide.original.removeEventListener('resize', onResizeSlide);
                    slide.original.removeEventListener('changeclass', onResizeSlide);
                    delete slide.original.dataset.slideId;
                    slide.original = undefined; 
                }
            });
            _parallax.slides = [];
        }
    }

    function addScrollEventListeners() {
        if (_parallax.slides.length > 0) {
            _parallax.slides.forEach(function (slide) {
                if (!slide.listened) {
                    if (_b.isMobile || _b.isTablet) {
                        slide.original.addEventListener('touchstart', touchStartEventListener, false);
                        slide.original.addEventListener('touchmove', touchMoveEventListener, false);
                    }
                    else if (_b.isMac) {
                        scrollTime = 1.2;
                        scrollDistance = 150;
                        if (_b.isSafari) {

                        } else if (_b.isChrome) {
                            slide.original.addEventListener('mousewheel', iMacChromeEventListener, false);
                        } else if (_b.isFireFox) {
                            slide.original.addEventListener('MozMousePixelScroll', iMacFireFoxEventListener, false);
                        }                        
                    }
                    slide.original.addEventListener('scroll', scrollEventListener, false);

                    slide.listened = true;
                }
            });
        }
    }

    function removeScrollEvents() {
        if (_parallax.slides.length > 0) {
            _parallax.slides.forEach(function (slide) {
                if (slide.listened) {
                    if (_b.isMobile || _b.isTablet) {
                        slide.original.removeEventListener('touchstart', touchStartEventListener);
                        slide.original.removeEventListener('touchmove', touchMoveEventListener);
                    }
                    else if (_b.isMac) {
                        if (_b.isSafari) {

                        } else if (_b.isChrome) {
                            slide.original.removeEventListener('mousewheel', iMacChromeEventListener);
                        } else if (_b.isFireFox) {
                            slide.original.removeEventListener('MozMousePixelScroll', iMacFireFoxEventListener);
                        }
                    }
                    slide.original.removeEventListener('scroll', scrollEventListener);
                    slide.listened = false;
                }
            });
        }
    }

    window.removeAllParallaxEffect = function () {
        if (_parallax.slides.length > 0) {
            removeScrollEvents();
            destroy();            
        }        
    };

    // this fuction need for calling from "player.scene-manager.js" -> func name "setSlides" and set parallax effect to all active elements
    window.setOrUpdateParallaxEffect = function setOrUpdateParallaxEffect() {
        if (window.BrowserAndDeviceInfo.isIE)
            return;
        var elements = getParallaxElements();
        if (elements != null) {
            insertElementsToSlides(elements);
            addScrollEventListeners();
            setup(false);
        }
    };
    window.Parallax = _parallax;
})(jQuery);