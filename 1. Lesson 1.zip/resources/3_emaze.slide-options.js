

var EM = window['EM'] || {};

if (window['EM_Editor']) {

    var emazeApp = window['emazeApp'] || angular.module('emazeApp', ['EmazeSettings', 'EmazeMenus', 'EmazeWidgets']);

    emazeApp.directive('negate', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attribute, ngModel) {
                ngModel.$isEmpty = function (value) {
                    return !!value;
                };
                ngModel.$parsers.unshift(formatter);
                ngModel.$formatters.unshift(formatter);

                function formatter(value) {
                    return !value;
                }
            }
        };
    });




    emazeApp.controller('slideOptionsController', function ($scope) {
        $scope.name = '';
        $scope.scroll_x = false;
        $scope.scroll_y = false;
        $scope.autoPlay = false;
        $scope.excludeFromMenu = false;
        $scope.stopDuration = 0;

        $scope.stopDurationAll = false;

        $scope.getSettings = function () {

            return { name: $scope.name, excludeFromMenu: $scope.excludeFromMenu || false, scroll_x: $scope.scroll_x, scroll_y: $scope.scroll_y, autoplay: $scope.autoPlay, stopduration: $scope.stopDuration };
        }

        $scope.setSettings = function (data) {
            $scope.$apply(function () {
                $scope.name = data.name;
                $scope.excludeFromMenu = data.excludeFromMenu;
                $scope.scroll_x = data.scroll_x || data.scroll; //backwards comp for when it was one property
                $scope.scroll_y = data.scroll_y || data.scroll; //backwards comp for when it was one property
                $scope.autoPlay = data.autoplay;
                $scope.stopDuration = data.stopduration;
                $scope.stopDurationAll = false;
            });
        }
    });
}

EM.slideOptions = (function () {

    var $scrollTarget; //the slide or edit surface that horzontal scroll feature is applied to
    var scroll_l; //left bound of scrollable area
    var scroll_r; //right bound of scrollable area



    function init() {
        attachEventHandlers();
    }

    function setScroll(data, $target) {
        if (EM.isMobileSlides) { //force vertical only in mobile view
            $target.removeClass("sd-page-scroll sd-page-scroll_x").addClass("sd-page-scroll_y");
        }
        else if (data.scroll || (data.scroll_x && data.scroll_y)) {//both
            $target.removeClass("sd-page-scroll_y sd-page-scroll_x").addClass("sd-page-scroll");
        } else if (data.scroll_x) { //horizontal
            $target.removeClass("sd-page-scroll sd-page-scroll_y").addClass("sd-page-scroll_x");
        } else if (data.scroll_y) {  //vertical
            $target.removeClass("sd-page-scroll sd-page-scroll_x").addClass("sd-page-scroll_y");
        } else { //none
            $target.removeClass("sd-page-scroll sd-page-scroll_y sd-page-scroll_x");
        }

    }

    function animateHorizontalScroll(duration, targetVal) {
        console.log('animateHorizontalScroll');
        TweenLite.to($scrollTarget[0], duration / 1000, { scrollTo: { x: targetVal } });

    }

    function scrollRight(e) {
        var x = window.innerWidth + 3 - e.pageX; //+ 3 to elimiate zero and small numbers
        var duration = (x * 30) + $scrollTarget[0].scrollWidth / 7;  //factor in the the distance we need to cover and allow more time for greater distances
        animateHorizontalScroll(duration, $scrollTarget[0].scrollWidth - $scrollTarget.width());
    }

    function scrollLeft(e) {
        var x = e.pageX + 3; //+ 3 to elimiate zero and small numbers
        var duration = (x * 30) + $scrollTarget[0].scrollWidth / 7;  //factor in the the distance we need to cover and allow more time for greater distances
        animateHorizontalScroll(duration, 0);
    }


    function doScroll(e) {
        var x = e.pageX;

        scroll_l = $scrollTarget[0].getBoundingClientRect().left + 100;
        scroll_r = window.innerWidth - scroll_l;

        if (x < scroll_l) {
            scrollLeft(e);
        } else if (x > scroll_r) {
            scrollRight(e);
        } else {
            endScroll();
        }
    }

    function endScroll() {
        TweenLite.killTweensOf($scrollTarget[0]);
    }

    function toggleHorizontalScroll(isScroll, $target) {

        if (!$target || !$target.length) {
            console.error('invalid $target', $target);
            return;
        }
        if ($target.css('overflow-x') === 'hidden') {

            isScroll = false;
        }

        $scrollTarget = $target; //external scope var to be acessed in mouse move events
        scroll_l = $scrollTarget[0].getBoundingClientRect().left + 100;
        scroll_r = window.innerWidth - scroll_l;

        if (isScroll && $target[0].scrollWidth > $target.width()) {
            $(document).on('mousemove', doScroll);
        } else {
            $(document).off('mousemove', doScroll);
        }
    }

    function enusreUniqueSlideName($slide) {
        var name = $slide.attr('data-name') || 'untitled';
        var newName = name;
        var isNameTaken;
        var nameIsNumber;
        var numericSuffix;

        isNameTaken = $('#slide-container .slide').not($slide).filter('[data-name="' + name + '"]').length;

        if (!isNameTaken) {
            $slide.data('name', name).attr('data-name', name); //might be redundant and not necessary. added just in case
            return name;
        }

        nameIsNumber = !isNaN(name);

        if (!nameIsNumber) {
            numericSuffix = (name.match(/(\d+)$/) || [''])[0];
            if (numericSuffix) {
                name = name.substring(0, name.length - numericSuffix.length);
            }
        } else {
            numericSuffix = Number(name);
        }

        for (var i = numericSuffix ? parseInt(numericSuffix) : 1; i < 10000; i++) { //get the number from the end of string, or default to one

            isNameTaken = $('#slide-container .slide').not($slide).filter('[data-name="' + newName + '"]').length;
            if (isNameTaken) {
                newName = nameIsNumber? (numericSuffix + 1) : (name + i);
            } else {
                $slide.attr('data-name', newName).data('name', newName);
                return newName;
            }

        }

    }

    function updateLinksToSlide(oldName, name) {
        $(':not(.em-menu) .sd-slide-link[href="#slidename=' + oldName + '"]').attr('href', '#slidename=' + name ); //update and links to slide inslide fo the slides/edit surface

    }

    function saveSettingsToSlide() {
        var $slide = EM_SlideManager.getSelectedSlide();
        var scope = EM.slideOptionsControllerScope();
        var settings = scope.getSettings();
        var prev = {
            name: $slide.attr('data-name'),
            exclude: $slide.attr('data-exclude-from-menu') === 'true'
        }
        var $allSllides = $('#slide-container .slide');


        $slide.data(settings).attr({ 'data-name': settings.name, 'data-exclude-from-menu': settings.excludeFromMenu, 'data-scroll_x': settings.scroll_x, 'data-scroll_y': settings.scroll_y, 'data-autoplay': settings.autoplay, 'data-stopduration': settings.stopduration }).removeAttr('data-scroll').removeData('scroll'); //remove depreciated property

        settings.name = enusreUniqueSlideName($slide);

        updateLinksToSlide(prev.name, settings.name);

        //if (prev.exclude !== (settings.excludeFromMenu || false)) {
        //    if (settings.excludeFromMenu) { 
        //        EM.navMenuManager.removeSlideItem($slide, false);
        //    } else {
        //        EM.navMenuManager.addSlideItem($slide, false);
        //    }
        //} else if (!settings.excludeFromMenu /* && (prev.name !== settings.name)*/) {  //update. not checking if unchanged, because there may be a rare case where   settings.name = enusreUniqueSlideName($slide); will change its back to equal prev.name
        //    EM.navMenuManager.updateSlideItemName(prev.name, settings.name);
        //}


        //the most stable, concise approach. 
        if (settings.excludeFromMenu) {
            EM.navMenuManager.removeSlideItem($slide, false, prev.name);
        } else { //add and update, eliminating the need to check which one to do. add will only add it if its not already there
            EM.navMenuManager.updateSlideItemName(prev.name, settings.name);
            EM.navMenuManager.addSlideItem($slide, false);
        }
         

        if (scope.stopDurationAll) {
            $allSllides.each(function () {
                $(this).data('stopduration', settings.stopduration).attr('data-stopduration', settings.stopduration);

            });
        }
        setScroll(settings, EM_Document.$editSurface);
        EM_Menu.setSavedStatus(false);
    }

    function loadSettingsFromSlide() {
        EM.slideOptionsControllerScope().setSettings(EM_SlideManager.getSelectedSlide().data());
    }

    function attachEventHandlers() {
        $('#slide-options-form').emazeDialog('init', { title: EM.contentType === 6 ? 'Page Options' : 'Slide Options', okText: 'APPLY', okFunc: saveSettingsToSlide, cssClass: 'slide-options' });

        $('#slide-container').on('click', '.menu-slide', function () {
            loadSettingsFromSlide();
            $('#slide-options-form').emazeDialog('show');

            $("#scene").one('transitionStart', function () { //hide the dialog if user changes slide
                $('#slide-options-form').emazeDialog('close');
            });
        });

    }

    function setSlideToScrollVerticalInEditor() {
        var $slide = EM_SlideManager.getSelectedSlide();

        if (!$slide.is('[data-scroll="true"], [data-scroll_y="true"]')) {
            $slide.attr('data-scroll_y', true);
            $slide.data('scroll_y', true);
            setScroll({ scroll_y: true }, EM_Document.$editSurface);
            return true;
        } 
        else {
            if ( $slide[0].scrollHeight > $slide.height() ) // If we have scroll in the slide return false (not to add the text). in editor.custom-effects.js
                return false;
            else
                return true;
                //return $slide[0].scrollHeight < 1080 * 2;
        }
    }


    return {
        init: init,
        loadSettingsFromSlide: loadSettingsFromSlide,
        setScroll: setScroll,
        toggleHorizontalScroll: toggleHorizontalScroll,
        animateHorizontalScroll: animateHorizontalScroll,
        setSlideToScrollVerticalInEditor: setSlideToScrollVerticalInEditor,
        enusreUniqueSlideName: enusreUniqueSlideName,
        updateLinksToSlide: updateLinksToSlide
    }

})();






EM.navMenuManager = (function () {

    var context = { isEditor: window['EM_Editor'] ? true : false };
    var manager = {};

    manager.menu = { name: '', items: [], config: {} }; //the menu object, same as that stored in the slide deck

    $(window).one('emaze-navMenu-ready', function () {

        $('#wrapper').on('dblclick', '.em-menu', openMenuEditor);

    });

    $(window).one('emaze-navMenu-ready', function () {

        $('#wrapper').on('click', '.em-menu-link', function (e) {
            e.preventDefault();
        });

        //TODO make more efficient by handlign cliks less often
        $('body').on('click', '.em-menu[data-autoclose] .em-menu-link', function () {
            if (window['EM_NavMenu']) {
                EM_NavMenu.close();
            }
        });

    });

    $(window).on('emaze-navMenu-ready', function () {

        //generate menu items for first time if there were none before.
        if (context.isEditor && !manager.menu.items.length) {
            $('#slide-container .slide').each(function () {
                addSlideItem($(this), true);
            });
        }

        EM_NavMenu.init(context.isEditor ? '#wrapper' : '#main-container', manager.menu);

        manager.configurator.setConfig();

        $('.em-menu').off('click', '.em-menu-item', selectMenuItem).on('click', '.em-menu-item', selectMenuItem);
    });

    function selectMenuItem() {
        $('.em-menu-item').removeClass('selected');
        $(this).addClass('selected');
    }

    function openMenuEditor() {
        $('[ui-view="menus"]').scope().$state.go('menus');
    }

    function updateItemsHref() {
        var $slide, $target;
        manager.menu.items.forEach(function (item, index) {


            if (isTargetItem(item)) {

                $target = $('#slide-container [data-element-link-id="' + item.name + '"]');
                if ($target.length) {
                    item.slideNum = EM_SlideManager.getSLideWrapperIndex($target.closest('.slide-wrapper')) + 1;
                    item.href = '#' + item.name;
                } else {
                    manager.menu.items.splice(index, 1); //remove the link since there is nothing to link to
                    console.error('menu item references a missing target', item.name);
                }

            } else {
                $slide = $('#slide-container [data-name="' + item.name + '"]');
                if ($slide.length) {
                    item.href = '#' + (EM_SlideManager.getSLideWrapperIndex($slide.closest('.slide-wrapper')) + 1);
                } else {
                    manager.menu.items.splice(index, 1); //remove the link since there is nothing to link to
                    console.error('menu item references a missing slide', item.name);
                }
            }

        });
        manager.updateMenuItems();
    }

    manager.getUpdatedMenu = function () {
        updateItemsHref();
        return manager.menu;
    }

    function addTargetItem($item) {
        //  var slideNum = EM_SlideManager.getSLideWrapperIndex($this.closest('.slide-wrapper')) + 1;
        var id = $item.attr('data-element-link-id');

        var exists = manager.menu.items.find(function (item) { return item.name === id && isTargetItem(item) });
        if (!exists) {
            manager.menu.items.push({ name: id, slideNum: 1, href: '#' + id }); //slidenum will be corrected upon save, once final slide location is known
        }
    }

    manager.addTargetItem = function ($item) {
        addTargetItem($item);
        manager.updateMenuItems();
    }

    manager.removeTargetItem = function (name) {

        if (name) {

            var items = manager.menu.items.filter(function (item) {
                return !isTargetItem(item) || (item.name !== name);
            });

            manager.updateMenuItems(items);

        }
    }

    manager.updateTargetItemName = function (name, newName) {
        var item;

        for (var i = 0; i < manager.menu.items.length; i++) {
            item = manager.menu.items[i];

            if (item.name === name && isTargetItem(item)) {
                item.name = newName;
                manager.updateMenuItems(manager.menu.items);
                return;
            }
        }
    }

    function addSlideItem($slide, addTargetsInSlide) {


        var name = $slide.attr('data-name') || EM.slideOptions.enusreUniqueSlideName($slide); //TODO handle missing name

        var exists = manager.menu.items.find(function (item) { return item.name === name && !isTargetItem(item) });

        if (!exists && $slide.attr('data-exclude-from-menu') !== 'true') {
            manager.menu.items.push({ name: name, href: '#' }); //href will be corrected upon save, once final slide location is known
        }
        if (addTargetsInSlide) {
            //sort targets by slide, then by top position
            $slide.find('[data-include-in-menu="true"]').sort(EM_Menu.sort_by_top).each(function () { addTargetItem($(this)) });
        }
    }

    manager.addAllTargetsInContainer = function ($container) {
        $container.find('[data-include-in-menu="true"]').sort(EM_Menu.sort_by_top).each(function () { addTargetItem($(this)) });
        manager.updateMenuItems();
    }

    manager.addSlideItem = function ($slide, addTargetsInSlide) {
        addSlideItem($slide, addTargetsInSlide);
        manager.updateMenuItems();
    }

    manager.removeSlideItem = function ($slide, removeTargetsInSlide, name) {

        name = name || $slide.attr('data-name');

        var items = manager.menu.items;


        if (name) {
            items = items.filter(function (item) {
                return isTargetItem(item) || (item.name !== name);
            });
        }

        if (removeTargetsInSlide) {
            var names = $slide.find('[data-include-in-menu="true"]').map(function () {
                return $(this).attr('data-element-link-id');
            }).get();

            if (names.length) {
                items = items.filter(function (item) {
                    return !(isTargetItem(item) && names.indexOf(item.name) !== -1);
                });

            }
        }

        manager.updateMenuItems(items);
    }

    manager.updateSlideItemName = function (name, newName) {
        var item;

        for (var i = 0; i < manager.menu.items.length; i++) {
            item = manager.menu.items[i];

            if (item.name === name && !isTargetItem(item)) {
                item.name = newName;
                manager.updateMenuItems(manager.menu.items);
                return;
            }
        }
    }

    manager.loadMenu = function (menu) {
        if (menu) {

            manager.unloadMenu(); //ensure removal of pre-existing menu

            manager.menu.name = menu.name || '';
            manager.menu.items = menu.items || [];
            manager.menu.config = menu.config || {};

            if (manager.menu.name) {
                manager.menuUrl = getMenuUrl(manager.menu);
                appendScript('nav-menu-resource', manager.menuUrl + '.js');
                appendLink('nav-menu-resource', manager.menuUrl + '.css');
            } 
        }

    }
    manager.getMenu = function () {
        var mergedArr = []; // all the visible menu items and not visible 
        mergedArr = manager.getAllVisibleMenuItemsByOrder(); // get all the visible menu items (targets or slides).
        Array.prototype.push.apply(mergedArr.items, manager.getExcludeIncludMenuAndTargets()); // add all the excluded and included targets and slides to the mergedArr .
        return mergedArr;
    }
    /**
     * @description Gets all the excluded and the included targets (data-exclude-from-menu=true , include-in-menu=true/false/null,).
     * [data-element-link-id] is the name of the target to check. we add only those who are false or null.
     * called from editor.feature.menu.js.
     * @returns {arrOfMenuNames: Array  -> all the menu and target items that are not included in the menu} 
     */
    manager.getExcludeIncludMenuAndTargets = function() {
        var arrOfMenuNames = [];// {href: "#i", name :"data-name" ,includeInMenu: false}
        $('#slide-container [data-exclude-from-menu="true"]').each(function (index) { // get all the names of the menus that are not visible in the menu bar.
            var name = $(this).attr("data-name");// get the slide name.
            arrOfMenuNames.push({
                href: "#",
                name: name,
                oldName: name,
                includeInMenu: false
            });
        });

        $('#slide-container [data-element-link-id]').each(function (index) { // get all the names of the targets that are not visible in the menu bar.
            var $this = $(this);
            //var includedInMenuAlready = false;
            var include = $this.attr("data-include-in-menu");
            var name;
            if (!include || include === "false") { // if there is attribute data-include-in-menu = true/false
                name = $this.attr("data-element-link-id");
                arrOfMenuNames.push({
                        href: "#" + name,
                        name: name,
                        oldName: name,
                        includeInMenu: false,
                        slideNum : 1 // if element got slideNum its a target!!!!!
                });
            }
                      //arrOfMenuNames.push({ href: "#", name: $(this).attr("data-element-link-id"), includeInMenu: includedInMenuAlready, dataUid: $(this).attr("data-uid"), type: "target" });
        });

        return arrOfMenuNames;
    }
    /**
     * @description get additional information for each menu (all the visible menu items) for example if it's a link or slide. called from editor.feature_menu.js
     * @param {} arr : array of objects 
     * @returns {Array: -> of the objects with additional information} 
     */
    manager.getAllIncludedMenuAndTargetsItems = function(arr) {
        var visibleMenuItemsArr = [];
        $('#slide-container [data-exclude-from-menu="false"]').each(function (index) { // get all the names of the menus that are visible in the menu bar.
            var name = $(this).attr("data-name");// get the slide name.
            visibleMenuItemsArr.push({
                href: "#",
                name: name,
                oldName: name,
                includeInMenu: true
            });
        });
        $('#slide-container [data-element-link-id]').each(function(index) {
            var $this = $(this);
            var include = $this.attr("data-include-in-menu");
            var name;
            
            if (include === "true") { // if data-include-in-menu = true
                name = $this.attr("data-element-link-id");
                visibleMenuItemsArr.push({
                    href: "#" + name,
                    name: name,
                    oldName: name,
                    includeInMenu: true,
                    slideNum: 1 // if element got slideNum its a target!!!!!
                
                });
            }
        });
        
    }
    /**
     * @description This function copies the menu object, adds additional information for emaze.feature-menu.js screen.
     * @param {}  
     * @returns {menu obj {} with additional information } 
     */
    manager.getAllVisibleMenuItemsByOrder = function() {
        var originaMenuObject = JSON.parse(JSON.stringify(manager.menu));// originaMenuObject ->{ name: '', items: [], config: {} } creates a deep copy! will not copy function or events.
        //var originaMenuObject = $.extend(true, {}, manager.menu);// originaMenuObject ->{ name: '', items: [], config: {} }
        var $slide, $target;

        originaMenuObject.items.forEach(function(item, index) {

            if (isTargetItem(item)) { // it's a target

                $target = $('#slide-container [data-element-link-id="' + item.name + '"]');
                if ($target.length && $target.attr("data-include-in-menu") === "true") {// add the additional information to the object 
                    item.oldName = item.name;
                    item.includeInMenu = true;

                } else { 
                    //manager.menu.items.splice(index, 1); //remove the link since there is nothing to link to
                    console.error('menu item references a missing target!!! problem with the menu', item.name);
                }

            } else {// it's a slide
                $slide = $('#slide-container [data-name="' + item.name + '"]');
                if ( $slide.length && $slide.attr("data-exclude-from-menu") === "false" ) { 
                    item.oldName = item.name;
                    item.includeInMenu = true;
                } else {
                    //manager.menu.items.splice(index, 1); //remove the link since there is nothing to link to
                    console.error('menu item references a missing slide!!! problem with the menu' , item.name);
                }
            }


        });
        return originaMenuObject;
    }
    /**
     * @description Updates slide/targets names, and hide/unhide items in the menu.
     * @param {} itemsArr 
     * @returns {} 
     */
    manager.setIncludeExcludeAndMenuOrTargetsNames = function(itemsArr) {

        //index: 
        // target has include-in-menu = true/false or doesn't exists.
        // target name: is data-element-link-id.
        // slide has data-exclude-in-menu= true/false.
        // slide name: is data-name

        var $slide, $target, $editSurfaceTarget, $bothWrappers;
        itemsArr.forEach(function (item, index) {
            if (isTargetItem(item)) {// if it's a target.
                $target = $('#slide-container [data-element-link-id="' + item.oldName + '"]');// slidedeck target
                $editSurfaceTarget = $('#wrapper #edit-area #edit-surface [data-element-link-id="' + item.oldName + '"]');
                $bothWrappers =  $target.add($editSurfaceTarget);

                if ($target.length) { // if exists
                    item.name = EM.links.incrementLinkIdUntillUnique($bothWrappers, item.name);// check if the name exists if it does change it.
                    //todo need to do something if the user enters null in the input
                    if (item.name !== item.oldName) {// if the user changed the name of the target at the menu screen.
                        EM.links.updateLinkId($bothWrappers, item.oldName, item.name);
                    }
                    if (item.includeInMenu !== $target.data('include-in-menu')) {// if the includeInMenu changed by the user
                        if (item.includeInMenu) { // if the user set it to be included in the menu.
                            $bothWrappers.attr("data-include-in-menu", true);

                            //    manager.addTargetItem($bothWrappers);


                        } else {//the user removed 
                            $bothWrappers.attr("data-include-in-menu", false);

                            //manager.removeTargetItem(item.name);
                        }
                    }
                }
            }
            else {// its a slide
                $slide = $('#slide-container [data-name="' + item.oldName + '"]'); // get the old name
                if ($slide.length) { // if exists

                    //$slide.data('exclude-from-menu') !== !item.includeInMenu the logic is in reverse. data-exclude-from-menu = false ==== item.includeInMenu = true.
                    if (item.name !== item.oldName || $slide.data('exclude-from-menu') !== !item.includeInMenu) { // if the user changed the name or hide/unhide the menu at the menu screen.                    }
                        $slide.attr("data-name", item.name).data('name', item.name); // update the slide name
                        $slide.attr("data-exclude-from-menu", !item.includeInMenu).data('exclude-from-menu', !item.includeInMenu);// update data-exclude-from-menu to what the user picked.
                       
                        item.name = EM.slideOptions.enusreUniqueSlideName($slide);
                       
                        EM.slideOptions.updateLinksToSlide(item.oldName, item.name);

                        //if (item.includeInMenu === false) { // same logic as in saveSettingsToSlide()
                        //    manager.removeSlideItem($slide, false);
                        //} else { //add and update, eliminating the need to check which one to do. add will only add it if its not already there
                        //    manager.updateSlideItemName(item.oldName, item.name);
                        //    manager.addSlideItem($slide, false);
                        //}
                        
                    }
                    
                }

            }
        });
        EM_Menu.setSavedStatus(false);

    }


    /*  if (settings.excludeFromMenu) {
                EM.navMenuManager.removeSlideItem($slide, false);
            } else { //add and update, eliminating the need to check which one to do. add will only add it if its not already there
                EM.navMenuManager.updateSlideItemName(prev.name, settings.name);
                EM.navMenuManager.addSlideItem($slide, false);
            }  */

    /**
     * 
     * @param {} itemsArr 
     * @returns {} 
     */
    manager.cleanMenuItemsExtraProps = function(itemsArr) {
        
    }
        
    

 
    manager.updateMenuItems = function (items) {
        if (items) {
            manager.menu.items = items.slice();
        }
        if (window['EM_NavMenu']) { //else, will happen on menu ready
            EM_NavMenu.setItems(manager.menu.items);
        }
    }


    manager.updateMenu = function (menu) {

        var prevName = manager.menu ? manager.menu.name : '';

        manager.menu = $.extend({}, menu);

        if ((prevName !== manager.menu.name) || !window['EM_NavMenu']) {
            manager.loadMenu(manager.menu); //load a new menu
        } else { //update existing menu
            EM_NavMenu.setItems(manager.menu.items);
            manager.configurator.setConfig(manager.menu.config);
        }

        if (!menu.name) {
            manager.menu.items = [];
        }
    }

    manager.unloadMenu = function () {
        var cssLink = $('link.nav-menu-resource')[0];

        if (window['EM_NavMenu']) {
            EM_NavMenu.close();
            EM_NavMenu.destroy();
            manager.configurator.removeStyleTag();
        }

        if (cssLink) {
            (cssLink.sheet || cssLink.styleSheet).disabled = true;
        }

        $('script.nav-menu-resource, link.nav-menu-resource').remove();
    }

    //#region internal functions

    function isTargetItem(item) {
        return item.slideNum !== undefined;
    }

    function appendScript(className, src, isAsync) {
        var script = document.createElement('script');

        script.className = className;
        script.setAttribute('src', src);
        script.async = isAsync || false;
        document.body.appendChild(script);

    }

    function appendLink(className, href) {
        var head = document.getElementsByTagName('head')[0],
            link = document.createElement('link');

        link.className = className;
        link.href = href;

        link.rel = 'stylesheet';
        link.type = 'text/css';

        head.appendChild(link);
    }

    function getResourcesUrl() {
        return window.location.href.indexOf('//localhost') === -1 ? (EM.resourcesURL || resources) : '/resources';
    }

    function getMenuUrl(menu) {
        return getResourcesUrl() + '/menus/' + menu.name + '/menu'; //for local host convenience
      //     return (EM.resourcesURL || resources) + '/menus/' + menu.name + '/menu';
    }

    //#endregion


    manager.configurator = (function () {
        var configurator = {};

        function deCase(s) {
            return s.replace(/[A-Z]/g, function (a) { return '-' + a.toLowerCase() });
        }

        function deeptest(target, s) {
            // slightly modified version, original by http://stackoverflow.com/users/80860/kennebec
            s = s.split('.');
            var obj = target[s.shift()];
            while (obj && s.length) obj = obj[s.shift()];
            return obj;
        }

        function generateCssRule(selector, setting) {

            var properties = (isConfigured(setting));

            if (properties) {

                return Object.keys(properties).reduce(function(previous, key) {
                            return previous + deCase(key) + ':' + properties[key] + ';\n';
                        },
                        selector + '{\n') +
                    '\n}';

            }
            return '';
        }

        function isConfigured(property) {
            return deeptest(manager.menu.config, property);
        }

        configurator.removeStyleTag = function() {
            if (configurator.styleTag) {
                configurator.styleTag.sheet.disabled = true;
                $(configurator.styleTag).html('').remove();
                configurator.styleTag = null;
            }
        }

        function updateStyleTag() {
            var css,
                head = document.head || document.getElementsByTagName('head')[0];

            configurator.removeStyleTag();

            configurator.styleTag = document.createElement('style');
            configurator.styleTag.type = 'text/css';
            //configurator.styleTag.id = 'nav-menu-style';

            css = [generateCssRule('.em-menu-item', 'items.normal'),
                   generateCssRule('.em-menu-item:hover', 'items.hover'),
                   generateCssRule('.em-menu-item.selected, .em-menu-item.selected:hover', 'items.selected'),
                   generateCssRule('.em-menu', 'container.css')
            ].join('\n');


            if (configurator.styleTag.styleSheet) {
                configurator.styleTag.styleSheet.cssText = css;
            } else {
                configurator.styleTag.appendChild(document.createTextNode(css));
            }
            head.appendChild(configurator.styleTag);
        }


        configurator.setConfig = function() {

            var config = manager.menu.config; //for brevity;

            if (config) {

                $('.em-menu-hover-effect').remove();
                if (isConfigured('effect')) {
                    appendLink('em-menu-hover-effect', getResourcesUrl() + '/menus/hover-effects/' + config.effect + '.css');
                }

                if (isConfigured('container.fontName')) {
                    $('.em-menu').cleanClass('sd-text-font-family_', 'sd-text-font-family_' + manager.menu.config.container.fontName);
                }

                   // $('.em-menu').removeClass('sd-text-font-family_' + manager.menu.config.container.fontName);
               

                if (isConfigured('container.css.fontSize')) {
                    manager.menu.config.container.css.fontSize = parseInt(config.container.css.fontSize) + 'px';
                }

                updateStyleTag();

                if (isConfigured('container.fontName')) {
                    $('.em-menu').addClass('sd-text-font-family_' + manager.menu.config.container.fontName);
                }

              

                if (isConfigured('container.location')) {

                    EM_NavMenu.setLocation(manager.menu.config.container.location);
                }

                if (EM_NavMenu.updateConfig) { //execute the specific update config function of the menu,. if defined.
                    EM_NavMenu.updateConfig(configurator, config);
                }
            }
        }

        configurator.isConfigured = isConfigured;

        return configurator;

    }());

    return manager;

}());


(function ($) { //adding it here (copied from vb.plugins.js) to make sure its in all pages that need here - in this case, the player.
    $.fn.extend({
        cleanClass: function (wildcard, classToAdd) {
            return this.each(function () {

                var $element = $(this);
                var classes, classStr = $element.attr('class');

                if (classStr) {

                    classes = classStr.split(' ');

                    if (wildcard) {
                        for (var i = classes.length; i > -1; i--) {
                            if (typeof classes[i] == "undefined") {
                                continue;
                            }
                            if (classes[i].indexOf(wildcard) != -1) {
                                classes.splice(i, 1); //remove all classes that contain the wildcard string out of the class array
                            }
                        }
                    }
                    if (classToAdd) {
                        classes.push(classToAdd);
                    }
                    $element.attr('class', classes.join(' '));
                } else {
                    $element.attr('class', classToAdd);
                }

            });
        }
    });
})(jQuery);









