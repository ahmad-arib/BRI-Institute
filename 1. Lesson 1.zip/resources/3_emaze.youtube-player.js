
window.EM_YoutubePlayer = (function () {
    var globals = {
        isTransitionHandled: false, //ensures handling only once in case a bug in the scene fires multiple transition done events
        $scene: $(),
        isReady: false,  
        playerList: { items: {}}, // nd object containing references to all of the youtube players on the page.
        enabled: true
    }
   


    function initializeYoutube() {
        var tag = document.createElement('script');
        tag.id = 'iframe-demo';
        tag.src = 'https://www.youtube.com/iframe_api';
        var firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

        window.onYouTubeIframeAPIReady = function () {
            globals.isReady = true;
        }
    }
    initializeYoutube();

    function getVideoElementsFromSlide($slide) {
        return $slide.find('.sd-element-video');
    }
   
    function stopVideoPlayers() {
        Object.keys(globals.playerList.items).forEach(function (key) {
            globals.playerList.items[key].rewind();
        });
    }


    function disable() {
        globals.enabled = false;
        stopVideoPlayers();
    }
    function enable() {
        globals.enabled = true;
    }

  function onTransitionStart() {
      globals.isTransitionHandled = false;
      stopVideoPlayers();
  }

  function onPlayerReady(event) { //not using autoplay url param to prevent uniented playback and to prevent need for reloding the video on each return to the slide.
      var iframe = event.target.getIframe(); //play it when ready if its in the current active slide

      var playerWrapper = globals.playerList.get(iframe.id);
          playerWrapper.isReady = true;
      if (globals.enabled && playerWrapper.autoplay && $(iframe).closest('.current-active-slide')) { //in case we lets the slide by the time that the player was ready
          playerWrapper.player.playVideo();
      }

      if (playerWrapper.mute) {
          playerWrapper.player.setVolume(0);
      }
  }

  function PlayerWrapper(iframe){
      this.player = new YT.Player(iframe.id, { events: { 'onReady': onPlayerReady } });
      this.autoplay = iframe.getAttribute('data-videoautoplay') === 'true';
      this.startTime = iframe.getAttribute('data-start') || 0;
      this.mute = iframe.getAttribute('data-mute') === 'true';
      this.isReady = false; //set to true on player ready event
      this.iframe = iframe;
  }


  PlayerWrapper.prototype.isValid = function () {
      if (this.player.getIframe().contentWindow) {
          return true;
      }
      return false;
  }

  PlayerWrapper.prototype.rewind = function () {
      try {
      if (this.isValid()) {
          this.player.pauseVideo();
          //this.player.seekTo(this.startTime);
          //setTimeout(this.player.pauseVideo, 100); //a second pause to keep iit from playing after seekto: caused errors
      }
      } catch (e) {
          console.warn(e);
      }
  }

  globals.playerList.get = function (id) {
      var key = 'p' + id;
      return this.items[key];
  }

  globals.playerList.add = function (iframe) {
      var playerWrapper = this.get(iframe.id);

      if (playerWrapper) {
          playerWrapper.player.destroy(); //must kill before adding existing player again
      }
      this.items['p' + iframe.id] = new PlayerWrapper(iframe);
  }



    function onTransitionDone(e, slideNum) {
        var $slide;
        var $videoElements;
        try {
            if (globals.isTransitionHandled) {
                return; //don't handle twice
            }
            globals.isTransitionHandled = true;

            $slide =   scene.getCurrentSlide();

            console.log($slide);

            if (!$slide || !$slide.length) {
                return;
            }

            $videoElements = getVideoElementsFromSlide($slide);

            $videoElements.each(function (i, iframe) {
                var playerWrapper;

                if (!this.getAttribute('src')) {
                    this.setAttribute('src', this.getAttribute('data-src'));
                }
                //ensure jsapi param
                var src = this.getAttribute('src');
                if (src.indexOf('enablejsapi=1') === -1) {

                    if (src.indexOf('?') === -1) {
                        src += '?enablejsapi=1';

                    } else {
                        src += '&enablejsapi=1';
                    }
                    this.setAttribute('src', src);
                }


                if (!this.getAttribute('id')) {
                    this.setAttribute('id', slideNum + '_' + $(this).closest('[data-uid]').attr('data-uid'));
                }

                playerWrapper  = globals.playerList.get(this.id);

                if (!(playerWrapper && playerWrapper.isValid())) {
                    globals.playerList.add(iframe);
                } else if (playerWrapper.isReady ) {

                    if (playerWrapper.mute) {
                        playerWrapper.player.setVolume(0);
                    }
                    if (playerWrapper.autoplay) {
                        playerWrapper.player.playVideo();
                    }
                }
            });

        } catch (e) {

            console.log(e);
            $.post("/present/logError", { source: "emaze.youtube-player.js/onTransitionDone", message: e });
        }
    }

    $(document).ready(function () {
        globals.$scene = $('#scene');

        globals.$scene.on('transitionDone', onTransitionDone);
        globals.$scene.on('transitionStart', onTransitionStart);

        globals.isSet = globals.$scene.length > 0;
    });

    function setTransitionEventsForYoutube() {
        if (!globals.isSet) {
            globals.$scene = $('#scene');

            globals.$scene.on('transitionDone', onTransitionDone);
            globals.$scene.on('transitionStart', onTransitionStart);
        }
    }

    function wipeVideoPlayersSource() {
        //this function serves the editor, which can ensure that vidoes wil nevel play when player of editor is hidden.
       //  the  stopVideoPlayers function doues player.seekto which causes it to play for some reason.

    }

    return {
        stopVideoPlayers: stopVideoPlayers,
        setTransitionEventsForYoutube: setTransitionEventsForYoutube,
        globals: globals,
        disable: disable,
        enable:enable
    }
})();