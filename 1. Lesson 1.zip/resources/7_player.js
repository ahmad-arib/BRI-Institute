
var EM = EM || {};

EM.player = (function ($) {

    function mobileAndTabletcheck() {
        var check = false;
        (function (a) { if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true; })(navigator.userAgent || navigator.vendor || window.opera);
        return check;
    };

    // Globals
    var firstLoad = true, //indicate if player loaded already or not
        options = {
            navigateViaHashChange: true
        },
        isEventServer = true, // if 'True' it's mean that works event server, if 'False' - works Local Event Server (change by hand)
        pastSlideNumber = 0,
        presentSlideNumber = getSlideNumber(), //Set hash value if exists as slide num, 1 if not. 
        //IPORTANT: getSlideNumber() DEPENDS ON OPTIONS OBJECT ABOVE
        // presentSlideNumber = getSlideNumber(), //Set hash value if exists as slide num, 1 if not. 
        sectionsSize = 0, //total number of sections - set in sceneIsReady()
        slidesSize = 0, //total number of slides - set in sceneIsReady()
        slidedeck = null, //slidedeck object, init when scene is ready
        $currentSlide = null,
        isAutoplay = false, //permission to autoplay
        isPlaying = false, //show if autoplay active,
        isAutoplayButtonClicked = false,
        defaultStopDuration = 4, //default duration in autoplay   **IMPORTANT:  if thisis ever changed it must also be changed in  apicontroller/getPresentationLength
        isFullscreen = false,
        showingSections = false, //does the sections screen showing
        hash = window.location.hash, //keep hash parameters
        timeout = null, //GUI hide timeout
        mouseThreshold = 0,
        infoTimeout = null,
        isReload = false, //Are we in reload process
        isSharePopUpShowing = false, //Does the social share pop up showing
        limitShowInDesktop = false,
        viewDurationStart = 0,
        prevSlideNumberForAnalytics = 0,
        keyusername = null,
        keyusernameflag = false,
        isOfflineAnalytics = false,
        OFFLINE_ANALYTICS_KEY = presentationId + '_offline_analytics',
        overRideHideControls = checkURLParam('dont-hide-controls'),
        ezContentType = null,
        context = { //where the player window is playing
            isStandalone: false,
            isPresentationPage: false,
            isEditor: false,
            isMyPres: false,
            isOffline: false,
            isStatic: false,
            isMobile: false,
            isIos: false,
            isPrezuTube: false,
            init: function () {
                try {
                    if (window.parent === window) {
                        this.isStandalone = true;
                    } else if (isPresentationPage()) {
                        this.isPresentationPage = true;
                    } else if (window.parent.EM_MyPresentations) {
                        this.isMyPres = true;
                    } else if (window.parent.EM_Editor) {
                        this.isEditor = true;
                    }
                } catch (e) {
                    //error here is a way of determening that its an embedded player outside of emaze.
                }
                this.isOffline = $('html').data('offline') === true;
                this.isStatic = $('html').data('static') === true;
                this.isMobile = EM.isPublished || EM.isLayoutsPlayer ? mobileAndTabletcheck() : window.location.href.indexOf("/mobile/") !== -1;
                this.isIos = /iPad|iPhone|iPod/.test(navigator.userAgent);
                this.isPrezuTube = window.location.href.indexOf("isprezitube") !== -1;
            }
        };


    if (!context.isEditor && EM.isPublished) {
      // its class with hidden in html
    }
    else {
        $('#player-loader').removeClass('hidden');
    }

    // add class for mobile view when page was published or in the preview and from mobile and it is website
    if ((EM.isPublished || EM.isLayoutsPlayer) && mobileAndTabletcheck() && EM.isWebsite) {
        EM.isMobileSlides = true;
        $('body').addClass('mobile-emaze');

        $('#buttonsPanel').remove(); //no navigation buttons in mobile slides  player
    }

    if (EM.compatibility.getDevice() == 'mobile' || EM.compatibility.getDevice() == 'tablet') {
        options.navigateViaHashChange = false;
    }


    function browserPrefix(prop, val) {
        var result = {};
        ['-webkit-', '-moz-', '-ms-', ''].forEach(function (prefix) {
            result[prefix + prop] = val;
        });
        return result;
    }

    function setScale($element, scaleFactor) {
        $element.css(browserPrefix('transform', 'scale(' + scaleFactor + ')'));
    }

    // user info from url for Analytics

    function GetUserName() {
        var keyUN = GetParameterFromUrl('kun0|');

        if (keyUN != null) {
            $.post("/present/ConvertUserName", { key: keyUN }, function (result) {
                keyusername = result;
                keyusernameflag = true;
            });
        }
    }
    function GetParameterFromUrl(sParam) {
        var lenParameter = sParam.length;
        var sPageURL = window.location.search.substring(1);
        var hasQind = sPageURL.indexOf("?");
        if (hasQind != -1) {
            sPageURL = sPageURL.substring(0, hasQind);
        }
        var sURLVariables = sPageURL.split('&');
        var start = sParam;
        var end = start.indexOf('kun0|') != -1 ? reverse(sParam) : null;
        var i;
        if (end != null) {
            for (i = 0; i < sURLVariables.length; i++) {
                if (sURLVariables[i].indexOf(start) != -1 && sURLVariables[i].indexOf(end) != -1) {
                    var len = sURLVariables[i].length;
                    var temp = sURLVariables[i].substring(0, len - lenParameter);
                    return temp.substring(lenParameter);
                }
            }
        } else {
            for (i = 0; i < sURLVariables.length; i++) {
                if (sURLVariables[i].indexOf(start) != -1) {
                    return sURLVariables[i];
                }
            }
        }

        return null;
    }

    function reverse(s) {
        var o = '';
        for (var i = s.length - 1; i >= 0; i--)
            o += s[i];
        return o;
    }
    //Get user name before sending analytic event
    GetUserName();

    // End info of user from url

    /*** Public methods***/

    // initialize player
    function init(id) {
        //For Publish in mobile and Tablet devices all except "Website" and "Blog" show only in landscape view
        if ((EM.compatibility.getDevice() == "tablet" || EM.compatibility.getDevice() == "mobile") && !EM.isWebsite && !(EM.ezContentTypeId == 11)) {
            $('body').addClass('only-landscape-view');
        }
        context.init();

        // Set enable for auto play for media elements
        EM.Media.toggleEnabled(true);

        if (!context.isOffline && EM.compatibility.getDevice() != "tablet" && EM.compatibility.getDevice() != "mobile") {
            /*** Set listeners ***/
            $(window).on('presentationObjectReady', setPlayerSidebarButtons);
            $(window).on('presentationObjectReady', setPlayerGUIbyDevice);
        }

        //reload the player in http mode if clicking on non https iframe in https mode
        if (window.location.href.indexOf('https://') !== -1) {

            $('#scene').on('click', '.embed-wrapper', function () {
                if ($('.sd-element-embed[src*="http://"]', this).length) { //if this wrapper contains an hhtp iframe
                    if (context.isPresentationPage) {
                        window.parent.postMessage('reloadAsHttp', '*');
                    } else if (context.isEditor) {
                        window.top.location.href = window.top.location.href.replace('https://', 'http://');
                    } else {
                        window.location.href = window.location.href.replace('https://', 'http://');
                    }
                }
            });

        }

        // scene-manager is done and the scene is ready to be played
        $(window).on('sceneReady', sceneIsReady);

        if (context.isEditor || context.isPresentationPage) {

            $(window).one('sceneReady', function () {
                try {
                    window.parent.postMessage('playerReady', '*');
                } catch (e) {
                    console.log(e);
                    //TODO send error to logger in server;
                }
            });
        }

        // unload handler for slideEvent
        $(window).unload(function () {
            if (!context.isEditor && viewDurationStart !== 0) {
                var viewDurationEnd = new Date(),
                    totalSlideViewDuration = Math.round((viewDurationEnd - viewDurationStart) / 1000);

                sendEventSlideClose(prevSlideNumberForAnalytics, totalSlideViewDuration);
                sendEventClosePresentation();
            }
            return "Bye now!";
        });

        // perform action when hash changes
        $(window).on('hashchange', stateCalled);

        // Implement slide settings if exist on $currentSlide
        $('#scene')
            .on('transitionStart', checkSlideAutoplay)
            // .off('transitionStart', EM.player.widgets.transitionStart).on('transitionStart', EM.player.widgets.transitionStart)
            .on('transitionDone', checkSlideScroll)
            .on('transitionDone', enableHeavyContent)
            .on('transitionDone', sendSlideChangeAnalytics);
        //.on('transitionDone', moveScaleToBody)
        //.off('transitionDone', EM.player.widgets.transitionDone).on('transitionDone', EM.player.widgets.transitionDone);

        //fix scrolling of iframes and of the slide itself in ios devices. for the slide, make it scmooth. for the iframes, enable the scrolling
        if (context.isIos) {

            $('#scene').on('transitionDone', function () {

                var $slide = $('.current-active-slide');

                $slide.find('iframe').each(function () {
                    var s = $(this).attr("src");
                    /*if (s.indexOf("widget-plugins/youtube-verticallist") !== -1 ||
                        s.indexOf("widget-plugins/twitter") !== -1 ||
                        s.indexOf("widget-plugins/fbfeed") !== -1)
                        /* add also check if iframe src includes wrapperscroll="yes" #1#
                       {
                           $(this).parent().css({ overflowY: 'auto', overflowX: 'hidden', 'WebkitOverflowScrolling': 'touch' });
                    }*/
                    $(this).parent().css({ overflowY: 'auto', overflowX: 'hidden', 'WebkitOverflowScrolling': 'touch' });
                    //$(this).parent().css({ overflowY: 'scroll', overflowX: 'hidden', 'WebkitOverflowScrolling': 'touch' });
                });
                $slide.css({ 'WebkitOverflowScrolling': 'touch' });
            });
            removeIOSRubberEffect(); // working partial
        }

        if (!context.isOffline) {
            $('#scene').on('transitionDone', redrawCharts);

            //patch to remove the redraw charts event handler of transiton doen in zoomer chrome because in some zoomer themes redrawing the charts causes the entire slide to disappear.
            $('#scene').one('transitionStart', function () {
                var isVideoTheme = window.EM_theme && EM_theme.sceneSettings && EM_theme.sceneSettings.video,
                    isZoomer = window.zoomerInit;
                if (EM.compatibility.getBrowser().indexOf('chrome') !== -1 && (isVideoTheme || isZoomer)) {
                    $('#scene').off('transitionDone', redrawCharts);
                }
            });
        }

        // Player control
        if (EM.compatibility.getDevice() != "tablet" && EM.compatibility.getDevice() != "mobile") {
            $('.playButton').on('click', playWrap);
        }

        $('.leftButton').on('click', prev);
        $('.rightButton').on('click', next);
        //$('.voiceButton').on('click', voiceControl);
        $('.sectionsButton').on('click', sectionsScreen);
        $('.fullscreenButton').on('click', fullScreen);

        // Share popup
        $('.replay').on('click', rewind);

        // Set keyboard control listener
        $(window).on('keydown', onKeyPress);

        // Init the Scene
        EM.scenemanager.init(id);

        if (!context.isEditor && EM.isPublished) {
            if (typeof EM.scenemanager.presentation !== "undefined") {
                if (EM.scenemanager.presentation.theme.themeId !== 48915) // shizim themeId
                    $('#player-loader').removeClass('hidden'); // remove if not shizim
            }
        }

        if (context.isOffline) {
            $('<div id="offline-analytics-indicator"><span class="text">Sync Data</span><span class="icon sync"></span></div>').insertAfter("#buttonsPanel").click(sendOffLineAnalytics);
            if (getOfflineAnalytics()) {
                $('#offline-analytics-indicator').addClass("on");
                sendOffLineAnalytics(); //send any offline analyics that may have been gathered previously
            }
        }

    }

    function removeIOSRubberEffect() {

        if (context.isIos) {
            $("#scene").on("touchstart", ".current-active-slide", function (event) {
                try {
                    var ptrThis = this;
                    var $this = $(this);
                    var top = this.scrollTop;
                    var totalScroll = this.scrollHeight;
                    var currentScroll = top + this.offsetHeight;


                    if (top === 0) {
                        this.scrollTop = 1;
                    }
                    else if (currentScroll === totalScroll) {
                        this.scrollTop = top - 1;
                    }

                } catch (e) {
                    console.info("iphone scroll problem");
                }
            });
        }



    }




    // Go to a specific slide number
    function go(targetSlideNumber) {
        presentSlideNumber = targetSlideNumber;
        updateState();
    }

    /**
     * @description Adds the banner (footer) to each slide if we are in websites.
     * @param {} isVerticalScroll - boolean if there is scroll in the slide or not.
     * @returns {} 
     */
    function appendBanner(isVerticalScroll) {
        //data.scrol

        var bannerHtml,
            bottom;
        var themeId = 0;// presentation.theme.themeId; // 0 for non crashing
       //if (presentation.theme.themeId) {
          if (typeof presentation !== "undefined") {
            themeId = presentation.theme.themeId;
        }


        if (/iPad|iPhone|iPod/.test(navigator.userAgent) || EM.isLayoutsPlayer || window.name === "social" || checkURLParam1('evmotors')) { // for now remove iphone banner. we have a bugs when we have iframe scroll in iphone.
            return; // todo re add the banner for iphones
        }

        if ($currentSlide.find('[data-banner="true"]').length) { // if there is a banner in the page (footer) don't add a new one.
            return;
        }
        //check if themeid (ws) is Beitar then change link to beitar ws generator
        //Beitar themeid's = 48919,48920,48921,48922,48930, 48931
        if (themeId === 48919 || themeId === 48920 || themeId === 48921 || themeId === 48922 || themeId === 48930 || themeId === 48931) {
            bannerHtml = '<div style="position:absolute; @footerBottom@; width:99.7%; height:48px; background: black; z-index: 2147483646 ;font-size: calc(11px + .5vw); font-family: \'asap\'; color : rgb(255, 255, 255); text-align: center;"data-banner="true">This website was created with&nbsp;<a class="ms-banner-link" target="_blank" href="https://www.emaze.com"><span class="">emaze.com</span></a>&nbsp;editor&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <img class="sd-element-image style-sd-image_1 sd-image-border-color_none initial-size-constraint" src="https://resources.emaze.com/vbcommon/images/logo_small.png" data-img-size="32,26" style="width: 32px; height: 26px; position: relative; bottom: -5px"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;click  <a class="ms-banner-link" target="_blank" href="https://www.emaze.com/iframe-website-generator/?c=beitar"><span class="">HERE</span></a>  to create your free website </div>';
        } else if (themeId === 48915) {
            bannerHtml = '<div style="position:absolute; @footerBottom@; width:99.7%; height:48px; background: black; z-index: 2147483646 ;font-size: calc(11px + .5vw); font-family: \'asap\'; color : rgb(255, 255, 255); text-align: center;"data-banner="true"><a class="ms-banner-link" target="_blank" href="https://www.emaze.com"><span class=""><img class="sd-element-image style-sd-image_1 sd-image-border-color_none initial-size-constraint" src="https://resources.emaze.com/vbcommon/images/createdby.png" data-img-size="32,26" style="width: 200px; height: 26px; position: relative; bottom: -5px"></span></a></div>';
        } else {
            //bottom = isVerticalScroll ? $currentSlide[0].scrollHeight + bannerHeight : $currentSlide.height();
            bannerHtml = '<div style="position:absolute; @footerBottom@; width:99.7%; height:48px; background: black; z-index: 2147483646 ;font-size: calc(11px + .5vw); font-family: \'asap\'; color : rgb(255, 255, 255); text-align: center;"data-banner="true">This website was created with&nbsp;<a class="ms-banner-link" target="_blank" href="https://www.emaze.com"><span class="">emaze.com</span></a>&nbsp;editor&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <img class="sd-element-image style-sd-image_1 sd-image-border-color_none initial-size-constraint" src="https://resources.emaze.com/vbcommon/images/logo_small.png" data-img-size="32,26" style="width: 32px; height: 26px; position: relative; bottom: -5px"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;click  <a class="ms-banner-link" target="_blank" href="https://www.emaze.com/website-generator/"><span class="">HERE</span></a>  to create your free website </div>';
        }

        if (EM.player.context.isMobile) { //if we are in mobile then add a different banner.
            bannerHtml = '<div style="position:absolute; @footerBottom@; width:99.7%; height:48px; background: black; z-index: 2147483646 ;font-size: calc(11px + .5vw); font-family: \'asap\'; color : rgb(255, 255, 255); text-align: center;"data-banner="true"> <img class="sd-element-image style-sd-image_1 sd-image-border-color_none initial-size-constraint" src="https://resources.emaze.com/vbcommon/images/logo_small.png" data-img-size="32,26" style="width: 32px; height: 26px; position: relative; bottom: -6px ">&nbsp; <a ><span>Create your free website with</span></a> <a class="ms-banner-link" target="_blank" href="https://www.emaze.com"><span class="">emaze.com</span></a> </div>';
        }

        if (isVerticalScroll) { // if we have scroll then update the bunner at the end of the scroll. using top.
            bottom = $currentSlide[0].scrollHeight;
            bannerHtml = bannerHtml.replace("@footerBottom@", "top:" + bottom + "px");
        } else { // no scroll
            if (scene.isZoomer) {// if we have no scroll in zoomer then put it at bottom - 48px (the height of the banner).
                bannerHtml = bannerHtml.replace("@footerBottom@", "bottom:" + -48 + "px");
            } else { // no scroll then we use the bottom 0
                bannerHtml = bannerHtml.replace("@footerBottom@", "bottom:" + 0 + "px");

            }

        }

        $currentSlide.append(bannerHtml);

    }

    // Letting us know if autoplay initiated alone or by user action
    function playWrap() {
        (isAutoplayButtonClicked && isAutoplay) ? isAutoplayButtonClicked = false : isAutoplayButtonClicked = true;
        play();
    }

    // Autoplay presentation
    function play() {
        if (isAutoplay) {
            isAutoplay = false;
            stopAutoplay();
            $('.pauseButton').removeClass('pauseButton').addClass('playButton');
        } else {
            try {
                window.dispatchEvent(new CustomEvent('start', { 'detail': 'presentation_autoplay_started' }));
            } catch (e) {

            }
            isAutoplay = true;
            startAutoplay();
            $('.playButton').removeClass('playButton').addClass('pauseButton');
        }

    }

    // Go to the next slide
    function next() {
        // Don't exceed total number of slides
        if (presentSlideNumber + 1 > slidesSize) {
            // Report end of presentation to who's interested
            try {
                window.parent.postMessage('presentationEnded', '*');
                //window.dispatchEvent(new CustomEvent('presentationEndedOpenShare', { 'detail': 'presentation_ended' }));
                $(window).trigger('presentationEndedOpenShare', { 'detail': 'presentation_ended' });
            } catch (e) {
                console.log(e);
                //TODO send error to logger in server;
            }

            // show the share pop up only if user triggered next
            if (!isAutoplay) showSharePopUp();
            presentSlideNumber = slidesSize;
        } else {
            presentSlideNumber++;
        }

        updateState();

    }

    // Go to the previous slide
    function prev() {

        if (isSharePopUpShowing) {
            hideSharePopUp();
            return;
        }

        // Limit slide number to 1
        if (presentSlideNumber - 1 < 1) {
            presentSlideNumber = 1;
        } else {
            presentSlideNumber--;
        }

        updateState();

    }

    // Register voice commands and trigger voice control on/off
    //function voiceControl(){
    //    if (annyang) {
    //        // Commands action
    //        var commands = {
    //            'next': function () {
    //                next();
    //            },
    //            'back': function () {
    //                prev();
    //            },
    //            'agenda': function () {
    //                sectionsScreen();
    //            },
    //            'slide': function () {
    //                sectionsDisplaySlides();
    //            },
    //            'close': function () {
    //                hideSectionsFrame();
    //            },
    //            'play': function () {
    //                playWrap(); //changed on 23/7/15 used to be  set to 'play()' but that only worked for one slide
    //            },
    //            'stop': function () {
    //                play();
    //            },
    //            'amaze': function () {//emaze parsed to amaze/amazed usually
    //                play();
    //                hideGUI();
    //            },
    //            'amazed': function () {//emaze parsed to amaze/amazed usually
    //                play();
    //                hideGUI();
    //            }

    //        };

    //        // Initialize annyang with the commands
    //        annyang.init(commands);

    //        // Make sure commands were added, might be issue with init this ver
    //        annyang.addCommands(commands);

    //        var $status = $('.voiceButton').attr('data-listen');

    //        if ( $status === "false" ){
    //            // Start listening.
    //            annyang.start({ autoRestart: false });
    //            $('.voiceButton').attr('data-listen', 'true');
    //            $('.voiceButton').addClass('buttonVoiceOn').addClass('voice-active');

    //            annyang.addCallback('end', function () {
    //                annyang.abort();
    //                $('.voiceButton').attr('data-listen', 'false'); 
    //                $('.voiceButton').removeClass('buttonVoiceOn').removeClass('voice-active');
    //            });
    //        } else {
    //            annyang.abort();
    //            $('.voiceButton').attr('data-listen', 'false'); 
    //            $('.voiceButton').removeClass('buttonVoiceOn').removeClass('voice-active');
    //        }
    //    }
    //}

    // Triggers sections screen, "Agenda"
    function sectionsScreen() {
        if (isAutoplay) {
            play();//Stop autoplay if active
        }

        if (!showingSections) {
            buildSectionsScreen();
            $("#sectionsFrame").css("visibility", "visible");
            showingSections = true;
        } else {
            $("#sectionList").add('#sectionsTitle').empty();
            $("#sectionsFrame").css("visibility", "hidden");
            showingSections = false;
        }

    }

    function riseScroll(interval, max) {
        if (interval < max) {
            setTimeout(function () {
                window.scrollTo(0, interval);
                interval = interval + 10;
                riseScroll(interval, max);
            }, 100);
        } else {
            return;
        }
    }

    // Turn on/off fullscreen mode
    function fullScreen() {
        var localStorageVal;
        // emaze viewer fullscreen handling
        if (typeof winformFullScreen != typeof undefined) { //Check if we got winform
            // check if enterFullScreen method available and we are not in fullscreen
            if (!isFullscreen) {
                isFullscreen = true;
                winformFullScreen('enterFullScreen');
                // check if leaveFullScreen method available and we are in fullscreen
            } else if (isFullscreen) {
                isFullscreen = false;
                winformFullScreen('leaveFullScreen');
            }
        } else {
            if (EM.compatibility.getDevice() == 'mobile' && EM.compatibility.getType() == 'iphone') {
                var $b = $('body');
                if ($b.hasClass('iphone-fullscreen')) {
                    $b.removeClass('iphone-fullscreen');
                } else {
                    $b.addClass('iphone-fullscreen');
                }

                return;
            }
            isFullscreen = window.innerHeight == screen.height;

            try { //in case local storage throws error
                localStorageVal = localStorage.getItem('iefs');
            } catch (e) {

                localStorageVal = null;
            }

            var s = "";
            if (!isFullscreen && (localStorageVal === "false" || localStorageVal == null)) {
                s = localStorageVal == null ? "null" : localStorageVal.toString();
                requestFullScreen(document.body);
                $('.fullscreenButton').addClass('fullscreen-active');
            } else {
                s = localStorageVal == null ? "null" : localStorageVal.toString();
                cancelFullScreen(document.body);
                $('.fullscreenButton').removeClass('fullscreen-active');
            }

            // Firefox spacebar cause clicking on the focused button
            $('.fullscreenButton').blur();
        }
    }

    function getSlidedeck() {
        return slidedeck;
    }

    // Return to first slide
    function rewind() {
        if (presentSlideNumber == 1) {
            hideSharePopUp();
        }

        window.scene.rewind();
        presentSlideNumber = 1;
        updateState();
    }
    function getSlideCount() {
        return slidesSize;
    }
    /*** Private methods ***/

    function setSlideDeck(slideDeck) {
        slidedeck = slideDeck;//update the global slidedeck with updated one given by editor
        if (slidedeck.presentationSettings && slidedeck.presentationSettings.menu) {
            if (slidedeck.presentationSettings.menu.name && EM.compatibility.getDevice() != "desktop") {
                slidedeck.presentationSettings.menu.name = 'frosty'; //anyothing other than desktop allways gets the mobile menu named frosty
            }

            if (context.isEditor && !isReload) { return; } //on first load in editor,. dont load the menu, it will be overridden in the reload immediately after

            EM.navMenuManager.loadMenu(slidedeck.presentationSettings.menu);
        }
    }

    function claimSiteClicked() {
        try {
            var slidedeck = JSON.parse(EM.scenemanager.presentation.theme.slides);
            var emailFromInstagram = slidedeck.presentationSettings.influencer.email;
            var instagramUsername = slidedeck.presentationSettings.influencer.instagram.username;
            var themeId = presentation.theme.themeId;
            var themeName = presentation.theme.themeName;
            var label = { emailFromInstagram: emailFromInstagram, instagramUsername: instagramUsername, themeId: themeId, themeName: themeName };

            $.post('https://app.emaze.com/api/logEvent', { eventtype: 'claimsite', label: labelForEvent(label) });
            $.post('https://event.emaze.com/influencer/setSiteClaimed?email=' + emailFromInstagram); // ongage
            return true;
        }
        catch (e) { }

    }


    function claimContentClicked() {
        EM_loginHandler.login("editor", EM.scenemanager.presentation.core.presentationId);
    }

    function claimContentClickedGotoMyPres() {
        EM_loginHandler.login("moveContentToUser-gotoMypres", EM.scenemanager.presentation.core.presentationId);
    }

    function loadJsFile(src) {
        var s = document.createElement("script");
        s.type = "text/javascript";
        s.src = src;
        document.body.appendChild(s);
    }

    function loadCssFile(src) {
        $('head').append('<link rel="stylesheet" href="' + src + '" type="text/css" />');
    }

    // hook in the login popup mechanism
    function loadLoginPopup() {
        EM_loginPopupInPlayer_setEventListeners = true;
        loadJsFile("https://static2.emaze.com/wp-content/themes/emaze/external/popups/login2/loginPopup.js?ver=1.5");
        loadJsFile("https://resources.emaze.com/vbcommon/js/loginPopupInPlayer.js");
        loadCssFile("https://static2.emaze.com/wp-content/themes/emaze/external/popups/login2/loginPopup.css?ver=1.5");
    }



    function loadjscssfile(filename, filetype) {
        if (filetype == "js") { //if filename is a external JavaScript file
            var fileref = document.createElement('script');
            fileref.setAttribute("type", "text/javascript");
            fileref.setAttribute("src", filename);
        }
        else if (filetype == "css") { //if filename is an external CSS file
            var fileref = document.createElement("link");
            fileref.setAttribute("rel", "stylesheet");
            fileref.setAttribute("type", "text/css");
            fileref.setAttribute("href", filename);
        }
        if (typeof fileref != "undefined")
            document.getElementsByTagName("head")[0].appendChild(fileref);
    }

    function loadScriptWithCallback(url, callback) {
        // Adding the script tag to the head as suggested before
        var head = document.getElementsByTagName('head')[0];
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.async = false; // download async run each file sync in the order it was called.


        // Then bind the event to the callback function.
        // There are several events for cross browser compatibility.
        if (callback) {
            script.onreadystatechange = callback;
            script.onload = callback;
        }

        script.src = url; // for some browsers this line need to be called after the events listeneres.
        // Fire the loading
        head.appendChild(script);
    }

    /**
     * adds the environment(for example resources.emazestaging.com) and version to the path
     * @param {string} pathToFile To the File with the prefix '/'. for example:  /vbcommon/libs/imageEnlarger/js/carousel.js
     * @returns {string} full url with environment and version (for example : //resources.emazestaging.com/vbcommon/libs/imageEnlarger/js/carousel.js?v=V3.0.7954.636311366583647781 ) 
     */
    function createFullUrl(pathToFile) {
        if (typeof emazeAppVersion === "undefined" || emazeAppVersion === null) { // at emaze.me the users doesn't have the emazeAppVersion until they republish.
            return environment + pathToFile;
        }
        return environment + pathToFile + "?v=" + emazeAppVersion;
    }

    // handles sceneReady event, revealing the presentation
    // and making adjustments
    function sceneIsReady(e, slideDeck, slideLength) {
        // Update Globals
        sectionsSize = slideDeck.sections.length;
        slidesSize = slideLength;

        // Update global slidedeck from returned object.
        // On reload editor sends us the slidedeck via client side
        if (!isReload) {
            setSlideDeck(slideDeck);
        }

        if (EM.isWebsite) {//now that we have a slide deck, we can get the slide number that corresponds to the slidename in hash from slidedeck.slidesettings
            presentSlideNumber = getSlideNumber();
        }

        // Set ezContentType from presentation
        ezContentType = EM.scenemanager.presentation.core.ezContentType;
        username = EM.scenemanager.presentation.userInfo.userName;
        isPremium = EM.scenemanager.presentation.userInfo.isPremiumUser;
        isLoggedIn = EM.scenemanager.presentation.userInfo.isUserLoggedIn;

        // Display presentation info
        setPresentationInfo();


        if (isReload) {
            // Reset audio module
            EM.Audio.reset(slidedeck);
        } else {
            // Init audio module with presentation slidedeck
            EM.Audio.init(slidedeck, context.isOffline ? { loadInterval: 10 } : {}); //in download version, reduce the load interval since the audio is not being loaded over http
        }

        // Go to the requested slide (or first one if none mentioned)
        go(presentSlideNumber);

        // enable heavy content for first slide
        enableHeavyContent();

        // Use scene scaling for now
        setTimeout(function () {
            window.scene.resizeWinner();
        }, 600);

        // Don't display the menu since functionality not available offline
        if (context.isOffline) $('#menu-container').addClass('hidden');

        $('html').on("mouseenter", showGUI).on("mouseleave", hideGUI);

        //$('#toggle').on('click', function(){
        //    displayUserAndPresentationInfo(5);
        //});

        // Trigger GUI once if mouse moved
        $('#scene').on('mousemove', mouseMoveGUIHandler);

        if (EM.compatibility.getDevice() != "desktop" || window.location.href.indexOf('enabletouch') > 0) {
            // we are on tablet or mobile or any other touch
            // supported device
            //TODO: Removed this from player, because use other library for mobile and tablet devices (by Sergey)
            /*$('html')
            .hammer().on("tap swipeup", showGUI)
            .hammer().on("swipedown", hideGUI)
            .hammer().on("swiperight", prev)
            .hammer().on("swipeleft", next);*/
        }

        // all should be set, we can remove the loader
        //Remove loader from my-presentations/explore/shared player iframe
        // if replaicng user content - remove loader after all replacements are done
        // for now the way selected to indicate if we are going to do a replace (and turn off the loader there) is by checking the following:
        var replaceChannel = getParameterByName('channel');
        var willReplacementsActuallyOccur = (replaceChannel != null) && (replaceChannel.length > 0);
        if (!willReplacementsActuallyOccur) {
            removeLoader();
        }

        // This event is for the video robot to catch 
        //window.dispatchEvent(new CustomEvent('playerReady', { detail: { 'slideCount': slidesSize } }));
        $(window).trigger('playerReady', { 'slideCount': slidesSize });

        try {
            if (window.top && (window.self !== window.top) && window.parent.playerReady && window.self.frameElement.id == "player-iframe") {
                window.parent.playerReady();
            }
        } catch (err) {
            //console.error(err);
        }

        // After scene is ready we can surely say player is also ready
        firstLoad = false;

        // Trigger any existing parameters actions
        triggerParamsActions();

        showGUI();
        //displayUserAndPresentationInfo(5);

        if (isReload && context.isEditor) {
            isReload = false;
            try {
                setTimeout(function () {
                    window.parent.postMessage('playerReloaded', '*');
                }, 300);
            } catch (e) {
                console.log(e);
                //TODO send error to logger in server;
            }
        }

        setPlayerCookies();


        if (!context.isEditor) {

            // influencers, non emaze users
            var pres = EM.scenemanager.presentation;
            if (EM.isPublished && pres.userInfo.isClaimed === false) { // isClaimed == false then we add the claim this site banner

                if (getSlidedeck().presentationSettings && getSlidedeck().presentationSettings.campaign && getSlidedeck().presentationSettings.campaign.indexOf("halloween") != -1) {
                    // login popup and redirect to my pres
                    var template = '<div onclick="EM.player.claimContentClickedGotoMyPres()" target="_blank" id="pl-claim-this-site-indp" class="pl-claim-this-content" ></div>';
                    $("#main-container").append($(template));
                    loadLoginPopup();

                } else {
                    // unauth wizard 
                    var template = '<a href="https://app.emaze.com/wizard/in/0/@presId" onclick="EM.player.claimSiteClicked()" target="_blank" id="pl-claim-this-site-indp" class=""></a>';
                    var presId = pres.core.presentationId;
                    if (presId) {
                        var $elem = $(template.replace("@presId", presId));
                        $("#main-container").append($elem); // add claim this site button to the dom
                    }
                }
            }

            // edit your photo album - emaze fb users
            if (!EM.isPublished && getSlidedeck().presentationSettings && getSlidedeck().presentationSettings.campaign && !context.isMobile && pres.core.dateCreated && pres.core.dateCreated == pres.core.dateUpdated) {
                var template = '<div onclick="EM.player.claimContentClicked()" target="_blank" id="pl-claim-this-site-indp" class="pl-claim-this-content" ></div>';
                $("#main-container").append($(template));
                loadLoginPopup();
            }

            if (EM.isPublished) { // send website view  event for emaze.me websites.
                var themeId = presentation.theme.themeId;
                var themeName = presentation.theme.themeName;
                var presentationId = EM.scenemanager.presentation.core.presentationId;
                //var labelPresInfo = "{\\\"presentationid\\\":\\\"" + presentationId + "\\\"}";
                //var labelPresInfo = "{\\\"presentationid\\\":\\\"" + presentationId + "\\\",\\\"themeID\\\":\\\"" + themeId + "\\\"}";
                var labelPresInfo = { presentationId: presentationId, themeId: themeId };
                // cannot usee /ap/logEvent because we are in emaze.me
                $.post('https://app.emaze.com/api/logEvent', { eventtype: 'websiteview', label: JSON.stringify(labelPresInfo), macaddress: EM.ezContentTypeId, computername: themeName, cpuid: themeId });
            }

            // Send emaze analytics event
            sendEventOpenPresentation();
            if (!context.isOffline) {
                var login_username = $.cookie('ezlogged') === $.undefined ? 'NA' : $.cookie('ezlogged');
                var label = login_username + ',' + presentationId;
                googleTagEvent(label, 'eventViewPresentation');
            }
        }

        if (EM.scenemanager.replaceWithUserContent && EM_WidgetServices) {
            var options = EM.scenemanager.unauthWizardFrame ? "spider-in" : null;
            EM_WidgetServices.setSocials(options);
        }

        if (EM.isWebsite && !EM.isLayoutsPlayer && !EM.hideShareRuler && (typeof presentation !== "undefined" && presentation.theme.themeId !== 48915) && window.location.pathname !== '/ifatbizcard3') {//share and follow 
       // if (EM.isWebsite && !EM.isLayoutsPlayer && !EM.hideShareRuler && (presentation.theme.themeId !== 48915)) {//share and follow - old Avi code

            loadjscssfile("https://static2.emaze.com/wp-content/themes/emaze/external/popups/login2/loginPopup.css", "css");
            loadjscssfile(createFullUrl("/share-and-follow/simple/shareFollow.css"), "css"); // load the css dynamically


            loadScriptWithCallback("https://static2.emaze.com/wp-content/themes/emaze/external/popups/login2/loginPopup.js");
            loadScriptWithCallback(createFullUrl("/vbcommon/js/cookies.js")); // used inside of shareFollow.js
            loadScriptWithCallback(createFullUrl("/vbcommon/js/loginPopupInPlayer.js"));
            loadScriptWithCallback(createFullUrl("/share-and-follow/simple/shareFollow.js"), function () { // load the javascript dynamically and just after everything is loaded init it.
                if (typeof ShareFollow != "undefined") {
                    ShareFollow.init();
                    console.log("share follow added to the dom");
                }
            });

        }

        //for remote connection trigger by Player Ready
        window.parent.postMessage(JSON.stringify({ playerReadyForRemote: true }), "*");

        if (typeof (fireTogetherJSScrolling) === "function") {
            $('.slide').on('scroll', function (e) {
                fireTogetherJSScrolling(e.currentTarget, $(e.currentTarget).scrollTop());
            });
        }

    }

    // First run, setting of player elements according to given user permissions
    function setPlayerSidebarButtons() {
        ezContentType = EM.scenemanager.presentation.core.ezContentType;
        var permissions = EM.scenemanager.presentation.userInfo;

        // Should watermark be displayed, 0,1 and null can be "presentation" content type
        $('#pl-watermark').toggleClass('hidden', !permissions.showLogo);
        $('#pl-watermark-indp').toggleClass('hidden', !permissions.showLogo || ezContentType == 1 || ezContentType == 0 || ezContentType == null);

        if (permissions.userImage) {
            $('#player-logo img').attr('src', permissions.userImage);
        } else {
            $('#player-logo img')
                .attr('src', '//resources.emaze.com/vbplayer/images/logo.png').addClass('logo');
        }

        // Is user allowed to edit
        if (permissions.isUserLoggedIn && !context.isEditor) {  //CODEREVIEW: streamline this code into a simple frm once the spec is understood
            if (permissions.canEdit) {
                if (!context.isPresentationPage && !context.isMyPres) {
                    $('#edit-button').hide();
                }
            } else {
                if (context.isMyPres) {
                    $('#edit-button').remove();
                } else {
                    try {
                        if (window.top.location.origin.indexOf('app.emaze') != -1) { //CONDEREVIEW: assuming this is meant to check !context.isPresentationPage 
                            $('#edit-button').off('click');
                            $('#edit-button').attr('id', 'clone-button');
                        } else {
                            $('#edit-button').hide();
                        }
                    } catch (e) {
                        $('#edit-button').hide();
                    }
                }
            }
        } else {
            $('#edit-button').addClass('hidden');
        }

        // Is user allowed to duplicated
        if (permissions.canDuplicate) {
            $('#duplicate-button').removeClass('hidden');
            try {
                window.parent.postMessage('canduplicate', '*');
            } catch (e) {
                console.error(e);
            }
        } else {
            try {
                window.parent.postMessage('noduplicate', '*');
            } catch (e) {
                console.error(e);
            }
            $('#duplicate-button').add('#clone-button').addClass('hidden');
        }

        //show/hide buttons according to permissions
        $('#delete-button').toggleClass('hidden', !permissions.isUserOwner || context.isEditor);
        $('#download-button').toggleClass('hidden', !permissions.canDownload);
        $('#print-button').toggleClass('hidden', !permissions.canPrint);

    }

    // Set CSS to according to device
    function setPlayerGUIbyDevice() {
        var device = EM.compatibility.getDevice(),
            $device;

        if (device !== 'desktop') {
            $device = $('.device'),
                $device.attr('href', $device.attr('href').replace('desktop', device));
        }
    }

    // Set control panel slider
    function playerSlider() {
        var $preview = $('.preview');
        $("#slider").slider({
            min: 1,
            max: slidesSize,
            value: presentSlideNumber,
            slide: function (event, ui) {
                go(ui.value);
            }
        });

        if (firstLoad || isReload) {
            setSliderMarks();
        }

        // Calculate and prepare preview thumbnail with slide
        $('.ui-state-default').on('mouseover', previewPosition)
            .hover(function () { // Display the preview thumbnail
                $preview.fadeIn(150);
            }, function () {
                $preview.fadeOut(150);
            });

    }
    //
    function moveScaleToBody() {
        if (EM.isWebsite) {
            var $slide = $('.current-active-slide');
            if ($slide.length > 0) {
                var slide = $slide[0];
                var height = slide.scrollHeight;
                $slide.add($slide.parents().not('body, #transformer')).css('height', height);
                $(document.body).css('overflow-y', 'scroll');
            } else {
                setTimeout(moveScaleToBody, 1000);
            }
        }
    }


    // Update hash with current slide number
    function updateState() {



        // If we already have hash on URL it won't trigger hash change
        // So I force a hash change
        //if (EM.compatibility.getDevice() != 'mobile') {
        if (firstLoad && hash || isReload) {
            window.location.hash = '#';
        }
        var slideName = EM.isWebsite ? getSlideSettingValue(presentSlideNumber, 'name') || presentSlideNumber : presentSlideNumber;
        if (slideName === 'null' || slideName === null) {
            slideName = presentSlideNumber;
        }

        //if (options.navigateViaHashChange) { // in websites, we show the slide name
        if (options.navigateViaHashChange || window.location.hash !== slideName) { // in websites, we show the slide name
            window.location.hash = '#' + String(slideName).replace('#', '');
        } else {
            //window.dispatchEvent(new CustomEvent('changeslide', { 'detail': { slideNumber: presentSlideNumber } }));
            $(window).trigger('changeslide', { 'detail': { slideNumber: presentSlideNumber, isAutoplay: isAutoplay } });
            stateCalled();
        }
        updateCurrentSlide();
    }


    // trigger by hashchange event
    function stateCalled(e) {
        hideSharePopUp();


        presentSlideNumber = getSlideNumber();

        if (presentSlideNumber != pastSlideNumber) {

            //patch to skip 2nd slide in layout player
            if (EM.isLayoutsPlayer && presentSlideNumber == 2 && checkIfSlideIsEmpty() && !EM.isWebsite) { // only if the slide number is 2 and it is really empty then skip it.
                if (slidesSize < 3) {
                    presentSlideNumber = 1;
                }
                presentSlideNumber = (presentSlideNumber > pastSlideNumber) ? 3 : 1;
                window.location.hash = presentSlideNumber; //commented out in attempt to preserve slide names in the hash; commented in to make the skip work, relevant only for presentations which anyway use only number hashes
            }

            // using scene go slide since we update state in our go method
            disableHeavyContent(); //disable iframes in current slide before exit.  videos are diabled in emaze.media_player on transition start.

            window.scene.goSlide(presentSlideNumber);
            pastSlideNumber = presentSlideNumber;
        }

        // updateState();
        updateGUI();
    }
    /**
     * Check if the current slide is empty or not. using scene.getCurrentSlide(); to get the current slide.
     * @return {boolean} true if the slide is empty, else false;
     */
    function checkIfSlideIsEmpty() {
        var $currentActiveSlide = scene.getSlide(presentSlideNumber); //  scene.getCurrentSlide();

        if ($currentActiveSlide && $currentActiveSlide.length) {
            if ($currentActiveSlide.find('.edit-wrapper').length < 2) { // check if the slide is empty
                return true;
            }
        }
        return false;
    }

    // Start and recurse autoplay
    function startAutoplay() {
        // Recurse on transitionDone
        $("#scene").one('transitionDone', startAutoplay);

        // Set stop duration time according to slide settings or default one
        var seconds = getSlideSettingValue(presentSlideNumber, 'stopduration') || defaultStopDuration;

        if (isPlaying !== false) {
            clearTimeout(isPlaying);
        }

        // Perform transition
        isPlaying = setTimeout(autoplay, seconds * 1000);

    }

    // Perform autoplay transition
    function autoplay() {

        //failsafe to prevent autoplay of player in editor when not in view
        if (context.isEditor && !$(window.frameElement).is(':visible')) {
            isAutoplay = false;
        }


        if (!isAutoplay) { return; }

        // stop playing embedded videos during play
        EM_YoutubePlayer.stopVideoPlayers();
        // For some reason autoplay causes mouse threshold to rise, reset it then
        mouseThreshold = 0;

        (presentSlideNumber >= slidesSize) ? go(1) : next();

        if (presentSlideNumber >= slidesSize) {
            // Report end of presentation to who's interested
            try {
                if (slidesSize === 1) {
                    window.parent.postMessage('presentationEnded', '*');
                    window.dispatchEvent(new CustomEvent('finish', { 'detail': 'presentation_autoplay_finished' }));
                } else {
                    // Get slide duration and reduce a bit to prevent last slide transition start
                    var sec = (getSlideSettingValue(presentSlideNumber, 'stopduration') || defaultStopDuration) - 0.3;

                    $('#scene').one('transitionDone', function () {
                        setTimeout(function () {
                            window.parent.postMessage('presentationEnded', '*');
                            window.dispatchEvent(new CustomEvent('finish', { 'detail': 'presentation_autoplay_finished' }));
                        }, sec * 1000);
                    });
                }
            } catch (e) {
                console.log(e);
                //TODO send error to logger in server;
            }
        }
    }

    // Stop the autoplay
    function stopAutoplay() {
        if (isPlaying !== false) {
            clearTimeout(isPlaying);
        }

    }

    // Set fullscreen with fallback to OLD IE (version 9) using activeX if enabled
    function requestFullScreen(element) {
        // Supports most browsers and their versions.

        var requestMethod = element.requestFullScreen ||
            element.webkitRequestFullScreen ||
            element.mozRequestFullScreen ||
            element.msRequestFullScreen;

        if (requestMethod) { // Native full screen.
            requestMethod.call(element);
        } else {
            window.open(window.location.href, 'emaze Fullscreen', 'fullscreen=yes');

            try {
                localStorage.setItem('iefs', true);
            } catch (e) {
                //in case local storage throws error
            }

        }
    }

    // If fullscreen is active, disable it
    function cancelFullScreen() {
        var cancelMethod = document.exitFullscreen ||
            document.mozCancelFullScreen ||
            document.webkitExitFullscreen ||
            document.msExitFullscreen;

        if (cancelMethod) {
            cancelMethod.call(document);
        } else {//the infamous IE handling
            try {
                localStorage.setItem('iefs', false);
                window.close();
            } catch (e) {
                //in case local storage throws error
            }
        }
    }

    //Get settings object of a requested slide
    function getSlideSettings(slideNum) {
        try {
            return slidedeck.slideSettings[slideNum - 1] || ($currentSlide ? $currentSlide.data() : {});
        } catch (e) {
            return {};
        }
    }

    // Get specific value from settings object of a requested slide
    function getSlideSettingValue(slideNum, key) {
        var slideSettings = getSlideSettings(slideNum);
        if (slideSettings[key]) {
            return slideSettings[key];
        } else {
            return null;
        }
    }

    // Triggers autoplay if slide has autoplay setting
    function checkSlideAutoplay(event, slideNum) {
        var settings = getSlideSettings(slideNum);

        // If we are not in autoplay mode and slide settings want to, toggle autoplay on
        if (!isAutoplay) {
            if (settings['autoplay']) {
                play();
            }
        }

        // If we are in autoplay mode and slide settings don't want to, toggle autoplay off
        if (isAutoplay) {
            if (!settings['autoplay'] && !isAutoplayButtonClicked) {
                play();
            }
        }

    }

    // Toggle scroll if slide has scroll setting set to true
    function checkSlideScroll() { //TODO: renamer this function because it does much more than check the scroll.
        var settings;

        updateCurrentSlide();
        if (window.name == "remote" && typeof window.parent.model != "undefined"
            && window.TogetherJS && window.TogetherJS.running && window.parent.model.IsOwner) {
            TogetherJS.send({ type: "setCurrentSlide", slide: presentSlideNumber });
        }
        //setOrUpdateParallaxEffect();
        settings = getSlideSettings(presentSlideNumber);

        // in some themes like sd-theme_company-profile the transition done is called during add slide and we come here to early and need to ingonre this event
        var isSettingsValid = Object.keys(settings).length > 0;

        if ($currentSlide && isSettingsValid) {

            EM.slideOptions.setScroll(settings, $currentSlide);
            //Set focus on the slide so keyboard scrolling will work right away
            if (context.isPresentationPage || window === window.top) { //put some limitations on this, so that  presentation embedded in a slide inside of editor won't steal focus
                $currentSlide.focus();
            }
            EM.slideOptions.toggleHorizontalScroll(settings.scroll || settings.scroll_x, $currentSlide);
            //##### added fix for adam (EM.scenemanager.presentation.userInfo.userName.toLowerCase()).indexOf('designadmin') === -1 ->> in order to remove the banner for design admin need to remove it after he will finish with the tutorials
            //if (EM.isWebsite && (EM.scenemanager.presentation.userInfo.userName.toLowerCase()).indexOf('designadmin') === -1) { // if we are in websites add the banner (footer).
            if (EM.isWebsite) { // if we are in websites add the banner (footer).
                var isActuallyScroll = $currentSlide.css('overflow-y') === 'auto';
                appendBanner(isActuallyScroll);
            }

        }
    }

    function sendSlideChangeAnalytics() {
        if ($currentSlide) {
            if (!context.isEditor && prevSlideNumberForAnalytics != presentSlideNumber) {
                if (viewDurationStart != 0) {
                    var viewDurationEnd = new Date(),
                        totalSlideViewDuration = Math.round((viewDurationEnd - viewDurationStart) / 1000);

                    sendEventSlideClose(prevSlideNumberForAnalytics, totalSlideViewDuration);
                    viewDurationStart = new Date();
                    prevSlideNumberForAnalytics = presentSlideNumber;

                } else {
                    viewDurationStart = new Date();
                    prevSlideNumberForAnalytics = presentSlideNumber;
                }
            }
        }
    }

    // load iframe on first time that slide is navigated to
    function enableHeavyContent() {
        $('.current-active-slide').addClass('enable-animation');
        $('.current-active-slide .sd-element-embed').each(function () { //dont handle all iframe because the sd-element-vidoe iframes are hanlded separately
            var dataSrc = this.getAttribute('data-src');
            var optimization = $(this).data().optimization;
            if (dataSrc && optimization !== 'none') { //embed elements that are untouched by optimization code should not be reloaded.
                this.src = dataSrc;
            }
        });
        if (EM.scenemanager.imageOptimizer.disableGifs && $currentSlide) {
            $currentSlide.find('[src*="f_png"]').each(function () {
                this.setAttribute('src', this.getAttribute('src').replace('f_png', 'f_gif'));
            });
        }
    }
    function redrawCharts() {
        EM_Graphs.redrawChartsInSlide($('.current-active-slide'));  // must re-draw the charts for hover effects to work on the chart. 
    }

    function disableHeavyContent() {
        $('.current-active-slide').removeClass('enable-animation');
        if ($currentSlide) {
            $currentSlide.find('iframe:not([data-optimization="none"]):not(.sd-element-video)').attr('src', '');
            if (EM.scenemanager.imageOptimizer.disableGifs) {
                $currentSlide.find('[src*="f_gif"]').each(function () {
                    this.setAttribute('src', this.getAttribute('src').replace('f_gif', 'f_png')); //assems gif disabled in the data-src of the image
                });
            }
        }
    }



    // Reload the player to sync with editor
    function reload(slideDeck, slideNum, themeUrl) {
        try {
            // Let the player know we are entering reload process
            isReload = true;

            changeTheme(themeUrl);

            // Set present slide number to the requested slide number
            pastSlideNumber = 0;
            presentSlideNumber = slideNum;

            setSlideDeck(slideDeck);

            // Hide sections screen in case it was opened
            hideSectionsFrame();

            // Clear the slider marks since slide deck size could be changed
            clearSliderMarks();

            // Reload #scene and it's related assets
            EM.scenemanager.reload(slidedeck);
            // Disable auto play in player from editor in case of autoplay active
            if (isAutoplay) {
                play();
            }

        } catch (e) {
            console.log(e.message);
            $.post("/present/logError", { source: "player.js/relaod", message: e.message });
        }

    }

    //change the theme css file in order to sync with change in editor
    function changeTheme(url) {
        EM.scenemanager.clearTheme();
        EM.scenemanager.setTheme(url);
    }

    // Bind keyboard keys to their corresponding actions
    function onKeyPress(e) {
        mouseThreshold = 0;//Resolve wierd behaviour where keypress (or something else) trigger mousemove in Chrome    
        var code = e.keyCode;

        switch (code) {
            case 27: //ESCape
                if (isFullscreen) {
                    fullScreen();
                }
                break;

            case 35: //End
                go(slidesSize);
                break;

            case 36: //Home
                rewind();
                break;

            case 38://Up
                try {
                    if (!scene.getCurrentSlide().is('.sd-page-scroll, sd-page-scroll_y')) {
                        if (isHideByContentType('hidebuttons')) {
                            return;
                        }
                        e.preventDefault();
                        prev();
                    }
                } catch (e) {
                    console.error(e);
                }
                break;
            case 37://Left Arrow
            case 33://PageUp
                if (isHideByContentType('hidebuttons')) {
                    return;
                }
                e.preventDefault();
                prev();
                break;
            case 8://Backspace
                return;


            case 40://Down
                try {
                    if (!scene.getCurrentSlide().is('.sd-page-scroll, sd-page-scroll_y')) {
                        if (isHideByContentType('hidebuttons')) {
                            return;
                        }
                        e.preventDefault();
                        next();
                    }
                } catch (e) {
                    console.error(e);
                }
                break;

            case 39://Right Arrow
            case 34://PageDown
                if (isHideByContentType('hidebuttons')) {
                    return;
                }
                e.preventDefault();
                next();
                break;
            case 32://Space bar
                return;


            case 13://Return
                fullScreen();
                break;
            case 122://F11
                e.preventDefault();
                fullScreen();
                break;

            default:
                if (code !== undefined)
                    scene.manualMove(code);
        }
    }

    // Show the share pop up screen
    function showSharePopUp() {

        // Trigger share pop up since we were in last slide
        if (!isSharePopUpShowing && EM.scenemanager.presentation.userInfo.isPublic) {
            $('.pop-container').show();
            isSharePopUpShowing = true;

            $('.rightButton').prop('disabled', true);
            $('.leftButton').prop('disabled', false);

            var scale_factor = $('#slide-box').attr('scale-factor') || ($(window).width() / 1920);

            setScale($('.wrap-pop'), scale_factor);
        }
    }

    // Hide the share pop up screen
    function hideSharePopUp() {
        if (isSharePopUpShowing) {
            $('.pop-container').hide();
            isSharePopUpShowing = false;
            $('.rightButton').prop('disabled', false);

            // Disable previous functionality since we have only 1 slide
            if (slidesSize == 1) {
                $('.leftButton').prop('disabled', true);
            }
        }
    }

    // Popping up the share option selected and set it
    function sharePopup(width, height, net) {
        var leftPosition, topPosition;
        leftPosition = (window.screen.width / 2) - ((width / 2) + 10);
        topPosition = (window.screen.height / 2) - ((height / 2) + 50);

        var windowFeatures = "status=no,height=" + height + ",width=" + width + ",resizable=yes,left=" + leftPosition + ",top=" + topPosition + ",screenX=" + leftPosition + ",screenY=" + topPosition + ",toolbar=no,menubar=no,scrollbars=no,location=no,directories=no";
        var u = window.location.href.replace('staging', '');
        var t = document.title;

        if (ezContentType == 1) // only presentation point to presentation page
            u = u.replace('app', 'www');
        url = u.substring(0, u.indexOf('#'));

        switch (net) {
            case 'fb':
                share = "http://www.facebook.com/sharer.php?u=";
                var label = 'Player, Facebook, ' + username + ', ' + presentationId;
                googleTagEvent(label, 'eventShare-Player');
                break;
            case 'tw':
                share = "https://twitter.com/share?text=Check out this amazing emaze!&via=emaze_tweets&url=";
                var label = 'Player, Twitter, ' + username + ', ' + presentationId;
                googleTagEvent(label, 'eventShare-Player');
                break;
            case 'in':
                share = 'http://www.linkedin.com/shareArticle?mini=true&title=' + encodeURIComponent(EM.scenemanager.presentation.core.name) + '&summary=' + encodeURIComponent(EM.scenemanager.presentation.core.description) + '&source=emaze&url=';
                var label = 'Player, Linkedin, ' + username + ', ' + presentationId;
                googleTagEvent(label, 'eventShare-Player');
                break;
            case 'gp':
                share = "https://plus.google.com/share?url=";
                var label = 'Player, Googleplus, ' + username + ', ' + presentationId;
                googleTagEvent(label, 'eventShare-Player');
                break;
            case 'pt':
                share = "https://pinterest.com/pin/create/button/?media=" + encodeURIComponent(EM.scenemanager.presentation.theme.imageUrl) + "&description=Check out this amazing emaze.&url=";
                var label = 'Player, Pinterest, ' + username + ', ' + presentationId;
                googleTagEvent(label, 'eventShare-Player');
                break;
        }

        $.ajax({
            type: 'POST', url: '/Share/sendEvent', dataType: 'json',
            data: { presid: presentationId, sharefrom: 'lastslide', sharetype: net }
        });

        window.open(share + encodeURIComponent(url) + '&t=' + encodeURIComponent(t), 'sharer', windowFeatures);
        return false;
    }

    // player event dispatcher (wrapper)
    function on(event, callback) {
        switch (event) {
            case 'start':
                window.addEventListener('start', callback);
                break;
            case 'finish':
                window.addEventListener('finish', callback);
                break;
            case 'error':
                window.addEventListener('error', callback);
                break;
        }
    }

    // check if TogetherJS is running but didn't recieve the event "ready"
    function checkStartStatusOfTogetherJS() {
        if (window.parent.model.IsOwner) {
            if (TogetherJS.running && TogetherJS.shareUrl()) {
                if (!window.IAmPresentor) {
                    TogetherJSReadyForOwner();
                }
            } else {
                setTimeout(checkStartStatusOfTogetherJS, 1000);
            }
        }
    }

    // *** Listener message ***////

    window.addEventListener('message', function (event) {
        var data;
        if (!event || !event.data) return;
        try {
            data = JSON.parse(event.data);
            if (data.startRemoteSession) {
                if (TogetherJS) {
                    TogetherJS(window);
                }
            } else if (data.startRemoteSessionForViewer) {
                if (RemoteControl && RemoteControl.onload)
                    RemoteControl.onload();
            }
        } catch (e) { }

    }, false);

    /*** Utilities ***/

    // return slide number from veriable "presentSlideNumber" - using in the mobile for target links
    function getSlideNumberNoHash() {
        return presentSlideNumber || 1; //3/7/2017 asaf: dded || 1 in case there is issue with slide number.
    }

    function getSlideNumberFromSlideName(name) {
        if (!slidedeck) {
            //must return a temp value for now, untill slide deck is available.
            return 1;
        }
        var decodedName = decodeURIComponent(name);
        for (var i = 0; i < slidedeck.slideSettings.length; i++) {
            if (decodeURIComponent(slidedeck.slideSettings[i].name) === decodedName) {
                return i + 1; //slide index is 1 based
            }
        }
        return 1;  //default to first slide if not found. could be from broken link after slide name has changed a link to the slide was saved.
    }
    //updates the global has variable. returs the slide number corresponding to the hash
    function updateHash(href) {

        //hash is global variable in the player
        hash = href.substr(1).replace('/', '');//trim out the # and remove "/" if this is mobile or tablet device

        if (!hash) {
            hash = 1;
            return hash; //retun default value of first slide
        }

        //hash is a direct link to slide number
        if (!isNaN(hash)) {
            hash = Math.min(+hash || 1, slidesSize || Infinity);  //enforce positive number, max value, and no zero.
            return hash;
        }

        //hash is to slide name. supported only in websites. trim the 'slidename=', if present
        if (EM.isWebsite) {
            hash = hash.replace('slidename=', '')
            return getSlideNumberFromSlideName(hash);
        }

        //hash is to slide number, could be website or presentations
        if (/slidenum=/i.test(hash)) {
            hash = hash.replace('slidenum=', '');
            return hash;
        }



        // support for prev, next, last, first slide links in the hash. only supported in presentations, but left for bakwards compatability in old websites
        switch (hash) {
            case 'prev':
                hash = presentSlideNumber - 1;
                return hash;
            case 'next':
                hash = presentSlideNumber + 1;
                return hash;
            case 'first':
                hash = 1;
                return hash;
            case 'last':
                hash = slidesSize;
                return hash;
            default:
                hash = 1; //if all else fails, default to first slide
                return hash;
        }
    }


    function getSlideNumber() {

        return options && options.navigateViaHashChange ? updateHash(window.location.hash) : getSlideNumberNoHash();
    }

    // remove player loader when scene is ready
    function removeLoader() {
        $('#player-loader').fadeOut(600, function () {
            $(this).addClass('hidden');
        });
    }


    // Update the $currentSlide global var and mark current slide with a class
    function updateCurrentSlide() {
        try {


            // Update current Slide
            $currentSlide = scene.getCurrentSlide();

            // Generic scene handle it's own current-active-slide
            if ($currentSlide && $currentSlide.length) {
                if (!$currentSlide.hasClass('slide_g')) {
                    // Update current-active-slide class on required slide
                    $('.current-active-slide').removeClass('current-active-slide');
                    $currentSlide.addClass('current-active-slide');
                    // We want that each slide always scrolls up after transitionDone Event
                    $currentSlide[0].scrollTop = 0;
                    //moved this code to scene transition done
                    //  if (!context.isDownload) {
                    // must re-draw the charts for hover effects to work on the chart. 
                    //       EM_Graphs.redrawChartsInSlide($currentSlide); 
                    //   }
                }
            }
            playerSlider();

        } catch (e) {
            console.error(e);
        }

    }

    // Updating the player GUI during presentation run
    function updateGUI() {
        var isPublic = EM.scenemanager.presentation.userInfo.isPublic;

        // First slide
        if (presentSlideNumber == 1) {
            $('.leftButton').prop('disabled', true);

            if (slidesSize > 1) {
                $('.rightButton').prop('disabled', false);
            } else {
                if (isPublic) {
                    $('.rightButton').prop('disabled', false);
                } else {
                    $('.rightButton').prop('disabled', true);
                }
            }
            // We are somewhere in the middle
        } else if (presentSlideNumber > 1 && presentSlideNumber < slidesSize) {
            $('.leftButton').add('.rightButton').prop('disabled', false);

            // Last slide
        } else if (presentSlideNumber == slidesSize) {
            // We have more then one slide, so we can go back to one
            // and move forward to pop sharing div
            $('.leftButton').prop('disabled', false);
            if (!isPublic) {
                $('.rightButton').prop('disabled', true);
            } else {
                $('.rightButton').prop('disabled', false);
            }

            // We shouldn't get here, but if we do enable control
        } else {
            $('.leftButton').add('.rightButton').prop('disabled', false);
        }

    }

    // Setting the presentation scale marks on the GUI slider
    function setSliderMarks() {
        var $slider = $('#slider'),
            step = 100 / (slidesSize - 1),//Steps for mark positioning
            position = 0,//current mark position
            isSection = false;// Mark to add next mark as a section mark

        for (i = 0; i < sectionsSize; i++) {
            var sections = slidedeck.sections[i];

            isSection = true;

            for (var j = 0; j < sections.slides.length; j++) {
                // Add regular slide mark

                if (isSection) {
                    $slider.append('<a href="#" class="ui-slider-mark-section ui-state-default ui-corner-all" style="left:' + position + '%;"></a>');
                } else {
                    $slider.append('<a href="#" class="ui-slider-mark ui-state-default ui-corner-all" style="left:' + position + '%;"></a>');
                }

                position += step;
                isSection = false;
            }
        }

    }

    function clearSliderMarks() {
        $('.ui-slider-mark').remove();
    }

    // Create the Sections screen (agenda)
    function buildSectionsScreen() {
        var WIDTH = 1920;
        var SCALED = 185 / WIDTH;
        var HEIGHT = 1080;

        $("#agendaButton").css("background", "#515151");
        $("#slidesButton").css("background", "#ee4c4e");

        if (slidedeck) {
            $("#sectionsTitle").html(EM.scenemanager.presentation.core.name);
            var $sectionList = $("#sectionList");
            $sectionList.empty();
            var counter = 0;
            var sCounter = 0; //Sections counter

            for (var i = 0; i < slidedeck.sections.length; i++) {
                var section = slidedeck.sections[i];
                var aSection = '<div id="section_' + (i + 1) + '" data-slide="' + (sCounter + 1) + '" class="sectionsSlidesSectionNames">\n' + section.title + '</div>';

                $sectionList.append(aSection);

                sCounter += section.slides.length;
                $("#section_" + (i + 1)).click(function () {
                    hideSectionsFrame();
                    go(+this.getAttribute("data-slide"));
                });

                $sectionList.append("<div id='dummy_" + (i + 1) + "' class='agenda-slides-wrapper'></div><div class='clearfix' style='height: 15px;'></div>");

                var $section = $("#dummy_" + (i + 1));

                for (var j = 0; j < counter; j++) {
                    $section.append("<div class='slide-wrapper' style='display:none'></div>");
                }

                for (var s = 0; s < section.slides.length; s++) {
                    counter++;
                    var aSlide = '<div id="slider_' + (counter) + '" data-slide="' + (counter) + '" class="aSectionSlide slide-wrapper">\n' +
                        '</div>';
                    $section.append(aSlide);
                    var $slideFrame = $('#slider_' + (counter));
                    $slideFrame.append(section.slides[s]);
                    var $theSlide = $slideFrame.children(":first");

                    toggleTransformOnSlideElements($theSlide);

                    $theSlide.css('width', '' + WIDTH + 'px');
                    $theSlide.css('height', '' + HEIGHT + 'px');
                    $theSlide.css('-webkit-transform-origin', '0 0 0');
                    $theSlide.css('-moz-transform-origin', '0 0 0');
                    $theSlide.css('-ms-transform-origin', '0 0 0');
                    $theSlide.css('transform-origin', '0 0 0');
                    $theSlide.css('-webkit-transform', 'scale(' + SCALED + ')');
                    $theSlide.css('-moz-transform', 'scale(' + SCALED + ')');
                    $theSlide.css('-ms-transform', 'scale(' + SCALED + ')');
                    $theSlide.css('transform', 'scale(' + SCALED + ')');

                    $slideFrame.click(function () {
                        hideSectionsFrame();
                        go(+this.getAttribute("data-slide"));
                    });

                    $('#sectionsClose').click(function () {
                        hideSectionsFrame();
                    });
                }
            }

            EM.scenemanager.ezLoadImages('#sectionList');
        }
    }

    // Hide the sections frame
    function hideSectionsFrame() {
        $("#sectionList").add('#sectionsTitle').empty();
        $("#sectionsFrame").css("visibility", "hidden");
        showingSections = false;
    }

    // Helper method for scaling slide elements
    function toggleTransformOnSlideElements($container, toggle) {
        if ($container && $container.length) {
            var $elements = $container.find('[data-transform]');

            if (toggle) {
                $elements.each(function () {
                    var transformVal = $(this).attr('data-transform');
                    var $this = $(this);
                    var trnsformStr = ['transform:', transformVal, '; -webkit-transform:', transformVal, '; -moz-transform:', transformVal, '; -ms-transform:', transformVal, ';'].join('');
                    $this.css('transform', '');
                    var styleAttr = $this.attr('style') || '';
                    $this.attr('style', styleAttr.concat(trnsformStr));
                });

            } else {
                $elements.css({
                    'transform': 'none',
                    '-webkit-transform': 'none',
                    '-moz-transform': 'none',
                    '-ms-transform': 'none'
                });
            }
        }
    }

    function displayUserAndPresentationInfo(timeToDisplayInSec) {
        $('#player-logo').add('#presentation-info').addClass('show');
        clearTimeout(infoTimeout);
        infoTimeout = setTimeout(function () {
            $('#player-logo').add('#presentation-info').removeClass('show');
        }, timeToDisplayInSec * 1000);
    }

    // Show the GUI and hide presentation information & logo after 3 seconds
    function showGUI(e) {

        // don't show emaze controls when video in full screen
        var elementFullScreen = document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement || document.fullScreenElement;
        if (elementFullScreen != null && elementFullScreen.nodeName == 'VIDEO')
            return;

        if (EM.compatibility.getDevice() === "tablet") {
            $('#buttonsPanel')
                .add('.leftButton')
                .add('.rightButton')
                .add('#offline-analytics-indicator')
                .add('#menu-container').addClass('show tablet');

            $('#timelinebutton').addClass('show hometablet');

        } else {
            $('#buttonsPanel')
                .add('.leftButton')
                .add('.rightButton')
                .add('#offline-analytics-indicator')
                .add('#menu-container')
                .add('#timelinebutton').addClass('show');

            // Click is triggering tap, and we want to disable logo and info
            // visibility to once, so it won't trigger on clicks
            //if ( !limitShowInDesktop ){
            //    $('#player-logo').add('#presentation-info').addClass('show');
            //    limitShowInDesktop = true;
            //}
        }

    }

    // Hide GUI
    function hideGUI() {
        $('#buttonsPanel')
            .add('.leftButton')
            .add('.rightButton')
            .add('#menu-container')
            .add('#offline-analytics-indicator')
            .add('#timelinebutton').removeClass('show');

        clearTimeout(timeout);
    }

    // Hide all GUI controls forever
    function hideGUIForever() {
        $('#buttonsPanel')
            .add('.leftButton')
            .add('.rightButton')
            .add('#timelinebutton')
            .add('#player-logo')
            .add('#menu-container')
            .add('#presentation-info').removeClass('show').addClass('hidden');
    }

    // Partial Hide player controls forever
    function hideControls(option) {
        if (overRideHideControls)
            return;
        switch (option) {
            // hide all but slider
            case 1:
                $('.leftButton')
                    .add('.rightButton')
                    .add('#timelinebutton').removeClass('show').addClass('hidden');
                break;
            // hide all but arrows
            case 2:
                $('#buttonsPanel')
                    .add('#timelinebutton').removeClass('show').addClass('hidden');
                break;
            // hide all
            case 0:
            default:
                $('#buttonsPanel')
                    .add('.leftButton')
                    .add('.rightButton')
                    .add('#timelinebutton').removeClass('show').addClass('hidden');
                break;

        }
    }

    // Hide top right menu
    function hideMenu() {
        $('#menu-container').removeClass('show').addClass('hidden');
    }

    // for website with parameter "noscroll" cancel scroll from slides
    function cancelScrollBarFromSlide() {
        $('.slide, .slide_g').each(function () { this.style.setProperty('overflow', 'hidden', 'important'); });
        $('.slide, .slide_g').scrollTop(0);
    }

    // Handle GUI appearance when mouse move
    // GUI will be hidden after 1 seconds
    function mouseMoveGUIHandler(e) {

        // don't show emaze controls when video in full screen
        var elementFullScreen = document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement || document.fullScreenElement;
        if (elementFullScreen != null && elementFullScreen.nodeName == 'VIDEO')
            return;

        mouseThreshold++;

        if (mouseThreshold > 2) {
            if (e.type != undefined) {
                $(['#buttonsPanel',
                    '.leftButton',
                    '.rightButton',
                    '#menu-container',
                    '#offline-analytics-indicator',
                    '#timelinebutton'].join(', ')).addClass('show');
            }
            mouseThreshold = 0;
        }

        resetTimer();
    }

    function resetTimer() {
        clearTimeout(timeout);
        timeout = setTimeout(hideOnTimeExpire, 1000);

    }

    function hideOnTimeExpire() {
        // If user interact with any of player controls, reset timeout timer

        var hoverSelector = ".player-button:hover, #buttonsPanel:hover, .ui-state-default:hover, .rightButton:hover, .leftButton:hover, #menu-container:hover, #offline-analytics-indicator:hover";

        if ($(hoverSelector).length) {
            resetTimer();
        } else {
            hideGUI();
        }
    }

    // TODO: make more organized with separate function
    $('#slider').slider().mousemove(function (e) {
        var width = $(this).width(),
            offset = $(this).offset(),
            options = $(this).slider('option'),
            value = Math.round(((e.clientX - offset.left) / width) * (options.max - options.min)) + options.min;

        $('.the-content').empty();

        setPreviewContentByPosition(value - 1);

    });

    // Position the preview thumbnail above hovered tick mark
    function previewPosition(e) {
        var $this = $(this),
            position = $this.position().left,  // get tick position in slider
            offset = $(this).offset().left,  // get tic offset from the left of the player
            $preview = $('.preview'),
            $chupchik = $('.chupchik');
        // if the oofset biger then half of the preview div
        if (offset > 150) {
            $preview.css('left', position - 150);
            $chupchik.css('left', '50%');
        } else {
            $preview.css('left', -($('#slider').position().left) + 4);
            // if the current slide circle on the tick
            $chupchik.css('left', offset - $this.hasClass('ui-slider-handle') ? 1 : 5);
        }
    }

    // Set scaled slide in the preview thumb when hovering slider tick mark
    function setPreviewContentByPosition(pos) {
        var slide = EM.scenemanager.getSlideByPosition(pos),
            $content = $('.the-content'),
            $slides;


        $('.preview > .slide-wrapper:not(.the-content)').remove();

        for (var i = 0; i < pos; i++) {
            $('.preview').prepend('<div class="slide-wrapper"></div>');
        };

        $content.addClass('slide-wrapper');

        $(slide).appendTo($content);

        $slides = $content.children('.slide');
        $slides.css(browserPrefix('transform-origin', '0 0'));

        scaleElement($slides, $content, 0);

        $('.section-name').text(EM.scenemanager.getSectionNameBySlide(pos));
        $('.slide-number').text((pos + 1) + '/' + slidesSize);
    }

    // Scale element and return it's scale factor
    function scaleElement($element, $context, margin) {
        margin = margin || 0;
        var
            w = $element.width(),
            h = $element.height(),
            dw = $context.width() - margin,
            dh = $context.height() - margin,
            widthDelta,
            heightDetla,
            minDelta;

        widthDelta = dw / w;
        heightDetla = dh / h;
        minDelta = Math.min(widthDelta, heightDetla);

        setScale($element, minDelta);

        $element.attr('scale-factor', minDelta); //CODEREVIEW:  this may/maynot be needed here. copy/pasted from editor where it is relevant for draggable operations

        return minDelta;
    }

    //TODO: function for check on contentTypeId
    // ezContentTypeId - ezContentTypeName
    //               1 - Presentation
    //               2 - Landing Page
    //               3 - Catalog
    //               4 - E-Card
    //               5 - Magazine
    //               6 - Mini-Site
    //               7 - Playful
    //               8 - Visual-Story
    //               10 - Visual-Story
    //               11 - Visual-Story
    function isHideByContentType(nameOfControl) {
        if (overRideHideControls)
            return;
        switch (ezContentType) {
            // if presentations - show all controls
            case null:
            case 0:
            case 1:
                return false;

            // landing page & minisite - hide all controls
            case 2:
            case 6:
                return true;
            // catalog: show arrows with timeline (hide only the menu)
            case 3:
                switch (nameOfControl) {
                    case "hidebuttons":
                        return false;
                    case "hidecontrols":
                        return false;
                    case "hidemenu":
                        return true;

                    default:
                        return true;
                };

            //Ecard, visual story, Magazine: show arrows and menu(hamburger) - hide the timeline
            case 4:
            case 5:
            case 8:
            case 11:
                switch (nameOfControl) {
                    case "hidebuttons":
                        return false;
                    case "hidecontrols":
                        return true;
                    case "hidemenu":
                        return false;

                    default:
                        return true;
                };
            case 7: //show only arrows
                switch (nameOfControl) {
                    case "hidebuttons":
                        return false;
                    case "hidecontrols":
                        return true;
                    case "hidemenu":
                        return true;

                    default:
                        return true;
                };

            // others - yes, hide
            default:
                return true;
        }
    }


    // Check params existence in URL and perform matching actions
    // url param: 
    // hidebuttons, isHideButtons - remove all controls (arrows, buttonsPanel(timeline), menuControl(burger)
    // hidecontrols - remove the timeline
    function triggerParamsActions() {
        if (checkURLParam('autoplay') || checkURLParam('isAutoPlay')) playWrap();
        if (checkURLParam('agenda')) sectionsScreen();
        if (checkURLParam('hidebuttons') || checkURLParam('isHideButtons') || isHideByContentType('hidebuttons')) hideGUIForever();
        if (isHideByContentType('hidecontrols')) hideControls(2);
        if (checkURLParam('hidecontrols')) hideControls(+getParameterByName('hidecontrols'));
        if (checkURLParam('hidemenu') || isHideByContentType('hidemenu')) hideMenu();
        if (checkURLParam('stop')) defaultStopDuration = +getParameterByName('stop');
        if (checkURLParam('hideprofile')) $('#player-logo, #presentation-info').hide();
        if (checkURLParam('noscroll')) cancelScrollBarFromSlide();
    }

    // Returns parameter value by it's name
    function getParameterByName(name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    }

    // return true if term located in URL
    function checkURLParam(term) {
        var url = window.location.href;

        if (url.indexOf('?' + term) != -1)
            return true;
        else if (url.indexOf('~' + term) != -1 || url.indexOf('&' + term) != -1)
            return true;

        return false;
    }

    //added to remove bottom banner for evmotors player/emaze.me
    function checkURLParam1(term) {
        var url = window.location.href;

        if (url.indexOf(term) != -1)
            return true;

        return false;
    }


    function setPresentationInfo() {
        var pName = EM.scenemanager.presentation.core.name,
            oName = EM.scenemanager.presentation.userInfo.userName,
            oPage = EM.scenemanager.presentation.userInfo.userPage,
            oImage = EM.scenemanager.presentation.userInfo.userImage;

        $('.presentation-title').text(pName).attr('title', pName);
        $('.presentation-author').text(oName);

        if (!context.isOffline) {
            // update author name to serve as link to his personal page
            $('.presentation-author').attr('href', oPage);
            if (oImage) {
                $('#player-logo').attr('href', oPage);
            }
        } else {
            $('#player-logo').remove();
            $('<p class="presentation-author">' + oName + '</p>').appendTo('#presentation-info');
            $('#presentation-info').css('left', '14px');
        }


    }

    function setPlayerCookies() {
        var isPureUser = $.cookie('ezaffid') === undefined && $.cookie('ezcampid') === undefined && $.cookie('ezsubid') === undefined;
        if (isPureUser && !context.isEditor) {
            $.cookie('ezaffid', 'player', { expires: 365, domain: 'emaze.com' });
            $.cookie('ezcampid', EM.scenemanager.presentation.core.presentationId, { expires: 365, domain: 'emaze.com' });
            $.cookie('ezsubid', EM.scenemanager.presentation.userInfo.userID, { expires: 365, domain: 'emaze.com' });
            $.cookie('ezaffidOriginal', 'player', { expires: 365, domain: 'emaze.com' });
            $.cookie('ezcampidOriginal', EM.scenemanager.presentation.core.presentationId, { expires: 365, domain: 'emaze.com' });
            $.cookie('ezsubidOriginal', EM.scenemanager.presentation.userInfo.userID, { expires: 365, domain: 'emaze.com' });
        }
    }

    function isPresentationPage() {
        try {
            var url = (window.location != window.parent.location) ? document.referrer : document.location;
            return url.indexOf("www.emaze.com/@") != -1 || url.indexOf("presid") != -1;
        } catch (e) {
            return false;
        }
    }

    //=============== Functions For Analytics =======================
    function getOfflineAnalytics() {
        try { return localStorage.getItem(OFFLINE_ANALYTICS_KEY); } catch (e) { return null; };  //try/catch in case localstorage not supported
    }

    function storeAnalyticsInLocalStorage(label) {
        var labels = JSON.parse(getOfflineAnalytics()) || [];
        label.IsOffline = true;
        labels.push(label);
        localStorage.setItem(OFFLINE_ANALYTICS_KEY, JSON.stringify(labels));
        $('#offline-analytics-indicator').addClass('on');
    }

    function sendOffLineAnalytics() {
        var labelsString = getOfflineAnalytics();

        if (labelsString) {         //TODO: create this function in the event server
            var url = isEventServer ? "https://event.emaze.com/analytic/Batch" : "http://127.0.0.1:81/analytic/Batch";
            $.post(url, { eventsString: labelsString }, function (data) {
                if (!data.error) {
                    localStorage.removeItem(OFFLINE_ANALYTICS_KEY); //clear the data from local storage since its been sent to server TODO: what if more data is gathered whle waiting for server response? it will be lost here
                    $('#offline-analytics-indicator').removeClass('on'); //if there are offline analytics, show the button, else hide
                    isOfflineAnalytics = false;
                } else {
                    console.log(data.error);
                }

            }).fail(function () {
                //TODO: inform user that sending the analytics failed, check network connection OR jut try on next load of player
            }).always(function () {

            });
        }
    }

    function sendAnalyticsEvent(type, slideData) {
        try {

            if (!EM.scenemanager.presentation.userInfo.createDateOwner) // layouts player for example
                return;

            var createUserDate = new Date(EM.scenemanager.presentation.userInfo.createDateOwner);
            var m = createUserDate.getMonth();
            createUserDate.setMonth(m + 1);
            if (!EM.scenemanager.presentation.userInfo.isOwnerPremium && createUserDate < new Date()) {
                return;
            }
            var datetime = new Date();

            var label = {
                PresentationId: EM.scenemanager.presentation.core.presentationId,
                DateView: datetime,
                GmtZone: datetime.getTimezoneOffset(),
                Type: type,
                IsOffline: false,
                IsPremium: EM.scenemanager.presentation.userInfo.isOwnerPremium
            };

            if (!context.isStatic) {
                label = $.extend(label, {
                    UserName: $.cookie('ezlogged') === $.undefined ? keyusername : $.cookie('ezlogged'),
                    VApp: domainName,
                    FullName: $.cookie("ezfullname"),
                    Alias: $.cookie("ezalias")
                });
            } else {
                label = $.extend(label, {
                    UserName: EM.scenemanager.presentation.userInfo.userEmail,
                    VApp: EM.scenemanager.presentation.userInfo.domain,
                    FullName: EM.scenemanager.presentation.userInfo.userName,
                    Alias: EM.scenemanager.presentation.userInfo.userAlias
                });
            }

            if (slideData) {
                label = $.extend(label, slideData);
            }
            if (isOfflineAnalytics) {
                storeAnalyticsInLocalStorage(label);
            } else {
                var url = isEventServer ? "https://event.emaze.com/analytic" : "http://127.0.0.1:81/analytic";
                $.post(url, { eventString: JSON.stringify(label) }, function (data) {
                    console.log(data);
                }).fail(function () {
                    if (context.isOffline) { //in download player, switch to offline analytics on first ajax fail for the duration of the sesstion.
                        isOfflineAnalytics = true;
                        storeAnalyticsInLocalStorage(label);
                    }
                });
            }
        } catch (e) {
            console.warn(e);
        }
    }

    function sendEventOpenPresentation() {
        sendAnalyticsEvent("open");
    }

    function sendEventSlideClose(slideNum, viewDuration) {
        sendAnalyticsEvent("slide", { SlideNumber: slideNum, TimeView: viewDuration });
    }

    function sendEventClosePresentation() {
        sendAnalyticsEvent("close");
    }

    function googleTagEvent(label, event) {
        if (typeof dataLayer !== 'undefined')
            dataLayer.push({ 'label': label, 'event': event });
    }

    function isPlayerReady() {
        return !firstLoad;
    }

    function labelForEvent(label) {
        return JSON.stringify(label).replace(/\"/g, '\\\\\\\"'); // replace " with \\\"
    }

    //=============== End Functions For Analytics ===================

    return {
        init: init,
        goToSlide: go,
        nextSlide: next,
        prevSlide: prev,
        playButton: playWrap,//left here in case its being called from somewhere
        play: play, //! interface provided to the emaze to vidoe convert service
        reload: reload,
        changeTheme: changeTheme,
        removeLoader: removeLoader,
        updateHash: updateHash,
        getSlideNumber: getSlideNumber,
        sharePopup: sharePopup,
        isPresentationPage: isPresentationPage,
        on: on,
        setScale: setScale,
        context: context,
        getSlideCount: getSlideCount,
        fullScreen: fullScreen,
        isFullScreen: isFullscreen,
        getSlideNumberNoHash: getSlideNumberNoHash,
        isPlaying: isPlaying,
        isPlayerReady: isPlayerReady, // player is loaded
        stateCalled: stateCalled,
        getSlidedeck: getSlidedeck,
        claimSiteClicked: claimSiteClicked,
        claimContentClicked: claimContentClicked,
        claimContentClickedGotoMyPres: claimContentClickedGotoMyPres
    }

}(jQuery));

