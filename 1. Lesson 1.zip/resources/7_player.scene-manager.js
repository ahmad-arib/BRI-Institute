
//#region polyfills
if (!String.prototype.endsWith) {
    String.prototype.endsWith = function(searchString, position) {
        var subjectString = this.toString();
        if (typeof position !== 'number' || !isFinite(position) || Math.floor(position) !== position || position > subjectString.length) {
            position = subjectString.length;
        }
        position -= searchString.length;
        var lastIndex = subjectString.indexOf(searchString, position);
        return lastIndex !== -1 && lastIndex === position;
    };
}

//#endregion


EM.scenemanager = (function($){
    
    var isStatic = $('html').data('static') === true,
        isCompatible = true,
        slidedeck,//parsed slidedeck
        attempt = 0, //presentation object fetching attempts
        isSlideBox,
        imageOptimizer = {
            screenScaleFactor: 1, //the max scale factor if user goes full screen used for image optimization
            enableResize: true,
            enableLazyload: true,
            disableGifs: true,
            parallaxTreshold : 0.7 //the screenScale factor at which we want to optimize parallax images.
        },
        optimizer = { //object that holds optimization settings about the presentation
            hasVideos: false,
            preLoadSlides: 1, //numeric for future support of multiple slides. currently supports just the next slide. set to zero to de-activate
            $preLoader : null
        };
    optimizer.analyzeSlide =  function(slideHtml) { //if any slide is encountered that has videos in it, set hasVideos to true to enable (inefficient) video bugfix woraround in chrome
        if(slideHtml.indexOf('<video') !== -1) {
            optimizer.hasVideos = true;
        }
    }
    var bannerHtml = '<div class="edit-wrapper wrapper-style-sd-text_3" style="position: absolute; top: @textTop@px; left: 550px; z-index: 2147483646; width: 1176.98px; height: 25.7778px;" tabindex="200" data-banner="true"><div contenteditable="false" tabindex="100" class="style-sd-text_3 sd-text-font-family_3 sd-text-line-height-2" style="font-size:16px; font-family:\x27asap\x27; width: 100%; height: 100%; color: rgb(255, 255, 255);">This website was created with  <a class="ms-banner-link" target="_blank" href="https://www.emaze.com"><span class="">emaze.com</span></a>  editor &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; click  <a class="ms-banner-link" target="_blank" href="https://www.emaze.com/website-generator/"><span class="">HERE</span></a>  to create your free website</div></div><div class="edit-wrapper wrapper-style-sd-shape_1" style="position: absolute; height: 41.7778px; width: 1920px; top: @shapeTop@px; left: -2px; z-index: 2147483645;" tabindex="200" data-banner="true"><svg class="sd-element-shape style-sd-shape_1 sd-shape-fill_3" width="480px" height="480px" viewBox="0 0 480 480" preserveAspectRatio="none" style="width: 100%; height: 100%; fill: rgb(49, 49, 49);"><g><rect x="0" y="0" width="100%" height="100%"></rect></g></svg></div><div class="edit-wrapper wrapper-style-sd-image_1" style="position: absolute; top: @iconTop@px; left: 957px; z-index: 2147483647; height: 26px; width: 32px;" tabindex="200" data-banner="true"><img class="sd-element-image style-sd-image_1 sd-image-border-color_none initial-size-constraint" src="https://resources.emaze.com/vbcommon/images/logo_small.png" data-img-size="32,26" style="width: 32px; height: 26px;"></div>';
    var bannerZoomerHtml = '<div  style="position: absolute; bottom: @textBottom@px; left: 300px; z-index: 2147483646; width: 1178px; height: 26px;"><div  class=" sd-text-font-family_3 sd-text-line-height-2" style="font-size:16px; font-family:\x27asap\x27; width: 100%; height: 100%; color: rgb(255, 255, 255);">This website was created with  <a class="ms-banner-link" target="_blank" href="https://www.emaze.com"><span class="">emaze.com</span></a>  editor &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; click  <a class="ms-banner-link" target="_blank" href="https://www.emaze.com/website-generator/"><span class="">HERE</span></a>  to create your free website</div></div><div style="position: absolute; height: 42px; width: 1920px; bottom: @shapeBottom@px; left: -2px; z-index: 2147483645;"><svg class="sd-element-shape style-sd-shape_1 sd-shape-fill_3" width="480px" height="480px" viewBox="0 0 480 480" preserveAspectRatio="none" style="width: 100%; height: 100%; fill: rgb(49, 49, 49);"><g><rect x="0" y="0" width="100%" height="100%"></rect></g></svg></div><div  style="position: absolute; bottom: @iconBottom@px; left: 700px; z-index: 2147483647; height: 26px; width: 32px;" ><img class="sd-element-image style-sd-image_1 sd-image-border-color_none" src="https://resources.emaze.com/vbcommon/images/logo_small.png"  style="width: 32px; height: 26px;"></div>';
    var bannerHtmlNoScroll = '<div style="position: absolute; bottom: @textBottom@px; left: 550px; z-index: 2147483646; width: 1176.98px; height: 25.7778px;" tabindex="200" data-banner="true"><div contenteditable="false" tabindex="100" class="style-sd-text_3 sd-text-font-family_3 sd-text-line-height-2" style="font-size:16px; font-family:\x27asap\x27; width: 100%; height: 100%; color: rgb(255, 255, 255);">This website was created with  <a class="ms-banner-link" target="_blank" href="https://www.emaze.com"><span class="">emaze.com</span></a>  editor &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; click  <a class="ms-banner-link" target="_blank" href="https://www.emaze.com/website-generator/"><span class="">HERE</span></a>  to create your free website</div></div><div style="position: absolute; height: 41.7778px; width: 1920px; bottom: @shapeBottom@px; left: -2px; z-index: 2147483645;" tabindex="200" data-banner="true"><svg class="sd-element-shape style-sd-shape_1 sd-shape-fill_3" width="480px" height="480px" viewBox="0 0 480 480" preserveAspectRatio="none" style="width: 100%; height: 100%; fill: rgb(49, 49, 49);"><g><rect x="0" y="0" width="100%" height="100%"></rect></g></svg></div><div style="position: absolute; bottom: @iconBottom@px; left: 957px; z-index: 2147483647; height: 26px; width: 32px;" tabindex="200" data-banner="true"><img class="sd-element-image style-sd-image_1 sd-image-border-color_none initial-size-constraint" src="https://resources.emaze.com/vbcommon/images/logo_small.png" data-img-size="32,26" style="width: 32px; height: 26px;"></div>';
    var isZoomer;
    var sceneReadyTimeoutCounter = 0;
    var onePage = getUrlParameter("onePage");
    /*** Public methods ***/




    function mobileIphoneScrollFix() {

        if (EM.isMobileSlides && window.location.href.lastIndexOf('emaze.me/selfi123?system=staging') !== -1) {

            $('[href*="player.css"]').attr('href', $('[href*="player.css"]').attr('href').replace('player.css', 'player-mobile-scroll-test.css')); //remove the offending css file that messed with iphoen scroll untill we isolate the issue
            
            $('#buttonsPanel, #presentation-info').remove(); //no navigation buttons in mobile slides  player

            function recursiveScrollModification($element) {
                var $parent = $element.parent();

                if ($parent.is('body')) {
                    $parent.css('overflow-y', 'auto');
                } else {
                    $parent.css('overflow-y', 'visible');
                    recursiveScrollModification($parent);
                }
            }

            $('#scene').on('transitionDone', function () {
                var $slide = $('.current-active-slide');
                $slide.css('height', $slide[0].scrollHeight);

            });

            $('#scene').one('transitionDone', function () {
                //not inside of slide, and not the body element
                $(' :not(.slide)  *:not(body)').one('scroll', function () {
                    $(this).css('height', this.scrollHeight);
                });
                var $slide = $('.current-active-slide');
                recursiveScrollModification($slide);
            });

        }
    }

    function init(id) {

        //fix object presentation from publish for emaze.me site
        if (window.location.hostname === "emaze.me") {
            if (presentation && presentation.Data) {
                presentation = presentation.Data;
            }
        }
        
        mobileIphoneScrollFix();

        imageOptimizer.enableResize = !EM.player.context.isOffline && window.location.href.indexOf('fullsizeimages') === -1 && !EM.isLayoutsPlayer;
        imageOptimizer.screenScaleFactor = Math.round(Math.min((window.innerWidth || window.screen.width) / (EM.isMobileSlides ? 320 : 1920), (window.innerHeight || window.screen.height) / (EM.isMobileSlides ? 760 : 1080)) * 100) / 100;
       
        if(optimizer.preLoadSlides) {
            $preLoader = $('<div id="pre-loader">').appendTo('#scene');
            $('#scene').on('transitionDone', function () {
                var slideNum = scene.currentSlideNum();
                var slides = slidedeck.sections.reduce(function (prev, current) { return prev.concat(current.slides); }, []); //TODO do this only once every time slide deck changes.
                var $slide;
                //TODO: problems: 1. the image optimizer will wipe out the image urls, making this useless until image src is set from data-src. possible alternate implementatrion is ot have the scen expore a getslidehtml function that returnt he html that it has stored for that slide.
                var targetSlide = slides[slideNum]; //no need to do plus one to get next slide because slidies is zero based but slide num is 1 based.
                if(targetSlide) {
                    $slide = $(targetSlide);
                    siteMenuClickFixer(slideNum); 
                    if (imageOptimizer.enableLazyload) { //amke sure the images are there for preloading
                        $slide.find('img[src="//resources.emaze.com/vbplayer/images/blanky.png"]').each(function () {
                            this.setAttribute('src', this.getAttribute('data-src'));
                        });
                    }
                    $preLoader.empty().append($slide.find('img'));
                }
            });
        }

        /* Set listeners */
        
        // Presentation Object is ready, start setting the presentation technology and assets
        $(window).one( 'presentationObjectReady', technologyWorker.init );
        

        //show the custom theme loader when relevant.
        $(window).one('presentationObjectReady', function () {
            if(EM.scenemanager.presentation.theme.logoImage){
                $('.emazeloader').css('background-image', ['url(', EM.scenemanager.presentation.theme.logoImage, ')'].join(''));
            }
        });

        // invoke DOM setup for the current presentation slidedeck
        $(window).one('technologyReady', slidesWorker.init);


        // ezload slidedeck images
        $(window).on('sceneReady', function(){ 
            if (imageOptimizer.enableLazyload) {
                gradualImageLoader('#slide-box');
            }
        });


        if (!EM.isMobileSlides) {
            // Get presentation thumbnail image and set in loader background
            setLoaderThumb(id);
        }

        // Get the presentation object and start initialization
        getPresentationObject(id);

    }

    function siteMenuClickFixer(slideNum) {
        var _menuSelected = document.getElementsByClassName("em-menu")[0];
        if (_menuSelected != undefined) {
            var _selectedItem = _menuSelected.getElementsByClassName("selected")[0];
            if (_selectedItem != undefined) {
                _selectedItem.classList.remove("selected");
            }
            var href = _menuSelected.getElementsByTagName("a");
            var replacedHash = "#" + slideNum;
            for (var i = 0, l = href.length; i < l; i++) {
                var el = href[i].getAttribute("href");
                if (el === replacedHash) {
                    var _needSelect = href[i].parentElement;
                    _needSelect.classList.add("selected");
                    break;
                }
            }
           
        }
    }

    //maybe not need
    //function siteMenuClickFixer(baseURI) {
    //    var _menuSelected = document.getElementsByClassName("em-menu")[0];//.getElementsByClassName("selected")[0];
    //    if (_menuSelected != undefined) {
    //        var _selectedItem = _menuSelected.getElementsByClassName("selected")[0];
    //        if (_selectedItem != undefined) {
    //            _selectedItem.classList.remove("selected");
    //        }
    //        var indSharp = baseURI.lastIndexOf("#");
    //        var nameMenu = baseURI.substr(indSharp);
    //        //var replacedHash = e.currentTarget.hash.replace("#0", "#");
    //        var href = _menuSelected.getElementsByTagName("a");
    //        for (var i = 0, l = href.length; i < l; i++) {
    //            var el = href[i].getAttribute("href");
    //            if (el === nameMenu) {
    //                var _needSelect = href[i].parentElement;
    //                _needSelect.classList.add("selected");
    //                break;
    //            }
    //        }
    //    }
    //}
    

    // Clear and reset scene and it's required assets
    // in order for editor and player being synched during play from editor
    // Called from EM.player.reload();
    function reload ( updatedSlideDeck ) {
        //get prev slide count
        var slideCount =  slidedeck.sections.reduce(function (prev, current) {
            return prev + current.slides.length;
        }, 0);

        // Clear current slides.
        while (slideCount) {
            scene.deleteSlide(1);
            slideCount--;
        }

        // Set global slide deck to edtior's provided slide deck
        slidedeck = updatedSlideDeck;

        // Set the provided slides
        slidesWorker.setSlides();
        sceneReadyTimeoutCounter = 0;
    }

    // Change a given slidedeck images src to data-src attribute
    function changeSlidedeckImgSrcToDataAttr (sd) {
        for (i = 0; i < sd.sections.length; i++) {
            sections = sd.sections[i];

            for (var j = 0; j < sections.slides.length; j++) {
                if (isCompatible) {  //CODEREVIEW: why is this being checked inside the loop? seems like first like of function should be if !isCompatible return; OR check before calling this function.
                    sections.slides[j] = changeSlideImgSrcToDataAttr(sections.slides[j]);
                }
            }
        }

        return sd;
    }


    /*** Private methods ***/

    // method will set EM.scenemanager.presentation according to data
    // recieved from getPresentation method from PresentController
    function getPresentationObject(id) {
           var canContinue = true;

           var getPresentationUrl,
               getPresentationData;
          

        if ( !isStatic ){
            // Fetch presentation object using AJAX

            if (EM.isLayoutsPlayer) {
                if (EM.isTemplatePreview) {
                    getPresentationUrl = "/present/getTemplateLayoutsPresentation";
                    getPresentationData = { groupId: EM.groupId };
                } else {
                    getPresentationUrl = "/present/getLayoutsPresentation";
                    getPresentationData = { themeId: EM.themeId };
                    if (EM.activatemode == "json2token" && EM.useremail) {
                        getPresentationData.activatemode = EM.activatemode;
                        getPresentationData.useremail = EM.useremail;
                        getPresentationData.refreshCache = true;
                    }
                }
            } else {
                getPresentationUrl = "/present/getPresentation";
                getPresentationData = { presentationID: id, key: getUrlParameter('key'), u: getUrlParameter('u') };
                try {
                    if (window.parent.model && window.parent.model.RemoteModel && !window.parent.model.IsOwner) {
                        getPresentationData.remoteKey = window.parent.model.SuperKey;
                    }
                }
                catch (e) { }
            }

            $.post(getPresentationUrl, getPresentationData, function (data) {
                EM.scenemanager.presentation = data;
                
                canContinue = errorHandler.init( EM.scenemanager.presentation.core.message );

                if ( canContinue ){
                    // Check if browser compatible with presentation
                    isCompatible = EM.compatibility.isCompatible();
                   // isCompatible = false; //TODO REMOVE!
                    $(window).trigger('presentationObjectReady');
                } 

            })
            // Not 404 error, might worth to retry fetching the presentation object
            .fail(function(error) {            
                // retry up to 3 times
                if ( attempt < 3 ){
                    console.error('Server responded with ' + error.status + " performing retry #" + (attempt + 1) );
                    attempt++;
                    getPresentationObject( id );

                } else {
                   window.dispatchEvent( new CustomEvent('error', { 'detail': error.status }) );
                   errorHandler.error500();
                   $(window).off('keydown');
                   console.error("Oh my, a " + error.status + " just occured.");
                }

            });

        } else {
            // Fetch presentation object from a static variable
            EM.scenemanager.presentation = presentation;

            // Check if browser compatible with presentation
            isCompatible = EM.compatibility.isCompatible();
            
            // Change files path for offline
            if (EM.player.context.isOffline) {
                resources = "resources";
            }

            if ( canContinue ) $(window).trigger('presentationObjectReady');
        }

    }

    // Get URI parameter value by parameter name
    function getUrlParameter (sParam) {
        var sPageURL = window.location.search.substring(1);
        var sURLVariables = sPageURL.split('&');
        for (var i = 0; i < sURLVariables.length; i++) 
        {
            var sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] == sParam) 
            {
                return sParameterName[1];
            }
        }

        return '';
    }

    // will set presentation thumbnail based on presentation ID
    function setLoaderThumb ( id ) {
        if ( !isStatic ){
            // Fetch using ajax
            $.ajax({
                url: '/getThumbnail/' + id,
                type: 'GET'
            })
            .done(function(data) {
                $('#thumb-img').css('opacity', 0).attr('src', data).animate({'opacity': 1}, 'slow');
            })
            .fail(function(error) {
                console.error("Unable to retrieve Presentation thumbnail, A " + error.status +" error just occured");
            });

        } else {
            // just animate. image is already there
           $('#thumb-img').css('opacity', 0).animate({'opacity': 1}, 'slow');
        }   
    }

   

    function appendLink(id, href) {
        var head = document.getElementsByTagName('head')[0],
            link = document.createElement('link');

            link.id = id;
            link.href = href;

            link.rel = 'stylesheet';
            link.type = 'text/css';
            link.media = 'all';

            head.appendChild(link);
    }

    function appendScript(className, src, isAsync) {
        var script = document.createElement('script');

        script.className = className;
        script.setAttribute('src', src);
        script.async = isAsync || false;
        document.body.appendChild(script);

    }

    // technologyWorker.init triggers on 'slidedeckReady' event.
    // get the DOM ready for the current presentation technology data
    var technologyWorker  = {
        init: function () {

            EM.scenemanager.isZoomer = EM.scenemanager.presentation.theme.jsUrl.indexOf("zoomer.js") != -1;
            EM.scenemanager.unauthWizardFrame = !EM.isLayoutsPlayer && window.name === "social"; // are we in the wizard with a presentation player (not layouts player)
            EM.scenemanager.replaceWithUserContent = EM.isLayoutsPlayer || EM.scenemanager.unauthWizardFrame; // are we going to replace with user content

            // this flag say if this is iPad or iPnone device
            EM.scenemanager.isAppleMobile = EM.compatibility.getType() == "ipad" || EM.compatibility.getType() == "iphone";
            EM.scenemanager.isAndroidMobile = EM.compatibility.getType() == "android";
            EM.scenemanager.mobileRemoveZoomer = EM.scenemanager.isAppleMobile || EM.scenemanager.isAndroidMobile && EM.scenemanager.presentation.theme.themeUrl.indexOf("sd-theme_halloweenparty") != -1;
            technologyWorker.setMeta();
            technologyWorker.setCSS(EM.scenemanager.presentation.theme.cssUrl);
            technologyWorker.setThemeCSS(EM.scenemanager.presentation.theme.themeUrl);
            technologyWorker.setScripts(EM.scenemanager.presentation.theme.jsUrl);
        },
        // setMeta will append/update meta tags (fb, twitter, etc.)
        setMeta: function(){
            var pName = EM.scenemanager.presentation.core.name,//presentation name
                oName = EM.scenemanager.presentation.userInfo.userName,//owner name
                playerUrl = EM.scenemanager.presentation.theme.playerUrl,
                thumbUrl = EM.scenemanager.presentation.theme.imageUrl,
                description = "";
            if (!EM.player.context.isStatic) {// EM.isPublished is to get the description meta for emaze.me
                description = (EM.playerSettings.MetaDescription == null || EM.playerSettings.MetaDescription == "") ? EM.scenemanager.presentation.core.description : EM.playerSettings.MetaDescription;
                if (EM.playerSettings.MetaTitle == null || EM.playerSettings.MetaTitle == "") {
                    $('title').html(pName + ' by ' + oName + ' on emaze');
                } else {
                    $('title').html(EM.playerSettings.MetaTitle);
                }
            }

            //  $('link[rel="canonical"]').attr('href', playerUrl);
            
            // added !EM.isPublished because on emaze.me websites or published presentations the description is set directly in website.cshtml .
            // if the user set in the editor the SEO tab (title, description ... ) then we use that. else we set the a default for a website or presentation from publishController.
            if (!EM.player.context.isOffline && !EM.isPublished) {
                switch (EM.ezContentTypeId) {
                    // presentations
                case null:
                case 0:
                case 1:
                        description = "Check out my latest presentation built on emaze.com, where anyone can create & share professional presentations, websites and photo albums in minutes.";
                    break;
                // e-card
                case 4:
                        description = "Check out this e-card made on emaze.com, where anyone can create & share presentations, websites, blogs, photo albums and e-cards in minutes.";
                    break;
                // website
                case 6:
                        description = "Check out my new website! Follow me on Emaze.me to get all my social media in one feed.";
                    break;
                // blog
                case 10:
                        description = "Check out my new blog! Follow me on Emaze.me to get all my social media in one feed.";
                    break;
                // Photo Album
                case 11:
                        description = "Check out my new photo album built on emaze.com, where anyone can create & share professional presentations, websites and photo albums in minutes.";
                    break;
                default:
                        description = "Check out my latest presentation built on emaze.com, where anyone can create & share professional presentations, websites and photo albums in minutes.";
                    break;
                }

                // Facebook meta
                $('meta[name="og:url"]').attr("content", playerUrl);
                $('meta[name="og:title"]').attr("content", pName);
                $('meta[name="og:image"]').attr("content", thumbUrl);
                $('meta[name="og:description"]').attr("content", description);

                // Twitter meta
                $('meta[name="twitter:url"]').attr("content", playerUrl);
                $('meta[name="twitter:title"]').attr("content", pName);
                $('meta[name="twitter:description"]').attr("content", description);
                $('meta[name="twitter:image"]').attr("content", thumbUrl);

                $('meta[name="description"]').attr("content", description);
            }

},
        // setCSS will append/update given CSS paths to the DOM
        // @params: path to the CSS file, id to recognize the CSS (technology/theme)
        // TODO: verify if any chance for multiple files in the path or always will be singular
        setCSS: function( path ){
            //if (!EM.player.context.isStatic) { //downloadable player has links already in place
            //    appendLink('technologyCSS', environment + '/' + path);
            //}

            //for iPhone and iPad devices use scene of blank theme (to avoid crash)
            if (EM.scenemanager.mobileRemoveZoomer && EM.scenemanager.isZoomer) {
                path = "Technologies/slides/css/style.css";
            }


            if (!EM.player.context.isStatic || EM.isPublished) { //downloadable player has links already in place
                appendLink('technologyCSS', environment + '/' + path);

                // if device is iPad or iPhone and technology was Zoomer we need to add css for slides
                if (EM.scenemanager.mobileRemoveZoomer && EM.scenemanager.isZoomer) {
                    appendLink('technologyCSS', environment + '/Technologies/slides/css/apple-mobile.css');
                }
            }
        },
        // get the DOM ready for the current presentation theme files
        setThemeCSS: function( path ){  //CODEREVIEW: create appendCSSLink function and re-use it below

            if (!isCompatible) { 
                appendLink('GenericThemeCSS', EM.player.context.isOffline ? $('#generic-css').attr('src') : environment + '/Technologies/Generic/css/generic.css');
            }

            if (!EM.player.context.isStatic) {
                appendLink('themeCSS', resources + '/' + path + '.css');

                if (EM.scenemanager.presentation.theme.customCssUrl) {
                    appendLink('CustomThemeCSS', EM.scenemanager.presentation.theme.customCssUrl);
                }

                if (EM.playerSettings && EM.playerSettings.checker && EM.playerSettings.checker.isSettingsBrand) {
                    appendLink('CustomPlayerCSS', EM.playerSettings.BrandCssUrl);
                }
            } 
        },
        // setScripts will append/update given scripts paths to the DOM
        setScripts: function( paths ){
            
            // compatability mode
            if (!isCompatible) {
                appendScript('technologyjs', EM.player.context.isOffline ? $('#generic-js').attr('src') : environment + '/Technologies/Generic/js/generic.js');
            }

            // theme js
            if ( !EM.player.context.isStatic ){
                //Theme specific js
                appendScript('themejs', resources + '/' + EM.scenemanager.presentation.theme.themeUrl + '.js');

                // custome theme js
                if (EM.scenemanager.presentation.theme.customJsUrl) {
                    $.ajax({
                        url: EM.scenemanager.presentation.theme.customJsUrl, //or your url
                        success: function (data) {
                            appendScript('customThemejs', EM.scenemanager.presentation.theme.customJsUrl);
                        },
                        error: function (data) {
                            console.error('Custom JS file does not exist');
                        },
                    });
                }

                // branding js
                if (EM.playerSettings && EM.playerSettings.checker && EM.playerSettings.checker.isSettingsBrand) {
                    $.ajax({
                        url: EM.playerSettings.BrandJsUrl, //or your url
                        success: function (data) {
                            appendScript('customPlayerJs', EM.playerSettings.BrandJsUrl);
                        },
                        error: function (data) {
                            console.log('Player Settings JS file does not exist');
                        },
                    });
                    
                }
            }
            // for Edge,Mac safari, iphone safari :replace Mask effect with fade in/out effect
            if (((EM.compatibility.getBrowser() == "edge") || (((EM.compatibility.getType() == "mac") || (EM.compatibility.getType() == "iphone")) && (EM.compatibility.getBrowser() == "safari"))) && EM.scenemanager.presentation.theme.themeId != 47793) {
                //If transition is Mask
                if (EM.scenemanager.isZoomer) {
                    paths = "Technologies/vendor/gsap/easing/BezierEasing.js,Technologies/vendor/gsap/TweenMax.min.js,Technologies/vendor/gsap/TimelineMax.min.js,Technologies/slides/js/main.js";
                    window.EM_theme = {
                        enableCustomTransition: true,
                        // Following methods will be used within the technology goSlide() method
                        transition: { "in": { "effect": "fade", "duration": 1, "delay": 0.2 }, "out": { "effect": "fade", "duration": 1, "delay": 0 } },
                        sceneSettings: {
                            foreground: 0, // number of foreground elements required
                            background: 0, // number of background elements required
                            isDark: false   // theme dark or bright
                        }
                    }
                }
            }


            // technology js
            if (!EM.player.context.isStatic || EM.isPublished) {

                // for iPhone and iPad devices use scene of blank theme (to avoid crash)
                if (EM.scenemanager.mobileRemoveZoomer && EM.scenemanager.isZoomer && EM.scenemanager.presentation.theme.themeId != 47793) {
                    paths = "Technologies/vendor/gsap/easing/BezierEasing.js,Technologies/vendor/gsap/TweenMax.min.js,Technologies/vendor/gsap/TimelineMax.min.js,Technologies/slides/js/main.js";
                    window.EM_theme = {
                        enableCustomTransition: true,
                        // Following methods will be used within the technology goSlide() method
                        transition: { "in": { "effect": "fade", "duration": 1, "delay": 0.2 }, "out": { "effect": "fade", "duration": 1, "delay": 0 } },
                        sceneSettings: {
                            foreground: 0, // number of foreground elements required
                            background: 0, // number of background elements required
                            isDark: false   // theme dark or bright
                        }
                    }
                }

                if (isCompatible) {
                    // parse paths to an array
                    var pathsArray = paths.split(',');

                    // append each given script to the DOM
                    for (var i = 0; i < pathsArray.length; i++) {
                        appendScript('technologyjs', environment + '/' + pathsArray[i]);
                    };

                    if (paths.indexOf('zoomer') != -1) {  //CODEREVIEW: what if movement.js is already in the array? check if contains movement.js and dont add twice OR fix the technology strings in the database OR merge the two files into zoomer.js and dont load 2 files
                        appendScript('technologyjs', environment + '/Technologies/Zoomer/js/movement.js');
                    }
                }
            }

            // Listen to scene init loadfinished event and continue with
            // scene setup
            $('body').on('loadfinished', function(){  //CODEREVIEW: why are we listening to one event just to fire another event?
                // report technologyReady event
                $(window).trigger('technologyReady');
            });

            // check if loaded scene object is ready and init the scene
        
            var interval = setInterval(function () {

                if ((isCompatible || typeof (window.scene.isFallback) === "function") && typeof (window.scene.init) === "function") { // if not compatible, make sure scene is fallback. otherwise, the scene object is still set to the original scene
                    clearInterval(interval);
                    scene.init('scene', { resourcesURL: resources, themeURL: EM.scenemanager.presentation.theme.themeUrl, forceSlideUpdate: EM.player.context.isEditor || (EM.scenemanager.replaceWithUserContent && !onePage) });
                    isSlideBox = $('#slide-box').length;
                }

            }, 100);

            //TODO : replace interval code above with solution below after production upload. all scenes now fire the event below. need to solve offline player(download)

            //$(document).one(isCompatible ? 'scene-ready' : 'generic-scene-ready', function () {
            //    scene.init('scene', {
            //        resourcesURL: resources,
            //        themeURL: EM.scenemanager.presentation.theme.themeUrl,
            //        forceSlideUpdate: EM.player.context.isEditor
            //    });
            //    isSlideBox = $('#slide-box').length;
            //});



        },
        // Clearing all implemented scripts
        clearScripts: function(){
            $('.technologyjs').remove();
            $('.themejs').remove();
        },
        // Clearing current theme CSS
        clearThemeCSS: function(){
            $('#themeCSS').remove();
        }
    }

    // slidesWorker.init triggers on 'presentationObjectReady' event.
    // sets the scene
    
    function triggerSceneReady(slidedeck, totalNumOfSlides){
        if (EM.player.context.isOffline  || sceneReadyTimeoutCounter > 2) { //failsafe to stop doing timeout to prevent endless loop.
            $(window).trigger('sceneReady', [slidedeck, totalNumOfSlides]);
        
       //} else if (EM.player.context.isPrezuTube) {
         //   sceneReadyTimeoutCounter++;
           // setTimeout(triggerSceneReady, 60 * 1000, slidedeck, totalNumOfSlides); //giving a full 10 * 3 = 30 seconds for player to load in case its loading heavy media
        } else if (EM_YoutubePlayer.globals.isReady) {
            $(window).trigger('sceneReady', [slidedeck, totalNumOfSlides]);
        }
        else {
            sceneReadyTimeoutCounter++;
            setTimeout(triggerSceneReady, 100, slidedeck, totalNumOfSlides);
        }
    }

    var slidesWorker = {
        init: function(){
            // Build slidedeck from raw presentation object slidedeck
            if (EM.player.context.isOffline) {
                slidedeck = EM_slideDeck.getSlideDeckFromDocument();
                EM_slideDeck.decompressSectionTitles(slidedeck);
            }else {
                slidedeck = EM_slideDeck.getSLideDeckFromString(EM.scenemanager.presentation.theme.slides);
            }

           // if (scene.setZoom) { //cant pass this setting in scene.init because technology worker runs before slidesworker
           //     scene.setZoom(slidedeck.presentationSettings ? (slidedeck.presentationSettings.zoomFactor || 1) : 1);
           // }

            // for taking efficient thumbnails
            if (onePage) {
                slidedeck.sections = slidedeck.sections.filter(function (s, i) { return i == 0; });  // one section
                slidedeck.sections[0].slides = slidedeck.sections[0].slides.filter(function (s, i) { return i == 0; }); // one slide
            }

            slidesWorker.setSlides();
        },
        // Method get raw (compressed) slide deck,
        // Parse it and add the slides to the DOM
        setSlides: function(){
            var totalNumOfSlides = 0, section, slideHtml;

            imageOptimizer.enableLazyload = isSlideBox && isCompatible; // &!EM.player.context.isEditor

            var k = 0;

            
            // show emaze websize banner
            var showScrolledEmazeBanner = (EM.isWebsite /*&& !EM.scenemanager.isZoomer */);

            // add the slides
            for (i = 0; i < slidedeck.sections.length; i++) {
                section = slidedeck.sections[i];

                for (var j = 0; j < section.slides.length; j++) {
                    slideHtml = section.slides[j];
                    optimizer.analyzeSlide(slideHtml);
                    section.slides[j] = processSlideString(slideHtml, k++, showScrolledEmazeBanner);
                    window.scene.addSlide(section.slides[j]);
                }

                totalNumOfSlides += section.slides.length;

                //!!! Currently I set here code which adds to all iframes id value if not exists
                // This needs for Remote Control (togetherjs)
				try{
					if (TogetherJS) {
						$('iframe').each(function (index) {
							if (!this.id) {
								this.id = "rm-" + index;
							}
						});
					}					
				}
				catch(e){}
                


                // ihpone fallback - use background images on slide (2D transition) - same as scene has in zoomer
                if (EM.scenemanager.isMobile && EM.scenemanager.isZoomer) {
                    $("#sceneContainer .slide").addClass('sd-world-background-image_1');
                }
            }

            // efficient thumbnail gen - leave only elements visible in first fold - good for long one pagers
            if (onePage) {
                $('.edit-wrapper').each(function () { if (parseInt($(this).css('top')) > 1080) $(this).remove() });
            }

            // here good place for set parallax effect to elements
            if (window.setOrUpdateParallaxEffect) {
                window.setOrUpdateParallaxEffect();
            }
            
            // For now add comaptibility msg display here, until better place is found
            if (!isCompatible && EM.compatibility.getDevice() != 'mobile') {
                $('.compatability-msg').removeClass('hidden');
                $('.compatability-button').click(function(){
                     $('.compatability-msg').addClass('hidden'); 
                });    
            }

            // add emaze banner for zoomer in scene - if free user websize on zoomer
            // remarked - now we add it in the slide itself
            //if (EM.scenemanager.isZoomer && EM.isWebsite) {
            //    var shapeBottom = 0;
            //    var tmpBannerHtml = bannerZoomerHtml.replace("@textBottom@", (shapeBottom+4).toString()).replace("@shapeBottom@", shapeBottom.toString()).replace("@iconBottom@", (shapeBottom + 10).toString());
            //    $('#main-container').append(tmpBannerHtml);
            //}

            

            triggerSceneReady(slidedeck, totalNumOfSlides);

            if (slidedeck.animationCSS) {
                console.count('keyframe-style');
                $('.keyframe-style').remove();
                setTimeout(function () {
                    $('<style type="text/css" class="keyframe-style">' + slidedeck.animationCSS + '</style>').appendTo("head");
                }, 3000);
              

            }
        }
    }

    function ensureYoutubeSSLbackwardsCompatability(html) {

        var match = html.match(/<iframe.*?((http.*?sd-element-video)|(sd-element-video.*?http)).*?>/g), updated;

        if (match) {
            updated = match.map(function (elm) {
                // Replace src with data-src & set default blank image in the src
                return elm.replace('http://', 'https://');
            });

            // Update the html
            for (var i = 0; i < updated.length; i++) {
                html = html.replace(match[i], updated[i]);
            };
        }
        return html;

    }

    function isYouTube(iframeHtml) {
        return iframeHtml.indexOf('sd-element-video') !== -1;
    }

    function isOptimizationEnabled(iframeHtml) {
        return iframeHtml.indexOf('data-optimization="none"') === -1;  //defaults to true if not specified
    }

    function updateIFrameSrcAndDataAttr(html) {
        //doing with regex rather than parsing as html because parsing it as html causes the resources to load.
        var match = html.match(/<iframe.*?>/g), updated;
        var enableOptimization = false;

        if (match) {
            updated = match.map(function (elm) {
                                       //must have optimize flag set to none, or be a vidoe element, to skip the optimization process
                enableOptimization = isOptimizationEnabled(elm); 
                //*BUT*
                if (isYouTube(elm)) {
                    enableOptimization = false;  //defaults to false if youtube 
                }
              
                // facebook 2 month token expire fix, replace our default that expired with a new one from 26-April-17
                elm = elm.replace('EAAVOVZClxBBkBAApCTBsYPrFsVPdAt4ur3RHxUwIErfZBWZCmWKqXayTXh0A8Da0zhAwyETfHYsZCEmfld04MQrP2phrdc2o7QiLChyLstaHzADCYFVpIChgI0pZAtMfnp4FZBekk5pXGa1dcx2PBfyMBkRCtPE8kZD',
                            'EAAVOVZClxBBkBANxyICLYmragkmadyrQ3LoDwfZBSczOGKEh40ZBdZCUZAZBivlgJxi2UOtL3ZA454qDNY1JVHyQTZBiwkOMyoS5Q6hPZBFbwDHIcZA4T8oZCWqSXbslvIwXbcGKH953qZBcGCJN8CnCrrNQSMqWZC3TOG08ZD');
                // Replace src with data-src & set default blank in the src
                return enableOptimization ? elm.replace(' src', ' src="about:blank" data-src') : elm;
            });

            // Update the html
            for (var i = 0; i < updated.length; i++) {
                html = html.replace(match[i], updated[i]);
            };
        }
        return html;

    }



    //consider using this: https://github.com/ressio/lazy-load-xt

    //enable disable videos in slide.
    function processVideos(html) {

        var videos = html.match(/<video.*[^-]src="[^"+]".*>/g), videosUpdated;  //regex matches all videos that have a src attribute that is not "" should also handle sighe quotes just in case...

        if (videos) {
            videosUpdated = videos.map(function (elm) {
                // Replace src with data-src & set default blank image in the src
                return elm.replace('src', 'src="" data-src');
            });
            // Update the html
            for (var i = 0; i < videosUpdated.length; i++) {
                html = html.replace(videos[i], videosUpdated[i]);
            };
        }

        return html;
           
    }
    
    function getMobileSlideHtml(html) {

        //for each element that has data-mobile-style defined, remove (or disable by adding data-) the style attribute,  remove data-mobile from that attribute to make it the style attribute

        //  var device = EM.compatibility.getDevice(), imagesFolder;

        // get all elements with mobile style defined
        var elements = html.match(/<[^>]*data-mobile-style[^>]*>/g), elementsUpdated;  //target all images

        if (elements) {
            elementsUpdated = elements.map(function (elm) {
                // Replace src with data-src & set default blank image in the src
                return elm.replace(' style', ' data-style').replace('data-mobile-style', 'style');
            });

            for (var i = 0; i < elementsUpdated.length; i++) {
                html = html.replace(elements[i], elementsUpdated[i]);
            };
        }

        return html;
    }

    function processSlideString(slideHtml, slideNum, showScrolledEmazeBanner) {

        slideHtml = processVideos(slideHtml);

        slideHtml = ensureYoutubeSSLbackwardsCompatability(slideHtml);


        if (imageOptimizer.enableLazyload || imageOptimizer.enableResize) {
            slideHtml = changeSlideImgSrcToDataAttr(slideHtml);
        }
        
        slideHtml = updateIFrameSrcAndDataAttr(slideHtml);


        //now that all src attributes have been safely neutralized, we can run the following function that parses the dom to optimize with cloudinary
        if (imageOptimizer.enableResize || imageOptimizer.disableGifs) { 
            slideHtml = optimizeSlideImgDataSrcWithCloudinary(slideHtml);
        }

        try {
      
        if (!slidedeck.slideSettings[slideNum]) {
            slidedeck.slideSettings[slideNum] = $(slideHtml).data(); //todo: parse just the slide without children (substring at index of >) to optimize
        }
        } catch (e) {
            console.warn(e);
        }


        if (!imageOptimizer.enableLazyload && imageOptimizer.enableResize) { //if we are not lazy-loading but we moved the src to data-src, we need to move it back now.
            slideHtml = changeSlideImgDataAttrToSrc(slideHtml);
        }

     

        if (EM.player.context.isMobile) {
            slideHtml = getMobileSlideHtml(slideHtml);
        }
       
        return slideHtml;
    }
    

    // Change src attribute to data-src with img URL.
    function changeSlideImgSrcToDataAttr ( html) {
      //  var device = EM.compatibility.getDevice(), imagesFolder;
       
        // var images = html.match(/<img(.*?src=.*?layoutimages).*?>/g),  // Target all the layout images, user content will be unaffected
        var images = html.match(/<img.*?>/g), imagesUpdated;  //target all images
        
        if (images){
            imagesUpdated = images.map(function(elm){
                // Replace src with data-src & set default blank image in the src
                return elm.replace('src', imageOptimizer.enableLazyload ? 'src="//resources.emaze.com/vbplayer/images/blanky.png" data-src' : "data-src");
            });
           
            //if (device == EM.compatibility.Devices.MOBILE) {
            //    imagesFolder = 'layoutimages_mobile';
           // }else if (device == EM.compatibility.Devices.TABLET) {
           //     imagesFolder = 'layoutimages_tablet';
           // }else {
           //     imagesFolder = false;
           // }

            // Update the html
            for (var i = 0; i < imagesUpdated.length; i++) {
              //  if (imagesFolder) {
                    // In case of mobile change image path to mobile layout images
               //     imagesUpdated[i] = imagesUpdated[i].replace('layoutimages', imagesFolder);
               // }
                    html = html.replace(images[i], imagesUpdated[i]);
                };
        }

        return html;
    }

    // Change src attribute to data-src with img URL.
    function changeSlideImgDataAttrToSrc(html) {
        // var images = html.match(/<img(.*?src=.*?layoutimages).*?>/g),  // Target all the layout images, user content will be unaffected
        var images = html.match(/<img.*?>/g), imagesUpdated;  //target all images

        if (images) {
            imagesUpdated = images.map(function (elm) {
                // Replace src with data-src & set default blank image in the src
                return elm.replace('data-src', 'src');
            });

            // Update the html
            for (var i = 0; i < imagesUpdated.length; i++) {
               
                html = html.replace(images[i], imagesUpdated[i]);
            };
        }

        return html;
    }

    function addCloudinaryDimentionParam(params, key, val) {
        var roundFactor = 40; // round to closet 40 pixels to save on cloudinary transformations.
        if (val) {
            params.push(key + Math.ceil(Math.round(val * imageOptimizer.screenScaleFactor) / roundFactor) * roundFactor);  //round up to closest 10 pixels  consider: multiply by the scale factor of the scene
        }
    }

    function generateCloudinaryImgUrl($img, src) {
        var w, h, isOptimized = false, params = ['c_limit', 'a_ignore'], img = $img[0], sizeAttr, size, isGif, isParallax, sizeFactor; //size is an array [width,height] of the image's natural size, saved by the editor


        if (!src) {
            return src;
        }

        sizeAttr = $img.attr('data-img-size');
        isGif = imageOptimizer.disableGifs && src.endsWith('.gif');
        isParallax = $img.closest('.edit-wrapper').is("[class*='sd-image-effect_parallax']");

        if (sizeAttr) {

            size = sizeAttr.split(',');
            if (size && size.length == 2) {

                w = parseInt(img.style.width.indexOf('%') === -1 ? img.style.width : img.parentElement.style.width);
                h = parseInt(img.style.height.indexOf('%') === -1 ? img.style.height : img.parentElement.style.height);

                sizeFactor = isGif ? 1.1 : 2.2; // 1 = 100% 2= 50% 

                // for parallax, we don't want to 'correct' the image size relative to element size, because it needs to be bigger.
                // we only care about reduction in screen size.
                if (isParallax) {
                    if (imageOptimizer.screenScaleFactor <= imageOptimizer.parallaxTreshold) {
                        addCloudinaryDimentionParam(params, 'w_', parseInt(size[0]));  //just width is enough, hiehgt will scale down automatically.
                        isOptimized = true;
                    }
                }

                else if (size[0] / (w * imageOptimizer.screenScaleFactor) > sizeFactor || size[1] / (h * imageOptimizer.screenScaleFactor) > sizeFactor) {
                    addCloudinaryDimentionParam(params, 'w_', w);
                    addCloudinaryDimentionParam(params, 'h_', h);
                    isOptimized = true;
                }
            }
        }

        if (isGif) {
            params.push('f_png');
            isOptimized = true;
        }

        if (isOptimized) {
            if (src.indexOf('//') === 0) {
                src = window.location.protocol + src; //can't send relative protocol to cloudinary
            }
            return 'https://res.cloudinary.com/emazecom/image/fetch/' + (params.length ? params.join(',') : '') + '/' + encodeURIComponent(src);
        } else {
            return src; //don't change the src if there is nothign to optimize.
        }
    }


    function optimizeSlideImgDataSrcWithCloudinary(slideHtml)
    {
        var $tempDomFragment =  $('<div>').html(slideHtml);
        
        $tempDomFragment.find('.sd-element-image').each(function () {
            var $this = $(this),
                src = generateCloudinaryImgUrl($this, $this.attr('data-src'));
                $this.attr('data-src', src);
        });

        return $tempDomFragment.html();
    }

    function loadMyImage($images, i) {
        var image = $images.eq(i),
            imageSrc = image.attr('data-src');  

        $('<img />').load(function () {
            // remove data-src & set image src
            image.removeAttr('data-src');

            image.attr('src', imageSrc);

            image.trigger('ez-load');

            if (i < $images.length) loadMyImage($images, i + 1);

        }).error(function () {//Even if image missing continue with the rest
            if (i < $images.length) loadMyImage($images, i + 1);
        }).attr('src', imageSrc);//Start the loading chain
    }


    // Forcing sync load of slide images in a given container
    function gradualImageLoader ( containerID ) {
        var $slides = $(containerID).find('.slide');

        $.each($slides, function(index, slide) {
            //get all blanked-out images in slide, and 
            loadMyImage($('.edit-wrapper:not(.parallax-box) img[src*=blanky]', slide), 0);
        });
    }

    var errorHandler = {
        init: function ( msg ) {
            var scale_factor = $(window).width() / 1920;

            function handleError(callBack, errorMessage ) {
                callBack.call();
                $(window).off('keydown');
            }

            function adjustViewForMobile() {
                if (EM.compatibility.getDevice() === ('mobile')) {
                    scale_factor = 0.6;
                    $('#the-error').css('left', '-25px');
                }
            }
            switch( msg ){
                case 'E403'://No permission to view presentation
                    handleError(errorHandler.notAllowed, 'presentation is private');
                break;
                case 'E404'://Presentation not found
                    handleError(errorHandler.error404, 'presentation not found');
                break;
                case 'E500'://Server Error 500
                    handleError(errorHandler.error500, 'server error');
                break;
                case 'NA'://Presentation Deleted
                    handleError(errorHandler.notAvailable, 'presentation deleted');
                break;
                case 'login':
                    handleError(errorHandler.login, 'login requried to view this presentation');
                    adjustViewForMobile();
                break;
                case 'password':
                    handleError(errorHandler.password, 'presentation is password protected');
                    adjustViewForMobile();
                    break;
                case 'username':
                    handleError(errorHandler.setUsername, 'Set Email');
                    adjustViewForMobile();
                    break;
                default:
                    return true; //no error;
            }
         
            // Scale the error to fit the screen
            $('body').css('background', 'black');
            EM.player.setScale($('#the-error'), scale_factor);
            return false;
        },
        hideError: function () {
            $('#menu-container').removeClass('hidden');
            $('#the-error').fadeOut(300);
        },
        error404: function(){
            $('#menu-container').addClass('hidden');
            EM.player.removeLoader();

            $('.error-image').addClass('error-404');
            $('.error-header').text('DOH!');
            $('.error-text').text("We looked everywhere and we're unable to find the requested presentation.");
            $('.close-button').on('click', function(){
                window.location.href = '/mypresentations';
            });
            $('.error-info').append('<p class="server-msg">' + EM.scenemanager.presentation.core.details + '</p>');
            
            $('#the-error').fadeIn(300);

            $(window).trigger('playerError', {
                detail: {
                    type: "E404",
                    image: 'error-404',
                    header: 'DOH!',
                    text: "We looked everywhere and we're unable to find the requested presentation.",
                    clickUrl: '/mypresentations',
                    details: EM.scenemanager.presentation.core.details
                }
            });

        },
        error500: function(){
            $('#menu-container').addClass('hidden');
            EM.player.removeLoader();
            
            $('.error-image').addClass('error-500');
            $('.error-header')
                .html("TOTO,<br/><span>we're not in Kansas anymore...</span>")
                .css('font-size', '6em');
            $('.error-text').text("A server error occured and unexplained things are happening around us.");
            $('.close-button').on('click', function(){
                window.location.href = '/mypresentations';
            });
            if ( EM.scenemanager.presentation != undefined ){
                $('.error-info').append('<p class="server-msg">' + EM.scenemanager.presentation.core.details + '</p>');
            }
            $('#the-error').fadeIn(300);

            $(window).trigger('playerError', {
                detail: {
                    type: "E500",
                    image: 'error-500',
                    header: "TOTO,<br/><span>we're not in Kansas anymore...</span>",
                    text: "A server error occured and unexplained things are happening around us.",
                    clickUrl: '/mypresentations',
                    details: EM.scenemanager.presentation.core.details
                }
            });

        },
        login: function(title, description){
            title = title === undefined ? "PRIVATE: PLEASE LOGIN" : title;
            description = description === undefined ? "This presentation is private, login to view it" : description;

            $(window).trigger('playerError', {
                detail: {
                    type: "login",
                    title: title,
                    description: description
                }
            });

            $('#regform > .form-header').text(title);
            $('#regform > .description').text(description);

            $('#menu-container').addClass('hidden');
            EM.player.removeLoader();

            $('.close-button').hide();

            $('#the-error').fadeIn(300);
           // $('.form-header p').text('Private: Please Login');
           // $('.description').text('This presentation is private, login to view it');
            $('#regform').show();
        },
        notAllowed: function(){
            $('#menu-container').addClass('hidden');
            EM.player.removeLoader();

            $('.error-image').addClass('error-allow');
            $('.error-header').text('Shhhhh...');
            $('.error-text').text("The presentation you are trying to access is private, you do not have permission to view it.");
            $('.close-button').on('click', function(){
                window.location.href = '/mypresentations';
            });
            $('.error-info').append('<p class="server-msg">' + EM.scenemanager.presentation.core.details + '</p>');

            $('#the-error').fadeIn(300);

            $(window).trigger('playerError', {
                detail: {
                    type: "E403",
                    image: 'error-allow',
                    header: "Shhhhh...",
                    text: "The presentation you are trying to access is private, you do not have permission to view it.",
                    clickUrl: '/mypresentations',
                    details: EM.scenemanager.presentation.core.details
                }
            });

        },
        notAvailable: function(){
            $('#menu-container').addClass('hidden');
            EM.player.removeLoader();

            $('.error-image').addClass('error-deleted');
            $('.error-header').text('So sorry!');
            $('.error-text').text("This presentation has been deleted.");
            $('.close-button').on('click', function(){
                window.location.href = '/mypresentations';
            });
            $('.error-info').append('<p class="server-msg">' + EM.scenemanager.presentation.core.details + '</p>');

            $('#the-error').fadeIn(300);

            $(window).trigger('playerError', {
                detail: {
                    type: "NA",
                    image: 'error-deleted',
                    header: "So sorry!",
                    text: "This presentation has been deleted.",
                    clickUrl: '/mypresentations',
                    details: EM.scenemanager.presentation.core.details
                }
            });
        },
        password: function(){
            $('#menu-container').addClass('hidden');
            EM.player.removeLoader();

            $('#the-error').fadeIn(300);

            $('.close-button').hide();

            $('#the-error').fadeIn(300);
            $('.form-header p').text('Password Protected');
            $('.description').text('This presentation is password protected. Please enter your password:');

            $('#passwordProtected').show();

            $('.gopassgo').on('click', function(event) {
                event.preventDefault();

                $.ajax({
                    url: "/Password/index",
                    type: "POST",
                    data: {
                        presentationId: presentationId,
                        password: $('.passy').val()
                    },
                    success: function(data){

                        if ( data === 'true') {                            
                                setTimeout(function () {
                                    window.location.reload(); // clear cache
                                }, 1000);                            
                                //window.location.href = "/" + presentationId;
                        } else {
                            $('#passwordProtected .field-validation-error-password')
                            .hide()
                            .text( 'Wrong Password' )
                            .show()
                            .animate({'bottom': '0px'}, 300, 'easeOutBounce', function(){
                                // Hide error messages on input focus
                                $('input').one('focus', function(){
                                    $('.field-validation-error-password')
                                    .add('.field-validation-error-user')
                                    .delay(300)
                                    .animate({'bottom': '-40px'}, 300).empty();

                                });
                            });
                        }
                    }
                });

            });

            $(window).trigger('playerError', {
                detail: {
                    type: "password",
                    header: "Password Protected",
                    text: "This presentation is password protected. Please enter your password:",
                }
            });
        },
        setUsername: function () {
            $('#menu-container').addClass('hidden');
            EM.player.removeLoader();
            $('#the-error').fadeIn(300);
            $('.close-button').hide();
            $('#the-error').fadeIn(300);
            $('.form-header p').text('Email');
            $('.description').text('Please enter your email:');
            $('#username-analytic').show();

            $('.gopassgo').on('click', function (event) {
                event.preventDefault();                
                if ($('.username analytic').val() != "") {
                    var mail = $('.username.analytics').val(), name = "",
                        index = mail.indexOf('@');
                    if (index != -1) name = mail.substr(0, index); else name = mail;
                    $.cookie("ezalias", name, { path: '/' });
                    $.cookie("ezfullname", name, { path: '/' });
                    $.cookie('ezlogged', mail, { path: '/' });
                }
                setTimeout(function () {
                    window.location.href = window.location.origin + "/" + EM.presentationId; //Remove parameter u = 1 
                }, 1000);
            });

            $(window).trigger('playerError', {
                detail: {
                    type: "username",
                    header: "Email",
                    text: "Please enter your email:",
                }
            });
        }
    }

    // Return slide
    function getSlideByPosition (pos) {
        var counter = 0;

        for (i = 0; i < slidedeck.sections.length; i++) {
            sections = slidedeck.sections[i];

            for (var j = 0; j < sections.slides.length; j++) {
                
                if ( counter == pos ){
                    return sections.slides[j];
                }

                counter++;
            }
        }
    }

    // Return slide
    function getSectionNameBySlide (pos) {
        var counter = 0;

        for (i = 0; i < slidedeck.sections.length; i++) {
            sections = slidedeck.sections[i];

            for (var j = 0; j < sections.slides.length; j++) {
                
                if ( counter == pos ){
                    return sections.title;
                }

                counter++;
            }
        }

    }

    // return parsed slidedeck
    function getSlidedeck () {
        return slidedeck;
    }

    //public methods
    return {
        init: init,
        reload: reload,
        clearTheme: technologyWorker.clearThemeCSS,
        setTheme: technologyWorker.setThemeCSS,
        getSlidedeck: getSlidedeck,
        getSlideByPosition: getSlideByPosition,
        getSectionNameBySlide: getSectionNameBySlide,
        ezLoadImages: gradualImageLoader,
        changeSlideImgSrcToDataAttr: changeSlideImgSrcToDataAttr,
        changeSlidedeckImgSrcToDataAttr: changeSlidedeckImgSrcToDataAttr,
        errorHandler: errorHandler,
        processSlideString: processSlideString,
        imageOptimizer: imageOptimizer,
        optimizer: optimizer
    }

}(jQuery));

