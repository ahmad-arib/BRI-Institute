EM.player.widgets = (function () {
    var api = {};

    function getCurrentSlideIframeWindows() {
        var windows = [];

        $('.current-active-slide iframe.sd-widget').each(function () {
            windows.push(this.contentWindow);
        });

        return windows;
    }

    api.executeCommand = function (windows, command, params) {

        var message = JSON.stringify({command: command, params:params});

        windows.forEach(function (win) {
            win.postMessage(message, '*');
        });
    }

    api.transitionStart = function () {
        api.executeCommand(getCurrentSlideIframeWindows(), 'transitionStart');
    }

    api.transitionDone = function () {
        api.executeCommand(getCurrentSlideIframeWindows(), 'transitionDone');
    }

    return api;
}());
