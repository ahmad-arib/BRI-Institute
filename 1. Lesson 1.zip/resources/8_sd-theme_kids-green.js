try {
// custom theme classes
$(document).ready(function(){
    $('#scene').addClass('sd-world-background-image_1');
});

// kids
var zoomerInit = new function () {
    this.set = function (s) {
        // location: x,y,z
        // rotation: rx,ry,rz. Use 0-360 to prevent carousel problems
        // width: w (height is calculated as 16*9)
        // reverse: come to the slide from the other direction
        // s.addTarget(x, y, z, rx, ry, rz, width);

        //s.addTarget(0, 0, 0, 0, 0, 0, 2000); // 1920/2=960      
        s.setLocation(640, 460, 500, -180, -180, 180, 250, 3000, 'Quartic.In');
        //s.setLocation(860, 460, 950, -180, -180, 180, 250, 6000, 'Quartic.In');
        //s.addTarget(860, 460, 950, -180, -180, 180, 250);

        s.addTarget(650, 470, 55, -180, -180, 185, 200, 1500, 'Quadratic.Out'); //slide1  


        s.addTarget(920, 650, 65, -180, -180, 185, 350, 1500, 'Quadratic.Out'); //slide2

        //s.addTarget(1090, 470, 65, -180, -180, 190, 350, 1500, 'Quadratic.Out'); //slide3
        s.addTarget(930, 410, 65, -180, -180, 190, 350, 1500, 'Quadratic.Out'); //slide3
        s.addGlide(1170, 470, 255, -180, -180, 190, 200, 1000, 'Quadratic.Out');


        //s.addTarget(1320, 710, 65, -180, -180, 175, 350, 1100, 'Quadratic.Out'); //slide4
        s.addTarget(1320, 560, 65, -180, -180, 175, 200, 1100, 'Quadratic.Out'); //slide4
        s.addGlide(1230, 570, 225, -180, -185, 185, 350, 1000, 'Quadratic.Out');



        s.addTarget(1300, 260, 65, -180, -180, 175, 250, 1500, 'Quadratic.Out'); //slide5
        s.addGlide(1180, 260, 225, -180, -180, 180, 350, 1000);


        s.addTarget(920, 230, 65, -180, -180, 185, 250, 2000, 'Quadratic.Out'); //slide6

        s.addGlide(920, 230, 245, -180, -180, 180, 250, 1000, 'Quadratic.Out');

        s.addTarget(510, 230, 65, -180, -180, 175, 350, 1000, 'Quadratic.Out'); //slide7

        s.addGlide(670, 370, 175, -180, -180, 175, 350, 1000, 'Quadratic.Out');

        s.addTarget(520, 640, 65, -180, -180, 175, 350, 2000, 'Quadratic.Out');//slide8





        ;
    };
} // GLIDE
}
catch  (ex) { }
